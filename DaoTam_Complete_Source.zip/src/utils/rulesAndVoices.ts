import { Chapter, VoiceOption } from '../types';

/**
 * QUY TẮC THIẾT LẬP VIP TỰ ĐỘNG:
 * - Truyện dài trên 200 chương: Set VIP từ chương thứ 51 trở về sau (50c đầu miễn phí).
 * - Truyện ngắn dưới 200 chương: Set VIP từ chương thứ 31 trở về sau (30c đầu miễn phí).
 */
export function calculateChapterVip(chapterNumber: number, totalChapters: number): { isVip: boolean; priceXu: number } {
  const isVip = totalChapters >= 200 ? chapterNumber >= 51 : chapterNumber >= 31;
  return {
    isVip,
    priceXu: isVip ? 5 : 0,
  };
}

/**
 * Chuẩn hóa chuỗi tiếng Việt sang chuẩn Unicode Canonical Composition (NFC).
 * Loại bỏ hoàn toàn lỗi hiển thị dấu rời rạc, dấu huyền/sắc bị tách thành backtick hay khoảng cách.
 */
export function normalizeViText(text?: string | null): string {
  if (!text) return '';
  return text.normalize('NFC');
}

/**
 * TỶ LỆ NHUẬN BÚT / CHIA SẺ DOANH THU VIP (TỐI ƯU THEO VERCEL SERVERLESS $0 CHI PHÍ VẬN HÀNH):
 * Vận hành trên nền tảng Serverless hiện đại với chi phí hosting tối ưu,
 * Đạo Tâm chi trả tỷ lệ doanh thu kỷ lục cho người sáng tác & dịch:
 * - Tác giả sáng tác (Author): Hưởng 98% (Nền tảng giữ 2% phí cổng/bảo trì)
 * - Editor / Dịch giả: Hưởng 90% (Nền tảng giữ 10%)
 * - Đăng Độc Quyền tại Đạo Tâm: Hưởng 95% (Nền tảng giữ 5%)
 */
export const ROYALTY_RATES = {
  author: 98,
  editor: 90,
  exclusive: 95,
  platformShare: {
    author: 2,
    editor: 10,
    exclusive: 5,
  },
} as const;

export function getStoryRoyaltyRate(isExclusive?: boolean, isEditorOnly?: boolean): {
  rate: number;
  label: string;
  platformShare: number;
} {
  if (isExclusive) {
    return {
      rate: ROYALTY_RATES.exclusive,
      label: 'Đăng Độc Quyền (95% Doanh Thu)',
      platformShare: ROYALTY_RATES.platformShare.exclusive,
    };
  }
  if (isEditorOnly) {
    return {
      rate: ROYALTY_RATES.editor,
      label: 'Editor / Bản Dịch (90% Doanh Thu)',
      platformShare: ROYALTY_RATES.platformShare.editor,
    };
  }
  return {
    rate: ROYALTY_RATES.author,
    label: 'Tác Giả Sáng Tác (98% Doanh Thu)',
    platformShare: ROYALTY_RATES.platformShare.author,
  };
}

/**
 * DANH SÁCH GIỌNG ĐỌC MICROSOFT EDGE TTS TIẾNG VIỆT THỰC TẾ
 * Tuyệt đối không bịa giọng ảo, không nhân bản bằng cách chỉnh pitch/rate.
 * Giữ nguyên chất giọng Neural tự nhiên chuẩn bản ngữ:
 * 1. vi-VN-HoaiMyNeural: Giọng Nữ truyền cảm, nhẹ nhàng, tự nhiên.
 * 2. vi-VN-NamMinhNeural: Giọng Nam trầm ấm, đĩnh đạc, chuẩn bản ngữ.
 */
export const EDGE_TTS_VOICES: VoiceOption[] = [
  {
    id: 'vi-VN-HoaiMyNeural',
    shortName: 'vi-VN-HoaiMyNeural',
    name: 'Hoài My',
    tag: 'Nữ • Edge Neural Tự Nhiên',
    gender: 'female',
    region: 'Nam',
    locale: 'vi-VN',
    pitch: 1.0,
    rateMultiplier: 1.0,
    sampleText: 'Chào bạn, mình là Hoài My. Đây là giọng đọc Edge TTS truyền cảm tự nhiên của Microsoft.',
    description: 'Giọng đọc nữ Microsoft Edge Neural truyền cảm, ngữ điệu tự nhiên, chuẩn bản ngữ tiếng Việt.',
    audioSampleUrl: '/assets/audio/hoai-my.wav',
  },
  {
    id: 'vi-VN-NamMinhNeural',
    shortName: 'vi-VN-NamMinhNeural',
    name: 'Nam Minh',
    tag: 'Nam • Edge Neural Tự Nhiên',
    gender: 'male',
    region: 'Bắc',
    locale: 'vi-VN',
    pitch: 1.0,
    rateMultiplier: 1.0,
    sampleText: 'Tôi là Nam Minh. Mời quý đạo hữu cùng thưởng thức câu chuyện qua giọng đọc Edge TTS chân thực.',
    description: 'Giọng đọc nam Microsoft Edge Neural trầm ấm, đĩnh đạc, ngữ điệu tự nhiên chuẩn bản ngữ.',
    audioSampleUrl: '/assets/audio/nam-minh.wav',
  },
];

// Alias for existing references
export const VOICE_OPTIONS: VoiceOption[] = EDGE_TTS_VOICES;

/**
 * Chuẩn hóa mã giọng Edge TTS từ bất kỳ ID cũ nào
 */
export function normalizeEdgeVoiceId(voiceId?: string): string {
  if (!voiceId) return 'vi-VN-HoaiMyNeural';
  const lower = voiceId.toLowerCase();
  if (lower.includes('namminh') || lower === 'nam-minh' || lower.includes('minh-quan')) {
    return 'vi-VN-NamMinhNeural';
  }
  return 'vi-VN-HoaiMyNeural';
}

/**
 * Quét danh sách giọng tiếng Việt khả dụng thực tế từ Edge TTS qua API máy chủ
 */
let dynamicEdgeVoices: VoiceOption[] = [...EDGE_TTS_VOICES];

export async function fetchAvailableEdgeVoices(): Promise<VoiceOption[]> {
  try {
    const res = await fetch('/api/tts/voices');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    if (data.success && Array.isArray(data.voices) && data.voices.length > 0) {
      dynamicEdgeVoices = data.voices.map((v: any) => ({
        id: v.shortName || v.id,
        shortName: v.shortName || v.id,
        name: v.name || (v.gender === 'male' ? 'Nam Minh' : 'Hoài My'),
        tag: v.tag || (v.gender === 'male' ? 'Nam • Edge Neural Tự Nhiên' : 'Nữ • Edge Neural Tự Nhiên'),
        gender: v.gender || (v.id.includes('NamMinh') ? 'male' : 'female'),
        locale: v.locale || 'vi-VN',
        pitch: 1.0,
        rateMultiplier: 1.0,
        sampleText: v.sampleText || 'Đây là giọng đọc Edge TTS tự nhiên.',
        description: v.description || 'Giọng đọc Microsoft Edge Neural chuẩn bản ngữ tiếng Việt.',
      }));
      return dynamicEdgeVoices;
    }
  } catch (err) {
    console.warn('Không thể kết nối API quét giọng Edge TTS, sử dụng danh sách chuẩn:', err);
  }
  return dynamicEdgeVoices;
}

export function getLoadedEdgeVoices(): VoiceOption[] {
  return dynamicEdgeVoices;
}

/**
 * Tạo URL luồng âm thanh Edge TTS chất lượng cao
 */
export function getEdgeTtsAudioUrl(text: string, voiceId: string): string {
  const normalizedVoice = normalizeEdgeVoiceId(voiceId);
  return `/api/tts?text=${encodeURIComponent(text.trim())}&voice=${encodeURIComponent(normalizedVoice)}`;
}

/**
 * Tìm kiếm giọng đọc trong Web Speech API nếu offline
 */
let cachedVoices: SpeechSynthesisVoice[] = [];

if (typeof window !== 'undefined' && window.speechSynthesis) {
  cachedVoices = window.speechSynthesis.getVoices();
  window.speechSynthesis.onvoiceschanged = () => {
    cachedVoices = window.speechSynthesis.getVoices();
  };
}

export function getMatchingBrowserVoice(voiceId: string): SpeechSynthesisVoice | null {
  if (typeof window === 'undefined' || !window.speechSynthesis) return null;
  const voices = cachedVoices.length > 0 ? cachedVoices : window.speechSynthesis.getVoices();
  if (voices.length === 0) return null;

  const targetId = normalizeEdgeVoiceId(voiceId);
  const isMale = targetId === 'vi-VN-NamMinhNeural';

  // Tìm giọng Microsoft NamMinh hoặc HoaiMy trong trình duyệt
  const matched = voices.find((v) => {
    const name = v.name.toLowerCase();
    const isVi = v.lang.startsWith('vi') || v.lang.includes('VN');
    if (!isVi) return false;
    if (isMale) {
      return name.includes('namminh') || name.includes('nam minh') || name.includes('male') || name.includes('nam');
    }
    return name.includes('hoaimy') || name.includes('hoài my') || name.includes('female');
  });

  if (matched) return matched;

  // Fallback to any Vietnamese voice
  const viVoice = voices.find((v) => v.lang.startsWith('vi') || v.lang.includes('VN'));
  return viVoice || null;
}

let activeAudioSample: HTMLAudioElement | null = null;

export function stopVoiceSample() {
  if (activeAudioSample) {
    activeAudioSample.pause();
    activeAudioSample.currentTime = 0;
    activeAudioSample = null;
  }
  if (typeof window !== 'undefined' && window.speechSynthesis) {
    window.speechSynthesis.cancel();
  }
}

/**
 * Phát thử giọng đọc Edge TTS thực tế (truyền đúng mã voice vi-VN-HoaiMyNeural hoặc vi-VN-NamMinhNeural)
 */
export function playVoiceSample(voiceId: string) {
  if (typeof window === 'undefined') return;
  stopVoiceSample();

  const normalizedVoiceId = normalizeEdgeVoiceId(voiceId);
  const voice = dynamicEdgeVoices.find((v) => v.id === normalizedVoiceId) || dynamicEdgeVoices[0] || EDGE_TTS_VOICES[0];

  // 1. Ưu tiên phát file âm thanh mẫu chuẩn cục bộ (cực nhanh < 0.05s, không bị lag mạng)
  if (voice.audioSampleUrl) {
    try {
      const localAudio = new Audio(voice.audioSampleUrl);
      localAudio.volume = 1.0;
      activeAudioSample = localAudio;
      localAudio.play().then(() => {
        localAudio.onended = () => {
          if (activeAudioSample === localAudio) activeAudioSample = null;
        };
      }).catch(() => {
        // Nếu file cục bộ bị chặn, gọi API Edge TTS trực tuyến
        playOnlineEdgeSample(voice, normalizedVoiceId);
      });
      return;
    } catch (e) {
      console.warn('Lỗi audio cục bộ, chuyển online:', e);
    }
  }

  playOnlineEdgeSample(voice, normalizedVoiceId);
}

function playOnlineEdgeSample(voice: VoiceOption, normalizedVoiceId: string) {
  try {
    const audioUrl = getEdgeTtsAudioUrl(voice.sampleText, normalizedVoiceId);
    const audio = new Audio(audioUrl);
    audio.volume = 1.0;
    activeAudioSample = audio;
    audio.play().then(() => {
      audio.onended = () => {
        if (activeAudioSample === audio) activeAudioSample = null;
      };
    }).catch(() => {
      fallbackSpeechSample(voice);
    });
  } catch (e) {
    fallbackSpeechSample(voice);
  }
}

function fallbackSpeechSample(voice: VoiceOption) {
  if (!window.speechSynthesis) return;
  const utterance = new SpeechSynthesisUtterance(voice.sampleText);
  utterance.lang = 'vi-VN';
  utterance.pitch = 1.0;
  utterance.rate = 1.0;

  const matched = getMatchingBrowserVoice(voice.id);
  if (matched) {
    utterance.voice = matched;
  }

  window.speechSynthesis.speak(utterance);
}

/**
 * BÓC TÁCH VÀ TẠO CHƯƠNG HÀNG LOẠT (Batch Chapter Parser)
 */
export function parseBatchChapters(
  rawText: string,
  totalExistingChapters: number,
  expectedTotalChapters: number
): Chapter[] {
  if (!rawText.trim()) return [];

  const chapterRegex = /(?:===|\b)(?:Chương|Hồi)\s+(\d+)[:\s.-]*(.*?)(?:===|\n)([\s\S]*?)(?=(?:===|\b)(?:Chương|Hồi)\s+\d+|$)/gi;
  const parsedChapters: Chapter[] = [];
  let match;

  while ((match = chapterRegex.exec(rawText)) !== null) {
    const chapterNum = parseInt(match[1], 10);
    const chapterTitle = match[2]?.trim() || `Diễn biến hồi mục ${chapterNum}`;
    const chapterContent = match[3]?.trim() || 'Nội dung chương đang được cập nhật...';

    const { isVip, priceXu } = calculateChapterVip(chapterNum, expectedTotalChapters);

    parsedChapters.push({
      id: `batch-${chapterNum}-${Date.now()}`,
      number: chapterNum,
      title: `Chương ${chapterNum}: ${chapterTitle}`,
      slug: `chuong-${chapterNum}`,
      content: chapterContent,
      wordCount: chapterContent.split(/\s+/).length,
      publishedDate: new Date().toISOString().split('T')[0],
      isVip,
      priceXu,
    });
  }

  if (parsedChapters.length === 0) {
    const paragraphs = rawText.split(/\n\s*\n/).filter((p) => p.trim().length > 0);
    const paragraphsPerChapter = Math.max(3, Math.ceil(paragraphs.length / 5));

    for (let i = 0; i < paragraphs.length; i += paragraphsPerChapter) {
      const chapterNum = totalExistingChapters + parsedChapters.length + 1;
      const chunkContent = paragraphs.slice(i, i + paragraphsPerChapter).join('\n\n');
      const { isVip, priceXu } = calculateChapterVip(chapterNum, expectedTotalChapters);

      parsedChapters.push({
        id: `batch-${chapterNum}-${Date.now()}`,
        number: chapterNum,
        title: `Chương ${chapterNum}: Tình tiết tiếp nối hồi mục`,
        slug: `chuong-${chapterNum}`,
        content: chunkContent,
        wordCount: chunkContent.split(/\s+/).length,
        publishedDate: new Date().toISOString().split('T')[0],
        isVip,
        priceXu,
      });
    }
  }

  return parsedChapters;
}
