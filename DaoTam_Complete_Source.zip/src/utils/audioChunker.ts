/**
 * Audio Chunker Engine & AudioStreamer for Đạo Tâm
 * Tối ưu hóa Audio không độ trễ, không gián đoạn:
 * 1. Chunk đầu tiên (phần tử số 0) cực ngắn (dưới 50 ký tự) để phát tức thì 0s delay (<150ms)
 * 2. Các chunk tiếp theo (từ số 1 trở đi) dài 150 - 200 ký tự và được tải đệm ngầm (pre-fetch)
 * 3. Class AudioStreamer điều phối hàng đợi âm thanh và hỗ trợ tự động chuyển chương
 */

export interface AudioChunk {
  id: number;
  text: string;
  charStart: number;
  charEnd: number;
  rawText: string;
}

/**
 * Thuật toán Chunking thông minh loại bỏ độ trễ:
 * - Chunk 0: Cực ngắn (< 50 ký tự), tổng hợp siêu tốc để phát ngay lập tức khi bấm Play.
 * - Chunk 1 trở đi: Gộp câu 150 - 200 ký tự theo ngữ pháp tiếng Việt, tải ngầm khi Chunk 0 đang nói.
 */
export function chunkChapterContent(
  content: string, 
  idealMinLength: number = 100, 
  idealMaxLength: number = 190
): AudioChunk[] {
  if (!content || !content.trim()) return [];

  const rawParagraphs = content
    .split(/\r?\n+/)
    .map((p) => p.trim())
    .filter((p) => p.length > 0);

  if (rawParagraphs.length === 0) return [];

  const chunks: AudioChunk[] = [];
  let chunkIndex = 0;
  let runningCharOffset = 0;

  // 1. TẠO CHUNK ĐẦU TIÊN (INDEX 0) SIÊU NGẮN (< 50 KÝ TỰ) ĐỂ PHÁT NGAY LẬP TỨC 0s TRỄ
  const firstPara = rawParagraphs[0];
  const firstSentences = firstPara
    .split(/(?<=[.?!…;])\s+|(?<=[”"'])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  let remainingFirstPara = firstPara;
  if (firstSentences.length > 0) {
    const firstSentence = firstSentences[0];

    if (firstSentence.length <= 50) {
      // Câu đầu tiên đã <= 50 ký tự, dùng luôn làm chunk 0
      chunks.push({
        id: chunkIndex++,
        text: firstSentence,
        rawText: firstSentence,
        charStart: runningCharOffset,
        charEnd: runningCharOffset + firstSentence.length,
      });
      runningCharOffset += firstSentence.length + 1;
      remainingFirstPara = firstPara.slice(firstSentence.length).trim();
    } else {
      // Nếu câu đầu > 50 ký tự: Cắt tại dấu phẩy/hai chấm/gạch ngang đầu tiên, hoặc ngắt trước 50 ký tự
      const subClauses = firstSentence.split(/(?<=[,:;—–-])\s+/);
      let shortChunk = subClauses[0]?.trim() || '';

      if (shortChunk.length > 50) {
        // Cắt theo từ gần nhất dưới 50 ký tự
        const words = shortChunk.split(/\s+/);
        let buf = '';
        for (const w of words) {
          if (buf && buf.length + 1 + w.length > 48) break;
          buf = buf ? `${buf} ${w}` : w;
        }
        shortChunk = buf || shortChunk.slice(0, 48);
      }

      chunks.push({
        id: chunkIndex++,
        text: shortChunk,
        rawText: shortChunk,
        charStart: runningCharOffset,
        charEnd: runningCharOffset + shortChunk.length,
      });
      runningCharOffset += shortChunk.length + 1;
      remainingFirstPara = firstPara.slice(shortChunk.length).trim();
    }
  }

  // 2. XỬ LÝ CÁC ĐOẠN CÒN LẠI (TỪ CHUNK 1 TRỞ ĐI: 150 - 200 KÝ TỰ)
  const remainingParagraphs = remainingFirstPara 
    ? [remainingFirstPara, ...rawParagraphs.slice(1)]
    : rawParagraphs.slice(1);

  for (const para of remainingParagraphs) {
    const rawSentences = para
      .split(/(?<=[.?!…;])\s+|(?<=[”"'])\s+/)
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    let accumulator = '';
    let accStartOffset = runningCharOffset;

    for (let i = 0; i < rawSentences.length; i++) {
      const sentence = rawSentences[i];

      // Nếu câu dài hơn 200 ký tự, tách nhỏ theo dấu phẩy / gạch nối
      if (sentence.length > idealMaxLength) {
        if (accumulator.trim()) {
          const trimmed = accumulator.trim();
          chunks.push({
            id: chunkIndex++,
            text: trimmed,
            rawText: trimmed,
            charStart: accStartOffset,
            charEnd: accStartOffset + trimmed.length,
          });
          accStartOffset += accumulator.length + 1;
          accumulator = '';
        }

        const clauses = sentence
          .split(/(?<=[,:;—–])\s+/)
          .map((c) => c.trim())
          .filter(Boolean);

        let clauseBuffer = '';
        let clauseStartOffset = accStartOffset;

        for (const clause of clauses) {
          if (clauseBuffer && (clauseBuffer.length + clause.length > idealMaxLength)) {
            const trimmedClause = clauseBuffer.trim();
            chunks.push({
              id: chunkIndex++,
              text: trimmedClause,
              rawText: trimmedClause,
              charStart: clauseStartOffset,
              charEnd: clauseStartOffset + trimmedClause.length,
            });
            clauseStartOffset += clauseBuffer.length + 1;
            clauseBuffer = clause;
          } else {
            clauseBuffer = clauseBuffer ? `${clauseBuffer} ${clause}` : clause;
          }
        }

        if (clauseBuffer.trim()) {
          const trimmedClause = clauseBuffer.trim();
          chunks.push({
            id: chunkIndex++,
            text: trimmedClause,
            rawText: trimmedClause,
            charStart: clauseStartOffset,
            charEnd: clauseStartOffset + trimmedClause.length,
          });
          accStartOffset = clauseStartOffset + clauseBuffer.length + 1;
        }

        continue;
      }

      const prospectiveLength = accumulator ? accumulator.length + 1 + sentence.length : sentence.length;

      if (prospectiveLength <= idealMaxLength) {
        accumulator = accumulator ? `${accumulator} ${sentence}` : sentence;

        if (accumulator.length >= idealMinLength) {
          const trimmed = accumulator.trim();
          chunks.push({
            id: chunkIndex++,
            text: trimmed,
            rawText: trimmed,
            charStart: accStartOffset,
            charEnd: accStartOffset + trimmed.length,
          });
          accStartOffset += accumulator.length + 1;
          accumulator = '';
        }
      } else {
        if (accumulator.trim()) {
          const trimmed = accumulator.trim();
          chunks.push({
            id: chunkIndex++,
            text: trimmed,
            rawText: trimmed,
            charStart: accStartOffset,
            charEnd: accStartOffset + trimmed.length,
          });
          accStartOffset += accumulator.length + 1;
        }
        accumulator = sentence;
      }
    }

    if (accumulator.trim()) {
      const trimmed = accumulator.trim();
      chunks.push({
        id: chunkIndex++,
        text: trimmed,
        rawText: trimmed,
        charStart: accStartOffset,
        charEnd: accStartOffset + trimmed.length,
      });
      accStartOffset += accumulator.length + 1;
    }

    runningCharOffset += para.length + 1;
  }

  return chunks;
}

export const splitChapterIntoSpeechChunks = chunkChapterContent;

/**
 * Bộ nhớ đệm Audio RAM trình duyệt (Blob URL Cache)
 */
class SeamlessAudioCache {
  private blobUrls = new Map<string, string>();
  private activeFetches = new Map<string, Promise<string>>();

  private makeKey(voiceId: string, text: string): string {
    return `${voiceId}:::${text.trim()}`;
  }

  public has(voiceId: string, text: string): boolean {
    return this.blobUrls.has(this.makeKey(voiceId, text));
  }

  public get(voiceId: string, text: string): string | undefined {
    return this.blobUrls.get(this.makeKey(voiceId, text));
  }

  public async fetchAndCache(voiceId: string, text: string): Promise<string> {
    const key = this.makeKey(voiceId, text);

    if (this.blobUrls.has(key)) {
      return this.blobUrls.get(key)!;
    }

    if (this.activeFetches.has(key)) {
      return this.activeFetches.get(key)!;
    }

    const fetchPromise = (async () => {
      try {
        const url = `/api/tts?text=${encodeURIComponent(text.trim())}&voice=${encodeURIComponent(voiceId)}`;
        const response = await fetch(url);
        
        if (!response.ok) {
          throw new Error(`TTS API failed with status ${response.status}`);
        }

        const arrayBuffer = await response.arrayBuffer();
        if (arrayBuffer.byteLength < 100) {
          throw new Error('Dữ liệu âm thanh trả về không hợp lệ');
        }

        const blob = new Blob([arrayBuffer], { type: 'audio/mpeg' });
        const objectUrl = URL.createObjectURL(blob);
        this.blobUrls.set(key, objectUrl);
        return objectUrl;
      } finally {
        this.activeFetches.delete(key);
      }
    })();

    this.activeFetches.set(key, fetchPromise);
    return fetchPromise;
  }

  public clear(): void {
    for (const url of this.blobUrls.values()) {
      try {
        URL.revokeObjectURL(url);
      } catch (e) {}
    }
    this.blobUrls.clear();
    this.activeFetches.clear();
  }
}

export const seamlessAudioCache = new SeamlessAudioCache();

/**
 * Class AudioStreamer điều phối phát luồng âm thanh
 * - Hỗ trợ phát liền mạch không độ trễ
 * - Tự động tải đệm ngầm (lookahead prefetching)
 * - Tự động chuyển chương (autoNextChapter) khi đọc hết chương
 */
export class AudioStreamer {
  private audioElement: HTMLAudioElement;
  private voiceId: string;
  private playbackRate: number;
  private chunks: AudioChunk[] = [];
  private currentChunkIndex: number = -1;
  private isPlaying: boolean = false;
  private autoNextChapter: boolean = true;
  private onChunkChange?: (index: number, chunk: AudioChunk) => void;
  private onComplete?: () => void;
  private onNextChapter?: () => void;

  constructor(options?: {
    voiceId?: string;
    playbackRate?: number;
    autoNextChapter?: boolean;
    onChunkChange?: (index: number, chunk: AudioChunk) => void;
    onComplete?: () => void;
    onNextChapter?: () => void;
  }) {
    this.audioElement = new Audio();
    this.audioElement.preload = 'auto';
    this.voiceId = options?.voiceId || 'vi-VN-HoaiMyNeural';
    this.playbackRate = options?.playbackRate || 1.0;
    this.autoNextChapter = options?.autoNextChapter ?? true;
    this.onChunkChange = options?.onChunkChange;
    this.onComplete = options?.onComplete;
    this.onNextChapter = options?.onNextChapter;
  }

  public setContent(content: string) {
    this.chunks = chunkChapterContent(content);
    this.currentChunkIndex = -1;
  }

  public setAutoNextChapter(enabled: boolean) {
    this.autoNextChapter = enabled;
  }

  public setOnNextChapter(callback: () => void) {
    this.onNextChapter = callback;
  }

  public setVoiceId(voice: string) {
    this.voiceId = voice;
  }

  public setPlaybackRate(rate: number) {
    this.playbackRate = rate;
    this.audioElement.playbackRate = rate;
  }

  public getChunks(): AudioChunk[] {
    return this.chunks;
  }

  public getCurrentIndex(): number {
    return this.currentChunkIndex;
  }

  public async playChunk(index: number): Promise<void> {
    if (index < 0 || index >= this.chunks.length) {
      this.isPlaying = false;
      if (this.onComplete) this.onComplete();
      if (this.autoNextChapter && this.onNextChapter) {
        this.onNextChapter();
      }
      return;
    }

    const chunk = this.chunks[index];
    this.currentChunkIndex = index;
    if (this.onChunkChange) this.onChunkChange(index, chunk);

    // Tải đệm ngầm các câu tiếp theo (lookahead window = 2)
    if (index + 1 < this.chunks.length) {
      seamlessAudioCache.fetchAndCache(this.voiceId, this.chunks[index + 1].text).catch(() => {});
    }
    if (index + 2 < this.chunks.length) {
      seamlessAudioCache.fetchAndCache(this.voiceId, this.chunks[index + 2].text).catch(() => {});
    }

    try {
      const audioUrl = await seamlessAudioCache.fetchAndCache(this.voiceId, chunk.text);
      this.audioElement.pause();
      this.audioElement.src = audioUrl;
      this.audioElement.playbackRate = this.playbackRate;
      this.audioElement.load();

      this.audioElement.onended = () => {
        this.playChunk(index + 1);
      };

      this.audioElement.onerror = () => {
        console.warn(`[AudioStreamer] Error on chunk #${index}, skipping to next`);
        setTimeout(() => this.playChunk(index + 1), 200);
      };

      await this.audioElement.play();
      this.isPlaying = true;
    } catch (err) {
      console.warn(`[AudioStreamer] Play failed for chunk #${index}:`, err);
      // Tự động bỏ qua câu lỗi để luồng nghe không bị nghẽn
      setTimeout(() => this.playChunk(index + 1), 300);
    }
  }

  public async play(): Promise<void> {
    const startIndex = this.currentChunkIndex >= 0 ? this.currentChunkIndex : 0;
    await this.playChunk(startIndex);
  }

  public pause() {
    this.isPlaying = false;
    this.audioElement.pause();
  }

  public destroy() {
    this.pause();
    this.audioElement.src = '';
    seamlessAudioCache.clear();
  }
}
