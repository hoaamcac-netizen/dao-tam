import { GenreItem } from '../types';

export const INITIAL_HOT_GENRES: GenreItem[] = [
  { id: 'co-dai', name: 'Cổ Đại', iconName: 'Landmark', description: 'Bối cảnh thời phong kiến, triều đình, giang hồ cổ xưa' },
  { id: 'di-nang', name: 'Dị Năng', iconName: 'Zap', description: 'Năng lực siêu nhiên, siêu năng lực đột biến' },
  { id: 'fanfic', name: 'Fanfic', iconName: 'Feather', description: 'Đồng nhân sáng tác dựa trên nhân vật có sẵn' },
  { id: 'he-thong', name: 'Hệ Thống', iconName: 'Cpu', description: 'Nhân vật chính sở hữu hệ thống thông minh hỗ trợ' },
  { id: 'hien-dai', name: 'Hiện Đại', iconName: 'Building2', description: 'Bối cảnh xã hội ngày nay, đô thị phồn hoa' },
  { id: 'hoang-de', name: 'Hoàng Đế', iconName: 'Crown', description: 'Cung đình, tranh đoạt quyền vị, đế vương' },
  { id: 'huyen-huyen', name: 'Huyền Huyễn', iconName: 'Flame', description: 'Thế giới huyền bí, ma pháp, đấu khí kỳ ảo' },
  { id: 'khong-gian-tuy-than', name: 'Không Gian Tùy Thân', iconName: 'Box', description: 'Sở hữu không gian chứa đồ, linh tuyền riêng' },
  { id: 'kiem-hiep', name: 'Kiếm Hiệp', iconName: 'Swords', description: 'Võ lâm chính phái, kiếm hiệp tình duyên hào sảng' },
  { id: 'linh-di', name: 'Linh Dị', iconName: 'Ghost', description: 'Ma quái, bắt ma, phong thủy kinh dị rùng rợn' },
  { id: 'mat-the', name: 'Mạt Thế', iconName: 'Biohazard', description: 'Thế giới suy tàn, zombie, sinh tồn khắc nghiệt' },
  { id: 'ngon-tinh', name: 'Ngôn Tình', iconName: 'Heart', description: 'Tình cảm lãng mạn sâu sắc giữa nam và nữ' },
  { id: 'ngot-sung', name: 'Ngọt Sủng', iconName: 'Smile', description: 'Tình yêu ngọt ngào, cưng chiều hết mực, không ngược' },
  { id: 'nu-cuong', name: 'Nữ Cường', iconName: 'ShieldAlert', description: 'Nữ chính thông minh, độc lập, bản lĩnh xuất chúng' },
  { id: 'quan-nhan', name: 'Quân Nhân', iconName: 'Award', description: 'Nhân vật chính phục vụ trong quân ngũ, kỷ luật thép' },
  { id: 'sat-thu', name: 'Sát Thủ', iconName: 'Target', description: 'Sát thủ chuyên nghiệp, võ công lãnh khốc' },
  { id: 'sung-thu', name: 'Sủng Thú', iconName: 'PawPrint', description: 'Nuôi dưỡng linh thú, thần thú đáng yêu đồng hành' },
  { id: 'tan-the', name: 'Tận Thế', iconName: 'AlertTriangle', description: 'Ngày tận thế của nhân loại, hiểm họa diệt vong' },
  { id: 'thap-nien', name: 'Thập Niên', iconName: 'Calendar', description: 'Bối cảnh thập niên 60, 70, 80 lập nghiệp' },
  { id: 'thu-nhan', name: 'Thú Nhân', iconName: 'Dog', description: 'Thế giới biến hình nửa người nửa thú dã tính' },
  { id: 'trong-sinh', name: 'Trọng Sinh', iconName: 'RotateCcw', description: 'Chết đi sống lại kiếp trước để làm lại cuộc đời' },
  { id: 'tu-tien', name: 'Tu Tiên', iconName: 'Mountain', description: 'Luyện khí, trúc cơ, kết đan, phi thăng tiên giới' },
  { id: 'xuyen-khong', name: 'Xuyên Không', iconName: 'Hourglass', description: 'Xuyên qua thời không khác, nhập vào thân xác mới' },
];

export const HOT_GENRES = INITIAL_HOT_GENRES;

const STORAGE_KEY = 'dao_tam_genres_v2';

export function getStoredGenres(): GenreItem[] {
  if (typeof window === 'undefined') return INITIAL_HOT_GENRES;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.warn('Failed to parse stored genres', e);
  }
  return INITIAL_HOT_GENRES;
}

export function saveGenres(genres: GenreItem[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(genres));
  } catch (e) {
    console.warn('Failed to save genres to localStorage', e);
  }
}

/**
 * Tự động tạo thể loại mới đúng chuẩn cấu trúc GenreItem
 */
export function createGenreItem(name: string, description?: string): GenreItem {
  const trimmed = name.trim();
  const slug = trimmed
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-');

  const id = `genre-${slug || Date.now()}`;

  // Tự động phân bổ icon tương thích ngữ nghĩa
  let iconName = 'Tag';
  const lower = trimmed.toLowerCase();
  if (lower.includes('tiên') || lower.includes('tu')) iconName = 'Mountain';
  else if (lower.includes('kiếm') || lower.includes('võ')) iconName = 'Swords';
  else if (lower.includes('ma') || lower.includes('quỷ') || lower.includes('linh')) iconName = 'Ghost';
  else if (lower.includes('yêu') || lower.includes('tình') || lower.includes('hôn')) iconName = 'Heart';
  else if (lower.includes('thực') || lower.includes('ăn')) iconName = 'Smile';
  else if (lower.includes('hoàng') || lower.includes('cung') || lower.includes('vương')) iconName = 'Crown';
  else if (lower.includes('thời') || lower.includes('xuyên') || lower.includes('sinh')) iconName = 'Hourglass';
  else if (lower.includes('thú') || lower.includes('mèo') || lower.includes('chó')) iconName = 'PawPrint';
  else if (lower.includes('hệ thống') || lower.includes('game') || lower.includes('võng')) iconName = 'Cpu';
  else if (lower.includes('khoa') || lower.includes('huyễn') || lower.includes('tinh')) iconName = 'Flame';

  return {
    id,
    name: trimmed,
    iconName,
    description: description || `Thể loại ${trimmed} thuộc thư viện Đạo Tâm`,
    isCustom: true,
  };
}
