import { Novel } from '../types';
import { calculateChapterVip } from '../utils/rulesAndVoices';

function generateChapters(novelId: string, totalCount: number, sampleContentGenerator: (n: number) => string) {
  const chapters = [];
  const limit = Math.min(totalCount, 60);
  for (let i = 1; i <= limit; i++) {
    const { isVip, priceXu } = calculateChapterVip(i, totalCount);
    chapters.push({
      id: `${novelId}-c${i}`,
      number: i,
      title: `Chương ${i}: ${
        i === 1 ? 'Khởi đầu định mệnh và sự thức tỉnh'
        : i === 2 ? 'Làn sóng ngầm nơi thâm cung nội viện'
        : i === 30 ? 'Bước ngoặt trước ngưỡng cửa số phận'
        : i === 31 ? 'Biến cố kinh hoàng (Khởi đầu VIP truyện ngắn)'
        : i === 50 ? 'Giao tranh quyết liệt tại đỉnh phong'
        : i === 51 ? 'Bí mật kinh thiên động địa (Khởi đầu VIP truyện dài)'
        : `Diễn biến gay cấn hồi mục ${i}`
      }`,
      slug: `chuong-${i}`,
      wordCount: 3100 + ((i * 37) % 700),
      publishedDate: '2026-10-28',
      isVip,
      priceXu,
      content: sampleContentGenerator(i),
    });
  }
  return chapters;
}

export const SAMPLE_NOVELS: Novel[] = [
  // ==================== 1. ĐAM MỸ ====================
  {
    id: 'xuyen-nhanh-nam-chinh-hac-hoa',
    title: 'Xuyên Nhanh: Nam Chính Hắc Hóa Lại Muốn Cường Chế Tôi',
    slug: 'xuyen-nhanh-nam-chinh-hac-hoa',
    author: 'Cố Niệm Niệm',
    coverImage: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=700&q=80',
    mainCategory: 'dam-my',
    status: 'Đang ra',
    isHot: true,
    totalChapters: 182, // < 200 chương => VIP từ c31
    views: 128400,
    dailyViews: 12450,
    rating: 4.9,
    categories: ['Đam Mỹ', 'Xuyên Không', 'Hệ Thống', 'Ngọt Sủng', 'Trọng Sinh'],
    description: 'Bạch Duật là một ký chủ chuyên nghiệp của Cục Quản Lý Thời Không. Nhiệm vụ của cậu là cứu rỗi những nam phụ thê thảm hoặc kéo các nam chính lạc lối trở lại quỹ đạo. Thế nhưng chẳng hiểu sao, mỗi lần hoàn thành nhiệm vụ chuẩn bị rút lui, các nam chính đáng lẽ phải chính trực quang minh lại biến chất, ánh mắt tối sầm khóa chặt lấy cậu trong góc phòng: "Duật Duật, ngươi lại muốn bỏ trốn đi đâu?"',
    translator: 'Đạo Tâm Team',
    updatedAt: Date.now() - 15 * 60 * 1000,
    lastUpdated: '15 phút trước',
    hasAudio: true,
    flowerCount: 1540,
    fullBookPriceXu: 120,
    fullBookDiscountPriceXu: 90,
    chapters: generateChapters('xnhh', 182, (i) => 
      `Ánh đèn vàng nhạt hắt lên khung cửa sổ sát đất, đổ bóng người đàn ông cao lớn lên mặt thảm len dày dặn. 

Bạch Duật giật mình tỉnh dậy, sau gáy truyền đến từng cơn đau nhức nhối. Cậu theo bản năng cử động cổ tay, lập tức nghe thấy tiếng xích kim loại va chạm leng keng đầy lạnh lẽo.

Hệ thống 007 trong tâm trí khẽ rung lên. Chúc mừng ký chủ đã thức tỉnh tại thế giới S-01: Tổng tài bá đạo và chú chim trong lồng son.

Bạch Duật khẽ nhíu mày, giọng điệu trong thức hải vẫn bình tĩnh lạ kỳ. "007, tình huống này là sao? Nhiệm vụ cứu vớt độ hảo cảm không phải đã đạt 99% rồi à? Sao ta lại bị khóa ở đây?"

Hệ thống 007 ngập ngừng đáp. "Ký chủ, độ hảo cảm đã đạt 100%, nhưng chỉ số hắc hóa của mục tiêu Phó Cảnh Thâm đột ngột tăng vọt lên 200%."`
    ),
  },
  {
    id: 'su-ton-luon-nho-thuong-cai-dau-cua-ta',
    title: 'Sư Tôn Luôn Nhớ Thương Cái Đầu Của Ta',
    slug: 'su-ton-luon-nho-thuong-cai-dau-cua-ta',
    author: 'Nhất Trản Thanh Đăng',
    coverImage: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=700&q=80',
    mainCategory: 'dam-my',
    status: 'Hoàn thành',
    isHot: true,
    totalChapters: 245, // > 200 chương => VIP từ c51
    views: 115200,
    dailyViews: 11200,
    rating: 4.8,
    categories: ['Đam Mỹ', 'Tu Tiên', 'Xuyên Không', 'Cổ Đại', 'Huyền Huyễn'],
    description: 'Diệp Lạc xuyên thành đại đồ đệ của Tiêu Dao Tông, vốn định an phận làm một kẻ ăn no chờ chết. Nào ngờ y phát hiện ra sư tôn cao lãnh chi hoa của mình dường như mắc bệnh sạch sẽ giai đoạn cuối, lại còn có thói quen mỗi khi nhìn thấy y là tay áo khẽ động, kiếm khí lạnh buốt muốn gọt bay chiếc đầu lâu trên cổ y!',
    translator: 'Mộng Đàm Team',
    updatedAt: Date.now() - 45 * 60 * 1000,
    lastUpdated: '45 phút trước',
    hasAudio: true,
    flowerCount: 1390,
    fullBookPriceXu: 150,
    fullBookDiscountPriceXu: 105,
    chapters: generateChapters('stdt', 245, (i) => 
      `Gió lạnh rít gào trên đỉnh Lăng Tiêu Phong. Băng tuyết nghìn năm phủ trắng xóa từng rặng thông già cỗi.

Diệp Lạc quỳ trên sàn ngọc thạch lạnh buốt thấu xương, trán rịn ra một tầng mồ hôi hột. Y không dám ngẩng đầu, bởi vì y cảm nhận rất rõ luồng kiếm khí sắc bén như lông tơ đang lơ lửng ngay sau gáy mình.

Phía trước, trên bảo tọa bạch ngọc, một bóng người mặc trường bào nguyệt sắc thanh khiết như tuyết đầu mùa. Đó chính là Lãnh Nguyệt Kiếm Tôn — Thẩm Vọng Trần.`
    ),
  },
  {
    id: 'vuong-gia-rat-biet-do-nguoi',
    title: 'Vương Gia Rất Biết Dỗ Người',
    slug: 'vuong-gia-rat-biet-do-nguoi',
    author: 'Nam Phong Ca',
    coverImage: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=700&q=80',
    mainCategory: 'dam-my',
    status: 'Hoàn thành',
    isHot: true,
    totalChapters: 239, // > 200 chương => VIP từ c51
    views: 98600,
    dailyViews: 9850,
    rating: 4.9,
    categories: ['Đam Mỹ', 'Cổ Đại', 'Hoàng Đế', 'Trọng Sinh', 'Ngọt Sủng'],
    description: 'Đời trước Lâm Trĩ ngốc nghếch tin lời tra nam, kết cục cả gia tộc bị chém đầu, bản thân chết rũ trong lãnh cung lạnh giá. Sống lại một đời vào đúng ngày kiệu hoa gả vào phủ Ninh Vương — vị chiến thần mặt lạnh tàn tật ai ai cũng khiếp sợ.',
    translator: 'Đạo Tâm Team',
    updatedAt: Date.now() - 2 * 3600 * 1000,
    lastUpdated: '2 giờ trước',
    hasAudio: true,
    flowerCount: 1240,
    fullBookPriceXu: 140,
    fullBookDiscountPriceXu: 95,
    chapters: generateChapters('vgrbd', 239, (i) => 
      `Tiếng pháo nổ giòn giã ngoài ngõ xa dần. Căn phòng hỷ rực rỡ ánh nến long phụng đỏ thẫm chiếu rọi bóng người mảnh mai đang ngồi trên mép giường.

Lâm Trĩ siết chặt hai vạt áo cưới thêu kim tuyến, lồng ngực đập thình thịch. Y thật sự đã sống lại rồi.`
    ),
  },
  {
    id: 'xuyen-thanh-thu-nhan-sieu-cap',
    title: 'Xuyên Thành Thú Nhân: Được Đại Lão Sủng Lên Trời',
    slug: 'xuyen-thanh-thu-nhan-duoc-dai-lao-sung-len-troi',
    author: 'Miêu Tử Tương',
    coverImage: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=700&q=80',
    mainCategory: 'dam-my',
    status: 'Đang ra',
    isHot: false,
    totalChapters: 160,
    views: 73000,
    dailyViews: 7100,
    rating: 4.9,
    categories: ['Đam Mỹ', 'Thú Nhân', 'Sủng Thú', 'Xuyên Không', 'Ngọt Sủng', 'Fanfic'],
    description: 'Bác sĩ thú y Tô Mục vô tình xuyên không đến tinh cầu thú nhân nguyên thủy, bất đắc dĩ hóa thành một bé sóc bay lông xù mềm mại, bị vị vương giả sư tử tuyết hung bạo nhặt về sủng ái.',
    translator: 'Mộng Đàm Team',
    updatedAt: Date.now() - 6 * 3600 * 1000,
    lastUpdated: '6 giờ trước',
    hasAudio: true,
    flowerCount: 910,
    fullBookPriceXu: 110,
    fullBookDiscountPriceXu: 80,
    chapters: generateChapters('tnsl', 160, (i) => 
      `Tô Mục ngơ ngác nhìn hai cái móng vuốt lông xù màu xám tro của mình. Cậu vừa chớp mắt một cái, một bóng đen khổng lồ đã ập tới, một chiếc lưỡi ráp ấm áp liếm láp qua trán cậu...`
    ),
  },

  // ==================== 2. TRUYỆN NAM ====================
  {
    id: 'dao-quan-bot-gian-ta-cong-luoc-nham-nguoi-roi',
    title: 'Vạn Cổ Thần Đế: Nhất Kiếm Phá Vạn Giới',
    slug: 'van-co-than-de-nhat-kiem-pha-van-gioi',
    author: 'Phi Thiên Ngư',
    coverImage: 'https://images.unsplash.com/photo-1514539079130-25950c84af65?auto=format&fit=crop&w=700&q=80',
    mainCategory: 'truyen-nam',
    status: 'Đang ra',
    isHot: true,
    totalChapters: 350, // > 200 chương => VIP từ c51
    views: 142000,
    dailyViews: 13800,
    rating: 4.9,
    categories: ['Truyện Nam', 'Tu Tiên', 'Huyền Huyễn', 'Kiếm Hiệp', 'Trọng Sinh'],
    description: 'Tám trăm năm trước, Minh Đế chi tử Trương Nhược Trần bị vị hôn thê là Trì Dao công chúa sát hại. Tám trăm năm sau, Trương Nhược Trần tái sinh, phát hiện năm xưa người sát hại mình đã thống nhất Côn Lôn Giới, trở thành đệ nhất nữ hoàng uy chấn cửu châu. Mang theo cừu hận cùng chí bảo Thần Độ Luân Hồi, hắn bước lên con đường nghịch thiên đoạt mệnh!',
    translator: 'Bản dịch chính quy',
    updatedAt: Date.now() - 30 * 60 * 1000,
    lastUpdated: '30 phút trước',
    hasAudio: true,
    flowerCount: 1310,
    fullBookPriceXu: 180,
    fullBookDiscountPriceXu: 120,
    chapters: generateChapters('vctd', 350, (i) => 
      `Thiên địa mịt mờ, ráng chiều đổ máu trên đỉnh Côn Lôn. 

Trương Nhược Trần chậm rãi mở mắt, hơi thở phả ra làn khói trắng lạnh ngắt giữa gió đông tuyết phủ. Linh hồn hắn đã ngủ vùi suốt tám trăm năm đằng đẵng trong luân hồi tịch mịch, nay cuối cùng cũng trùng sinh vào thân xác một thiếu niên ốm yếu nơi biên cương Vân Võ Quận Quốc.

Bên ngoài trướng bạt, tiếng binh khí va chạm rền vang. Hắn siết chặt nắm đấm, đáy mắt lóe lên ngọn lửa kiên nghị ngút trời: "Trì Dao, tám trăm năm trước món nợ máu nàng nợ ta, kiếp này ta ắt sẽ bắt nàng hoàn trả gấp mười!"`
    ),
  },
  {
    id: 'toan-cau-cao-vo',
    title: 'Toàn Cầu Cao Võ: Ta Dùng Khí Huyết Chấn Sơn Hà',
    slug: 'toan-cau-cao-vo',
    author: 'Lão Ưng Cật Tiểu Kê',
    coverImage: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=700&q=80',
    mainCategory: 'truyen-nam',
    status: 'Hoàn thành',
    isHot: true,
    totalChapters: 420, // > 200 chương => VIP từ c51
    views: 135000,
    dailyViews: 12900,
    rating: 4.8,
    categories: ['Truyện Nam', 'Dị Năng', 'Hệ Thống', 'Hiện Đại', 'Trọng Sinh'],
    description: 'Trùng sinh trở lại những năm tháng chuẩn bị thi đại học, Phương Bình vốn tưởng mình có thể dựa vào kiến thức tương lai để làm giàu. Nào ngờ thế giới này không giống như trước: Nơi đây địa quật hoành hành, võ đạo vi tôn, võ giả quyền khuynh thiên hạ, bay trên trời lặn dưới biển! Dựa vào hệ thống khí huyết nghịch thiên, Phương Bình bắt đầu hành trình từ học sinh nghèo thành chiến thần nhân loại.',
    translator: 'Chiến Thần Team',
    updatedAt: Date.now() - 3 * 3600 * 1000,
    lastUpdated: '3 giờ trước',
    hasAudio: true,
    flowerCount: 1180,
    fullBookPriceXu: 190,
    fullBookDiscountPriceXu: 130,
    chapters: generateChapters('tgcv', 420, (i) => 
      `Tiếng ve sầu kêu râm ran ngoài tán cây ngô đồng mùa hạ. Phương Bình trợn tròn mắt nhìn tấm bảng đen phía trước lớp học, nơi thầy giáo chủ nhiệm đang phấn chấn viết bằng phấn đỏ: "Kỳ thi Võ khoa năm nay, tiêu chuẩn khí huyết tối thiểu là 110卡!"

Phương Bình dụi mắt ba lần: "Võ khoa? Khí huyết? Chẳng lẽ ta xuyên qua thế giới tu chân rồi sao?"`
    ),
  },
  {
    id: 'mat-the-khong-gian-tuy-than',
    title: 'Trọng Sinh Mạt Thế: Ta Có Không Gian Tùy Thân Trữ Vạn Tấn Hàng',
    slug: 'trong-sinh-mat-the-ta-co-khong-gian-tuy-than',
    author: 'Phong Hỏa Hí Chư Hầu',
    coverImage: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=700&q=80',
    mainCategory: 'truyen-nam',
    status: 'Đang ra',
    isHot: true,
    totalChapters: 210,
    views: 91000,
    dailyViews: 8900,
    rating: 4.9,
    categories: ['Truyện Nam', 'Mạt Thế', 'Tận Thế', 'Không Gian Tùy Thân', 'Dị Năng', 'Trọng Sinh'],
    description: 'Trước ngày tận thế một tháng, Lục Trầm sống lại kiếp trước khi thảm họa zombie bùng nổ. Mang theo không gian tùy thân vô hạn dung tích, hắn điên cuồng vơ vét hàng trăm tỷ tiền vật tư, xây dựng pháo đài thép bất khả xâm phạm!',
    translator: 'Chiến Thần Team',
    updatedAt: Date.now() - 2 * 3600 * 1000,
    lastUpdated: '2 giờ trước',
    hasAudio: true,
    flowerCount: 1050,
    fullBookPriceXu: 130,
    fullBookDiscountPriceXu: 90,
    chapters: generateChapters('mtkg', 210, (i) => 
      `Tách! Đồng hồ trên tường điểm đúng 0 giờ đêm ngày 15 tháng 8. Lục Trầm bật dậy trên giường, mồ hôi đầm đìa, hai mắt đỏ ngầu nhìn chiếc nhẫn ngọc bích phát sáng trên ngón tay trỏ...`
    ),
  },
  {
    id: 'ta-co-mot-toa-khung-bo-oc',
    title: 'Ta Có Một Toà Nhà Ma Kinh Dị',
    slug: 'ta-co-mot-toa-nha-ma-kinh-di',
    author: 'Hội Thuyết Thoại Đích Trửu Tử',
    coverImage: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=700&q=80',
    mainCategory: 'truyen-nam',
    status: 'Đang ra',
    isHot: false,
    totalChapters: 195, // < 200 chương => VIP từ c31
    views: 67000,
    dailyViews: 6400,
    rating: 4.9,
    categories: ['Truyện Nam', 'Linh Dị', 'Hệ Thống', 'Hiện Đại'],
    description: 'Trần Ca thừa kế công viên nhà ma sắp phá sản của cha mẹ để lại. Tình cờ phát hiện ra chiếc điện thoại màu đen bí ẩn, mỗi khi hoàn thành nhiệm vụ kinh dị trong thế giới thực, hắn có thể mở rộng nhà ma và thu phục những lệ quỷ rùng rợn nhất.',
    translator: 'Linh Dị Quán',
    updatedAt: Date.now() - 5 * 3600 * 1000,
    lastUpdated: '5 giờ trước',
    hasAudio: true,
    flowerCount: 760,
    fullBookPriceXu: 115,
    fullBookDiscountPriceXu: 85,
    chapters: generateChapters('tcnm', 195, (i) => 
      `Ánh trăng nhợt nhạt chiếu qua khe cửa sắt rỉ sét của công viên giải trí Tây Giao. Trần Ca cầm chiếc cờ lê nặng trịch trong tay, đi chậm rãi dọc theo dãy hành lang u tối của khu nhà ma bỏ hoang.`
    ),
  },

  // ==================== 3. TRUYỆN NỮ ====================
  {
    id: 'xuyen-thanh-hoang-tu-ngoc-ga-thay',
    title: 'Gả Cho Bạo Quân Tàn Tật, Ta Được Cưng Chiều Tận Trời',
    slug: 'ga-cho-bao-quan-tan-tat-ta-duoc-cung-chieu-tan-troi',
    author: 'Thanh Thảo Manh',
    coverImage: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=700&q=80',
    mainCategory: 'truyen-nu',
    status: 'Hoàn thành',
    isHot: true,
    totalChapters: 267, // > 200 chương => VIP từ c51
    views: 118000,
    dailyViews: 11500,
    rating: 4.9,
    categories: ['Truyện Nữ', 'Cổ Đại', 'Hoàng Đế', 'Ngôn Tình', 'Trọng Sinh', 'Ngọt Sủng', 'Nữ Cường'],
    description: 'Đời trước nàng bị đích muội và mẹ kế hãm hại gả thay vào phủ Nhiếp Chính Vương tàn bạo, ai nấy đều tưởng nàng sẽ chết không toàn thây. Nào ngờ vị Nhiếp Chính Vương liệt chân ấy lại nâng niu nàng trong lòng bàn tay, vì nàng mà dẹp yên phản loạn, quét sạch gian thần, đội lên đầu nàng chiếc mũ phượng tôn quý nhất cửu châu!',
    translator: 'Đạo Tâm Team',
    updatedAt: Date.now() - 1 * 3600 * 1000,
    lastUpdated: '1 giờ trước',
    hasAudio: true,
    flowerCount: 1470,
    fullBookPriceXu: 160,
    fullBookDiscountPriceXu: 110,
    chapters: generateChapters('gcby', 267, (i) => 
      `Kiệu hoa rung lắc trên con đường đá phủ đầy hoa đào rơi. Khương Ninh đưa tay vén nhẹ chiếc khăn voan đỏ thêu chỉ vàng, ánh mắt tĩnh lặng không gợn sóng.

Sống lại một đời vào đúng ngày đại hôn gả thay cho vị Diêm Vương sống quyền khuynh triều dã Tạ Yến, khóe môi nàng khẽ nhếch lên nụ cười bình thản: "Đích muội, món quà này của ngươi, đời này Khương Ninh ta xin nhận lấy!"`
    ),
  },
  {
    id: 'tro-ve-thap-nien-80-nu-cuong',
    title: 'Trở Về Thập Niên 80: Nữ Cường Làm Giàu Nuôi Ba Con Cưng',
    slug: 'tro-ve-thap-nien-80-nu-cuong-lam-giau',
    author: 'Lục Nguyệt Tuyết',
    coverImage: 'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?auto=format&fit=crop&w=700&q=80',
    mainCategory: 'truyen-nu',
    status: 'Hoàn thành',
    isHot: true,
    totalChapters: 215,
    views: 95000,
    dailyViews: 9300,
    rating: 4.8,
    categories: ['Truyện Nữ', 'Thập Niên', 'Quân Nhân', 'Nữ Cường', 'Hiện Đại', 'Trọng Sinh', 'Ngôn Tình'],
    description: 'Doanh nhân tỷ phú Thẩm Thanh Đường bất ngờ chết vì làm việc quá sức, mở mắt ra phát hiện mình đã quay trở lại năm 1982 tại một vùng quê nghèo, bên cạnh là người chồng quân nhân lạnh lùng cùng ba đứa con nheo nhóc.',
    translator: 'Đạo Tâm Team',
    updatedAt: Date.now() - 4 * 3600 * 1000,
    lastUpdated: '4 giờ trước',
    hasAudio: true,
    flowerCount: 980,
    fullBookPriceXu: 135,
    fullBookDiscountPriceXu: 95,
    chapters: generateChapters('tn80', 215, (i) => 
      `Tiếng gà gáy sáng vang lên từ chuồng tre sau nhà. Thẩm Thanh Đường sờ vào chiếc chăn bông vá víu chằng chịt, mùi rơm rạ khô thoang thoảng phả vào cánh mũi...`
    ),
  },
  {
    id: 'tuyet-sac-sat-thu-xuyen-khong',
    title: 'Tuyệt Sắc Sát Thủ: Khuynh Đảo Hoàng Đình',
    slug: 'tuyet-sac-sat-thu-khuynh-dao-hoang-dinh',
    author: 'Thiên Sơn Trà',
    coverImage: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=700&q=80',
    mainCategory: 'truyen-nu',
    status: 'Đang ra',
    isHot: false,
    totalChapters: 175,
    views: 82000,
    dailyViews: 8100,
    rating: 4.9,
    categories: ['Truyện Nữ', 'Sát Thủ', 'Xuyên Không', 'Cổ Đại', 'Nữ Cường', 'Hoàng Đế'],
    description: 'Đệ nhất sát thủ thế giới ngầm hy sinh trong lúc làm nhiệm vụ, linh hồn nhập vào vị tiểu thư phế vật bị ruồng bỏ của phủ Thừa tướng. Cầm kiếm đoạt mệnh, nàng từng bước giẫm đạp lên những kẻ phản bội!',
    translator: 'Yên Vũ Các',
    updatedAt: Date.now() - 7 * 3600 * 1000,
    lastUpdated: '7 giờ trước',
    hasAudio: true,
    flowerCount: 840,
    fullBookPriceXu: 110,
    fullBookDiscountPriceXu: 80,
    chapters: generateChapters('stkd', 175, (i) => 
      `Băng đăng lạnh giá chiếu rọi mặt nước hồ sâu thẳm. Lãnh Nguyệt mở mắt ngoi lên khỏi mặt nước, ánh mắt sắc như lưỡi dao găm chém đứt màn sương đêm.`
    ),
  },

  // ==================== 4. TRUYỆN SÁNG TÁC ====================
  {
    id: 'mong-hoa-luc-ky-sang-tac',
    title: 'Mộng Hoa Lục Ký: Vạn Dặm Hồng Trần Tìm Ngươi',
    slug: 'mong-hoa-luc-ky-van-dam-hong-tran-tim-nguoi',
    author: 'Bạch Nguyệt Quang',
    editor: 'Mộng Các Chủ',
    publisherRoles: ['author', 'editor'], // Tác giả và Editor
    coverImage: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=700&q=80',
    mainCategory: 'truyen-sang-tac',
    isOriginal: true,
    status: 'Đang ra',
    isHot: true,
    totalChapters: 180,
    views: 125000,
    dailyViews: 14500,
    rating: 5.0,
    categories: ['Truyện Sáng Tác', 'Cổ Đại', 'Tu Tiên', 'Ngọt Sủng', 'Trọng Sinh'],
    description: 'Tác phẩm tự sáng tác chính chủ của tác giả Đạo Tâm. Câu chuyện kể về hành trình nghịch thiên cải mệnh, một đời phong hoa tuyết nguyệt tìm lại người thương nơi biển người mênh mông.',
    translator: 'Chính chủ sáng tác & biên tập',
    updatedAt: Date.now() - 1 * 3600 * 1000,
    lastUpdated: '1 giờ trước',
    hasAudio: true,
    flowerCount: 1680,
    fullBookPriceXu: 125,
    fullBookDiscountPriceXu: 90,
    chapters: generateChapters('mhlk', 180, (i) =>
      `Gió thổi tung bay vạt áo lụa trắng nơi đình hoa quế. Hắn nâng chén quỳnh tương, ánh mắt xa xăm nhìn về chân trời nơi ngọn tiên sơn phủ đầy tuyết trắng ngàn năm...`
    ),
  },
  {
    id: 'hac-nguyet-quang-trong-sinh',
    title: 'Hắc Nguyệt Quang Cầm Kiếm Nghịch Thiên',
    slug: 'hac-nguyet-quang-cam-kiem-nghich-thien',
    author: 'Cửu Vĩ Linh Hồ',
    publisherRoles: ['author'], // Tác giả
    coverImage: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=700&q=80',
    mainCategory: 'truyen-sang-tac',
    isOriginal: true,
    status: 'Hoàn thành',
    isHot: true,
    totalChapters: 120,
    views: 98000,
    dailyViews: 9200,
    rating: 4.9,
    categories: ['Truyện Sáng Tác', 'Dị Năng', 'Huyền Huyễn', 'Nữ Cường'],
    description: 'Tiểu thuyết tự sáng tác đặc sắc. Trải qua kiếp nạn bị tông môn phản bội, nữ chính trùng sinh trở lại với dị năng phong ấn thượng cổ, thề quét sạch mọi ân oán tiền kiếp.',
    translator: 'Tác giả độc quyền',
    updatedAt: Date.now() - 3 * 3600 * 1000,
    lastUpdated: '3 giờ trước',
    hasAudio: true,
    flowerCount: 1120,
    fullBookPriceXu: 95,
    fullBookDiscountPriceXu: 70,
    chapters: generateChapters('hnqcs', 120, (i) =>
      `Sấm sét xé toạc tầng mây đen kịt. Nàng đứng trên vách đá Tử Vân, thanh bảo kiếm trong tay lóe lên luồng linh quang tím biếc sắc bén lạ thường...`
    ),
  },
];
