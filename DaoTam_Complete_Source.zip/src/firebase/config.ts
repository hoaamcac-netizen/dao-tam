import { initializeApp, getApps } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import { getAnalytics } from "firebase/analytics";
import firebaseAppletConfig from '../../firebase-applet-config.json';

// Khởi tạo Firebase với đúng cấu hình và Firestore Database ID của dự án
const app = getApps().length === 0 ? initializeApp(firebaseAppletConfig) : getApps()[0];
export const analytics = typeof window !== 'undefined' ? getAnalytics(app) : null;

export const db = getFirestore(app, firebaseAppletConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

// Danh sách email Quản Trị Viên (Admin)
export const ADMIN_EMAILS: string[] = [
  'banhbarook@gmail.com', // Tài khoản người dùng đang đăng nhập / Quản trị viên
  'meoyeutien22@gmail.com',
  'meoghientruyen@gmail.com',
  'hoaamcac@gmail.com',
  'dauanhoanggia1@gmail.com',
  'pkimc2210@gmail.com',
];

export function checkIsAdmin(email?: string | null): boolean {
  if (!email) return false;
  return ADMIN_EMAILS.some((adminEmail) => adminEmail.toLowerCase().trim() === email.toLowerCase().trim());
}

// Kiểm tra kết nối Firestore khi khởi động app
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase is offline, check connection/credentials.');
    }
  }
}
testConnection();
