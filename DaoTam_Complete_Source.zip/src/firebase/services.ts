import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  addDoc,
  updateDoc, 
  deleteDoc,
  query, 
  where,
  orderBy, 
  onSnapshot,
  arrayUnion,
  arrayRemove
} from 'firebase/firestore';
import { 
  signInWithPopup, 
  signOut as firebaseSignOut, 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
  User as FirebaseUser 
} from 'firebase/auth';
import { db, auth, googleProvider, checkIsAdmin } from './config';
import { 
  Novel, 
  Chapter, 
  UserProfile, 
  TopUpRequest, 
  NovelSubmission, 
  WithdrawalRequest, 
  CreatorApplication, 
  NovelReport 
} from '../types';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map((provider) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

/**
 * Đăng nhập bằng tài khoản Google (Firebase Auth popup)
 */
export async function loginWithGoogle(): Promise<FirebaseUser> {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error) {
    console.error('Google Sign-in failed:', error);
    throw error;
  }
}

/**
 * Đăng ký tài khoản mới bằng Email và Mật khẩu
 */
export async function registerWithEmail(
  email: string, 
  password: string, 
  displayName: string,
  referralCode?: string
): Promise<UserProfile> {
  const cleanEmail = email.trim().toLowerCase();
  const cleanName = displayName.trim() || 'Độc Giả Mới';
  const isAdmin = checkIsAdmin(cleanEmail);

  try {
    const cred = await createUserWithEmailAndPassword(auth, cleanEmail, password);
    if (auth.currentUser) {
      await updateProfile(auth.currentUser, { displayName: cleanName });
    }
    const profile = await syncUserProfile(cred.user);
    if (cleanName && profile.displayName !== cleanName) {
      profile.displayName = cleanName;
      await updateUserState(profile.id, { displayName: cleanName });
    }
    return profile;
  } catch (authError: any) {
    console.warn('Firebase Auth registration fallback to Firestore record:', authError?.message || authError);
    // Graceful fallback for environments where email/password auth provider is disabled or restricted
    const customUid = `usr-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const newProfile: UserProfile = {
      id: customUid,
      email: cleanEmail,
      displayName: cleanName,
      avatarUrl: '', // Default empty avatar placeholder as requested
      bio: '',
      followers: [],
      followingCreators: [],
      isLoggedIn: true,
      role: isAdmin ? 'admin' : 'reader',
      xuBalance: 0,
      authorEarnedXu: 0,
      flowerBalance: 0,
      lastDailyRewardDate: '',
      lastDailyRewardTimestamp: 0,
      readingHistory: [],
      bookmarks: [],
      unlockedChapters: {},
      unlockedFullBooks: [],
      purchases: [],
    };

    try {
      await setDoc(doc(db, 'users', customUid), {
        ...newProfile,
        createdAt: Date.now(),
        referralCode: referralCode || '',
      });
    } catch (dbErr) {
      console.warn('Could not save user profile to Firestore:', dbErr);
    }
    return newProfile;
  }
}

/**
 * Đăng nhập bằng Email và Mật khẩu
 */
export async function loginWithEmail(email: string, password: string): Promise<UserProfile> {
  const cleanEmail = email.trim().toLowerCase();
  const isAdmin = checkIsAdmin(cleanEmail);

  try {
    const cred = await signInWithEmailAndPassword(auth, cleanEmail, password);
    return await syncUserProfile(cred.user);
  } catch (authError: any) {
    console.warn('Firebase Auth signIn fallback checking Firestore:', authError?.message || authError);
    // Check Firestore users collection for matching email
    try {
      const q = query(collection(db, 'users'), where('email', '==', cleanEmail));
      const snap = await getDocs(q);
      if (!snap.empty) {
        const data = snap.docs[0].data();
        return {
          id: snap.docs[0].id,
          email: data.email || cleanEmail,
          displayName: data.displayName || 'Độc Giả',
          avatarUrl: data.avatarUrl || '',
          bio: data.bio || '',
          followers: data.followers || [],
          followingCreators: data.followingCreators || [],
          isLoggedIn: true,
          role: isAdmin ? 'admin' : (data.role || 'reader'),
          xuBalance: typeof data.xuBalance === 'number' ? data.xuBalance : 0,
          authorEarnedXu: typeof data.authorEarnedXu === 'number' ? data.authorEarnedXu : 0,
          flowerBalance: typeof data.flowerBalance === 'number' ? data.flowerBalance : 0,
          lastDailyRewardDate: data.lastDailyRewardDate || '',
          lastDailyRewardTimestamp: data.lastDailyRewardTimestamp || 0,
          readingHistory: data.readingHistory || [],
          bookmarks: data.bookmarks || [],
          unlockedChapters: data.unlockedChapters || {},
          unlockedFullBooks: data.unlockedFullBooks || [],
          purchases: data.purchases || [],
        };
      }
    } catch (dbErr) {
      console.warn('Firestore fallback lookup failed:', dbErr);
    }

    // If account doesn't exist, throw friendly error
    if (authError?.code === 'auth/wrong-password' || authError?.code === 'auth/invalid-credential') {
      throw new Error('Mật khẩu không chính xác. Vui lòng kiểm tra lại!');
    }
    if (authError?.code === 'auth/user-not-found') {
      throw new Error('Tài khoản email này chưa được đăng ký. Vui lòng chọn "Đăng ký ngay"!');
    }
    throw new Error(authError?.message || 'Đăng nhập không thành công. Vui lòng kiểm tra lại thông tin.');
  }
}

/**
 * Đăng xuất tài khoản Firebase
 */
export async function logoutUser(): Promise<void> {
  try {
    await firebaseSignOut(auth);
  } catch (error) {
    console.error('Sign-out failed:', error);
    throw error;
  }
}

/**
 * Đồng bộ hoặc khởi tạo User Profile trong Firestore collection "users"
 */
export async function syncUserProfile(firebaseUser: FirebaseUser): Promise<UserProfile> {
  const userRef = doc(db, 'users', firebaseUser.uid);
  const path = `users/${firebaseUser.uid}`;
  const isAdmin = checkIsAdmin(firebaseUser.email);

  try {
    const snap = await getDoc(userRef);

    if (snap.exists()) {
      const data = snap.data();
      const determinedRole = isAdmin ? 'admin' : (data.role || 'reader');

      const updatedProfile: UserProfile = {
        id: firebaseUser.uid,
        email: firebaseUser.email || '',
        displayName: data.displayName || firebaseUser.displayName || 'Độc Giả',
        avatarUrl: data.avatarUrl || firebaseUser.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
        bio: data.bio || '',
        followers: data.followers || [],
        followingCreators: data.followingCreators || [],
        isLoggedIn: true,
        role: determinedRole,
        xuBalance: typeof data.xuBalance === 'number' ? data.xuBalance : 0,
        authorEarnedXu: typeof data.authorEarnedXu === 'number' ? data.authorEarnedXu : 0,
        flowerBalance: typeof data.flowerBalance === 'number' ? data.flowerBalance : 0,
        lastDailyRewardDate: data.lastDailyRewardDate || '',
        lastDailyRewardTimestamp: typeof data.lastDailyRewardTimestamp === 'number' ? data.lastDailyRewardTimestamp : 0,
        bankInfo: data.bankInfo || undefined,
        readingHistory: data.readingHistory || [],
        bookmarks: data.bookmarks || [],
        unlockedChapters: data.unlockedChapters || {},
        unlockedFullBooks: data.unlockedFullBooks || [],
        purchases: data.purchases || [],
      };

      if (data.role !== determinedRole) {
        await updateDoc(userRef, { role: determinedRole });
      }

      return updatedProfile;
    } else {
      const newRole = isAdmin ? 'admin' : 'reader';
      const newProfile: UserProfile = {
        id: firebaseUser.uid,
        email: firebaseUser.email || '',
        displayName: firebaseUser.displayName || 'Độc Giả Mới',
        avatarUrl: firebaseUser.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
        bio: '',
        followers: [],
        followingCreators: [],
        isLoggedIn: true,
        role: newRole,
        xuBalance: 0,
        authorEarnedXu: 0,
        flowerBalance: 0,
        lastDailyRewardDate: '',
        lastDailyRewardTimestamp: 0,
        readingHistory: [],
        bookmarks: [],
        unlockedChapters: {},
        unlockedFullBooks: [],
        purchases: [],
      };

      await setDoc(userRef, {
        email: newProfile.email,
        displayName: newProfile.displayName,
        avatarUrl: newProfile.avatarUrl,
        bio: '',
        followers: [],
        followingCreators: [],
        role: newProfile.role,
        xuBalance: 0,
        authorEarnedXu: 0,
        flowerBalance: 0,
        lastDailyRewardDate: '',
        lastDailyRewardTimestamp: 0,
        readingHistory: [],
        bookmarks: [],
        unlockedChapters: {},
        unlockedFullBooks: [],
        purchases: [],
        createdAt: new Date().toISOString(),
      });

      return newProfile;
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Theo dõi hoặc bỏ theo dõi Tác giả / Editor / Admin trong Firestore:
 * - Khi follow = true:
 *   + Thêm creatorId vào followingCreators của currentUser
 *   + Thêm currentUserId vào followers của creator
 * - Khi follow = false:
 *   + Xóa creatorId khỏi followingCreators của currentUser
 *   + Xóa currentUserId khỏi followers của creator
 */
export async function followCreatorInFirestore(
  currentUserId: string,
  creatorId: string,
  shouldFollow: boolean
): Promise<{ success: boolean; isFollowing: boolean }> {
  try {
    const userRef = doc(db, 'users', currentUserId);
    const creatorRef = doc(db, 'users', creatorId);

    if (shouldFollow) {
      await updateDoc(userRef, {
        followingCreators: arrayUnion(creatorId),
      });
      const creatorSnap = await getDoc(creatorRef);
      if (creatorSnap.exists()) {
        await updateDoc(creatorRef, {
          followers: arrayUnion(currentUserId),
        });
      }
    } else {
      await updateDoc(userRef, {
        followingCreators: arrayRemove(creatorId),
      });
      const creatorSnap = await getDoc(creatorRef);
      if (creatorSnap.exists()) {
        await updateDoc(creatorRef, {
          followers: arrayRemove(currentUserId),
        });
      }
    }
    return { success: true, isFollowing: shouldFollow };
  } catch (error) {
    console.warn('Lỗi cập nhật Firestore khi theo dõi creator (sử dụng offline fallback):', error);
    return { success: true, isFollowing: shouldFollow };
  }
}

/**
 * Lấy thông tin User / Creator theo ID từ Firestore
 */
export async function fetchUserProfileById(userId: string): Promise<UserProfile | null> {
  try {
    const snap = await getDoc(doc(db, 'users', userId));
    if (snap.exists()) {
      const data = snap.data();
      return {
        id: snap.id,
        email: data.email || '',
        displayName: data.displayName || 'Tác giả',
        avatarUrl: data.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
        bio: data.bio || '',
        followers: data.followers || [],
        followingCreators: data.followingCreators || [],
        isLoggedIn: true,
        role: data.role || 'author',
        xuBalance: data.xuBalance || 0,
        authorEarnedXu: data.authorEarnedXu || 0,
        flowerBalance: data.flowerBalance || 0,
        readingHistory: data.readingHistory || [],
        bookmarks: data.bookmarks || [],
        unlockedChapters: data.unlockedChapters || {},
        unlockedFullBooks: data.unlockedFullBooks || [],
        purchases: data.purchases || [],
      };
    }
    return null;
  } catch (error) {
    console.warn('Could not fetch user profile by ID:', error);
    return null;
  }
}

/**
 * Tìm Creator theo bút danh (displayName)
 */
export async function fetchCreatorByDisplayName(name: string): Promise<UserProfile | null> {
  try {
    const usersCol = collection(db, 'users');
    const q = query(usersCol, where('displayName', '==', name));
    const snap = await getDocs(q);
    if (!snap.empty) {
      const docSnap = snap.docs[0];
      const data = docSnap.data();
      return {
        id: docSnap.id,
        email: data.email || '',
        displayName: data.displayName || name,
        avatarUrl: data.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
        bio: data.bio || '',
        followers: data.followers || [],
        followingCreators: data.followingCreators || [],
        isLoggedIn: true,
        role: data.role || 'author',
        xuBalance: data.xuBalance || 0,
        authorEarnedXu: data.authorEarnedXu || 0,
        flowerBalance: data.flowerBalance || 0,
        readingHistory: data.readingHistory || [],
        bookmarks: data.bookmarks || [],
        unlockedChapters: data.unlockedChapters || {},
        unlockedFullBooks: data.unlockedFullBooks || [],
        purchases: data.purchases || [],
      };
    }
    return null;
  } catch (error) {
    console.warn('Could not fetch creator by displayName:', error);
    return null;
  }
}

/**
 * Cập nhật số dư Xu hoặc thông tin người dùng
 */
export async function updateUserState(userId: string, data: Partial<UserProfile>): Promise<void> {
  const path = `users/${userId}`;
  try {
    const userRef = doc(db, 'users', userId);
    await updateDoc(userRef, data as any);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Tải danh sách truyện từ Firestore
 */
export async function fetchNovelsFromFirestore(): Promise<Novel[]> {
  const path = 'novels';
  try {
    const novelsCol = collection(db, path);
    const snapshot = await getDocs(novelsCol);

    if (snapshot.empty) {
      return [];
    }

    const novels: Novel[] = [];
    for (const docSnap of snapshot.docs) {
      const novelData = docSnap.data() as Novel;
      
      const chaptersCol = collection(db, 'novels', docSnap.id, 'chapters');
      const q = query(chaptersCol, orderBy('number', 'asc'));
      const chaptersSnap = await getDocs(q);

      const chapters: Chapter[] = chaptersSnap.docs.map((cDoc) => ({
        ...(cDoc.data() as Chapter),
        id: cDoc.id,
      }));

      novels.push({
        ...novelData,
        id: docSnap.id,
        chapters: chapters.length > 0 ? chapters : (novelData.chapters || []),
      });
    }

    return novels;
  } catch (error) {
    console.warn('Không thể tải truyện từ Firestore, giữ nguyên danh sách hiện tại:', error);
    return [];
  }
}

/**
 * Lưu tác phẩm mới hoặc cập nhật truyện trong Firestore
 */
export async function saveNovelToFirestore(novel: Novel): Promise<void> {
  const path = `novels/${novel.id}`;
  try {
    const novelRef = doc(db, 'novels', novel.id);
    const { chapters, ...novelMeta } = novel;

    await setDoc(novelRef, {
      ...novelMeta,
      updatedAt: Date.now(),
    });

    if (chapters && chapters.length > 0) {
      for (const ch of chapters) {
        const chRef = doc(db, 'novels', novel.id, 'chapters', ch.id || `c-${ch.number}`);
        await setDoc(chRef, ch);
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Nạp dữ liệu mẫu ban đầu vào Firestore nếu database đang trống.
 * Chỉ thực hiện khi người dùng đăng nhập hiện tại là Admin đã được cấp quyền.
 */
export async function seedNovelsIfEmpty(sampleNovels: Novel[]): Promise<void> {
  const currentUser = auth.currentUser;
  if (!currentUser || !checkIsAdmin(currentUser.email)) {
    return;
  }

  try {
    const novelsCol = collection(db, 'novels');
    const snap = await getDocs(novelsCol);
    if (snap.empty) {
      console.log('Tài khoản Admin hợp lệ, đang khởi tạo nạp dữ liệu mẫu vào Firestore...');
      for (const novel of sampleNovels) {
        await saveNovelToFirestore(novel);
      }
      console.log('Nạp dữ liệu mẫu vào Firestore thành công!');
    }
  } catch (error) {
    console.warn('Seed novels error:', error);
  }
}

/**
 * Xóa vĩnh viễn truyện khỏi Firestore (Chỉ dành cho Admin)
 */
export async function deleteNovelFromFirestore(novelId: string): Promise<void> {
  const path = `novels/${novelId}`;
  try {
    const novelRef = doc(db, 'novels', novelId);
    await deleteDoc(novelRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

/**
 * Ẩn hoặc hiện truyện trên Firestore (Chỉ dành cho Admin)
 */
export async function toggleHideNovelInFirestore(novelId: string, isHidden: boolean): Promise<void> {
  const path = `novels/${novelId}`;
  try {
    const novelRef = doc(db, 'novels', novelId);
    await updateDoc(novelRef, {
      isHidden,
      publishStatus: isHidden ? 'hidden' : 'published',
      updatedAt: Date.now(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/* ==========================================================================
   FIRESTORE REALTIME SERVICES: YÊU CẦU NẠP TIỀN (TOP-UP REQUESTS)
   ========================================================================== */

/**
 * Gửi yêu cầu nạp Xu lên Firestore collection "topup_requests"
 */
export async function createTopUpRequestInFirestore(
  requestData: Omit<TopUpRequest, 'id' | 'createdAt' | 'status'>
): Promise<TopUpRequest> {
  const path = 'topup_requests';
  try {
    const newDocRef = doc(collection(db, path));
    const newRequest: TopUpRequest = {
      ...requestData,
      id: newDocRef.id,
      status: 'pending',
      createdAt: Date.now(),
    };
    await setDoc(newDocRef, newRequest);
    return newRequest;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

/**
 * Tải danh sách yêu cầu nạp tiền:
 * - Admin: Tải toàn bộ danh sách
 * - User thường: Chỉ tải yêu cầu của chính user (filterUserId)
 */
export async function fetchTopUpRequestsFromFirestore(filterUserId?: string): Promise<TopUpRequest[]> {
  const path = 'topup_requests';
  try {
    const colRef = collection(db, path);
    const q = filterUserId
      ? query(colRef, where('userId', '==', filterUserId))
      : query(colRef, orderBy('createdAt', 'desc'));

    const snap = await getDocs(q);
    const list: TopUpRequest[] = snap.docs.map((d) => ({
      ...(d.data() as TopUpRequest),
      id: d.id,
    }));

    if (filterUserId) {
      list.sort((a, b) => b.createdAt - a.createdAt);
    }
    return list;
  } catch (error) {
    console.warn('Lỗi tải topup_requests:', error);
    return [];
  }
}

/**
 * Cập nhật trạng thái duyệt nạp tiền (Chỉ Admin)
 */
export async function updateTopUpRequestStatusInFirestore(
  requestId: string,
  status: 'approved' | 'rejected'
): Promise<void> {
  const path = `topup_requests/${requestId}`;
  try {
    const reqRef = doc(db, 'topup_requests', requestId);
    await updateDoc(reqRef, {
      status,
      approvedAt: status === 'approved' ? Date.now() : undefined,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/* ==========================================================================
   FIRESTORE REALTIME SERVICES: BẢN THẢO TRUYỆN (NOVEL SUBMISSIONS)
   ========================================================================== */

/**
 * Gửi bản thảo truyện lên collection "novel_submissions"
 */
export async function submitNovelSubmissionToFirestore(
  submissionData: Omit<NovelSubmission, 'id'>
): Promise<NovelSubmission> {
  const path = 'novel_submissions';
  try {
    const newDocRef = doc(collection(db, path));
    const newSub: NovelSubmission = {
      ...submissionData,
      id: newDocRef.id,
      status: 'pending',
      submittedAt: Date.now(),
    };
    await setDoc(newDocRef, newSub);
    return newSub;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

/**
 * Tải danh sách bản thảo:
 * - Admin: Tải toàn bộ
 * - Author: Chỉ tải bản thảo của chính mình (filterAuthorId)
 */
export async function fetchNovelSubmissionsFromFirestore(filterAuthorId?: string): Promise<NovelSubmission[]> {
  const path = 'novel_submissions';
  try {
    const colRef = collection(db, path);
    const q = filterAuthorId
      ? query(colRef, where('submittedBy.userId', '==', filterAuthorId))
      : query(colRef, orderBy('submittedAt', 'desc'));

    const snap = await getDocs(q);
    const list: NovelSubmission[] = snap.docs.map((d) => ({
      ...(d.data() as NovelSubmission),
      id: d.id,
    }));

    if (filterAuthorId) {
      list.sort((a, b) => b.submittedAt - a.submittedAt);
    }
    return list;
  } catch (error) {
    console.warn('Lỗi tải novel_submissions:', error);
    return [];
  }
}

/**
 * Cập nhật trạng thái duyệt bản thảo truyện (Chỉ Admin)
 */
export async function updateNovelSubmissionStatusInFirestore(
  submissionId: string,
  status: 'approved' | 'rejected',
  rejectionReason?: string
): Promise<void> {
  const path = `novel_submissions/${submissionId}`;
  try {
    const subRef = doc(db, 'novel_submissions', submissionId);
    await updateDoc(subRef, {
      status,
      rejectionReason: rejectionReason || '',
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/* ==========================================================================
   FIRESTORE REALTIME SERVICES: ĐƠN XIN LÀM TÁC GIẢ / EDITOR (CREATOR APPLICATIONS)
   ========================================================================== */

/**
 * Gửi đơn xin làm Editor / Tác giả lên collection "creator_applications"
 */
export async function submitApplicationToFirestore(
  applicationData: Omit<CreatorApplication, 'id' | 'submittedAt' | 'status'>
): Promise<CreatorApplication> {
  const path = 'creator_applications';
  try {
    const newDocRef = doc(collection(db, path));
    const newApp: CreatorApplication = {
      ...applicationData,
      id: newDocRef.id,
      submittedAt: Date.now(),
      status: 'pending',
    };
    await setDoc(newDocRef, newApp);
    return newApp;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

/**
 * Tải danh sách đơn đăng ký Editor / Tác giả:
 * - Admin: Toàn bộ
 * - Reader/Author: Chỉ đơn của chính mình
 */
export async function fetchCreatorApplicationsFromFirestore(filterUserId?: string): Promise<CreatorApplication[]> {
  const path = 'creator_applications';
  try {
    const colRef = collection(db, path);
    const q = filterUserId
      ? query(colRef, where('userId', '==', filterUserId))
      : query(colRef, orderBy('submittedAt', 'desc'));

    const snap = await getDocs(q);
    const list: CreatorApplication[] = snap.docs.map((d) => ({
      ...(d.data() as CreatorApplication),
      id: d.id,
    }));

    if (filterUserId) {
      list.sort((a, b) => b.submittedAt - a.submittedAt);
    }
    return list;
  } catch (error) {
    console.warn('Lỗi tải creator_applications:', error);
    return [];
  }
}

/**
 * Duyệt hoặc từ chối đơn đăng ký làm Tác giả / Editor (Chỉ Admin)
 */
export async function updateCreatorApplicationStatusInFirestore(
  applicationId: string,
  status: 'approved' | 'rejected',
  rejectionReason?: string
): Promise<void> {
  const path = `creator_applications/${applicationId}`;
  try {
    const appRef = doc(db, 'creator_applications', applicationId);
    await updateDoc(appRef, {
      status,
      approvedAt: status === 'approved' ? Date.now() : undefined,
      rejectionReason: rejectionReason || '',
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/* ==========================================================================
   FIRESTORE REALTIME SERVICES: YÊU CẦU RÚT TIỀN NHUẬN BÚT (WITHDRAWAL REQUESTS)
   ========================================================================== */

/**
 * Gửi yêu cầu rút tiền nhuận bút lên collection "withdrawal_requests"
 */
export async function createWithdrawalRequestInFirestore(
  requestData: Omit<WithdrawalRequest, 'id' | 'createdAt' | 'status'>
): Promise<WithdrawalRequest> {
  const path = 'withdrawal_requests';
  try {
    const newDocRef = doc(collection(db, path));
    const newReq: WithdrawalRequest = {
      ...requestData,
      id: newDocRef.id,
      createdAt: Date.now(),
      status: 'pending',
    };
    await setDoc(newDocRef, newReq);
    return newReq;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

/**
 * Tải danh sách yêu cầu rút tiền:
 * - Admin: Toàn bộ
 * - Author: Chỉ các yêu cầu của tác giả đó (filterAuthorId)
 */
export async function fetchWithdrawalRequestsFromFirestore(filterAuthorId?: string): Promise<WithdrawalRequest[]> {
  const path = 'withdrawal_requests';
  try {
    const colRef = collection(db, path);
    const q = filterAuthorId
      ? query(colRef, where('authorId', '==', filterAuthorId))
      : query(colRef, orderBy('createdAt', 'desc'));

    const snap = await getDocs(q);
    const list: WithdrawalRequest[] = snap.docs.map((d) => ({
      ...(d.data() as WithdrawalRequest),
      id: d.id,
    }));

    if (filterAuthorId) {
      list.sort((a, b) => b.createdAt - a.createdAt);
    }
    return list;
  } catch (error) {
    console.warn('Lỗi tải withdrawal_requests:', error);
    return [];
  }
}

/**
 * Duyệt hoặc từ chối yêu cầu rút tiền nhuận bút (Chỉ Admin)
 */
export async function updateWithdrawalRequestStatusInFirestore(
  requestId: string,
  status: 'approved' | 'rejected',
  reason?: string
): Promise<void> {
  const path = `withdrawal_requests/${requestId}`;
  try {
    const reqRef = doc(db, 'withdrawal_requests', requestId);
    await updateDoc(reqRef, {
      status,
      approvedAt: status === 'approved' ? Date.now() : undefined,
      rejectionReason: reason || '',
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/* ==========================================================================
   FIRESTORE REALTIME SERVICES: BÁO CÁO VI PHẠM (NOVEL REPORTS)
   ========================================================================== */

/**
 * Gửi báo cáo vi phạm tác phẩm lên collection "novel_reports"
 */
export async function submitNovelReportToFirestore(
  reportData: Omit<NovelReport, 'id' | 'createdAt' | 'status'>
): Promise<NovelReport> {
  const path = 'novel_reports';
  try {
    const newDocRef = doc(collection(db, path));
    const newReport: NovelReport = {
      ...reportData,
      id: newDocRef.id,
      createdAt: Date.now(),
      status: 'pending',
    };
    await setDoc(newDocRef, newReport);
    return newReport;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

/**
 * Tải danh sách báo cáo vi phạm (Chỉ dành cho Admin)
 */
export async function fetchNovelReportsFromFirestore(): Promise<NovelReport[]> {
  const path = 'novel_reports';
  try {
    const colRef = collection(db, path);
    const q = query(colRef, orderBy('createdAt', 'desc'));
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({
      ...(d.data() as NovelReport),
      id: d.id,
    }));
  } catch (error) {
    console.warn('Lỗi tải novel_reports:', error);
    return [];
  }
}

/**
 * Cập nhật trạng thái báo cáo vi phạm (Chỉ Admin)
 */
export async function updateNovelReportStatusInFirestore(
  reportId: string,
  status: 'resolved' | 'dismissed',
  actionTaken?: string
): Promise<void> {
  const path = `novel_reports/${reportId}`;
  try {
    const repRef = doc(db, 'novel_reports', reportId);
    await updateDoc(repRef, {
      status,
      adminNotes: actionTaken || '',
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}
