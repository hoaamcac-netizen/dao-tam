import React, { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth, checkIsAdmin } from '../firebase/config';
import { syncUserProfile } from '../firebase/services';
import { UserProfile } from '../types';

export const GUEST_USER: UserProfile = {
  id: 'guest',
  email: '',
  displayName: 'Khách Đọc Truyện',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
  isLoggedIn: false,
  role: 'reader',
  xuBalance: 0,
  authorEarnedXu: 0,
  flowerBalance: 0,
  lastDailyRewardDate: '',
  lastDailyRewardTimestamp: 0,
  bankInfo: {
    bankName: '',
    accountNumber: '',
    accountHolder: '',
  },
  notifications: [],
  readingHistory: [],
  bookmarks: [],
  unlockedChapters: {},
  unlockedFullBooks: [],
  purchases: [],
};

interface AuthContextType {
  user: UserProfile;
  loading: boolean;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  refreshProfile: () => Promise<UserProfile | null>;
}

const AuthContext = createContext<AuthContextType>({
  user: GUEST_USER,
  loading: true,
  setUser: () => {},
  refreshProfile: async () => null,
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile>(GUEST_USER);
  const [loading, setLoading] = useState(true);

  const refreshProfile = async (): Promise<UserProfile | null> => {
    const currentUser = auth.currentUser;
    if (currentUser) {
      try {
        const profile = await syncUserProfile(currentUser);
        if (checkIsAdmin(profile.email)) {
          profile.role = 'admin';
        }
        setUser(profile);
        return profile;
      } catch (err) {
        console.error('Lỗi làm mới profile:', err);
      }
    }
    return null;
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        try {
          const profile = await syncUserProfile(fbUser);
          // Ghi đè role nếu là admin
          if (checkIsAdmin(profile.email)) {
            profile.role = 'admin';
          }
          setUser(profile);
        } catch (err) {
          console.error('Lỗi lấy profile:', err);
          setUser(GUEST_USER);
        }
      } else {
        setUser(GUEST_USER);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, setUser, refreshProfile }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
