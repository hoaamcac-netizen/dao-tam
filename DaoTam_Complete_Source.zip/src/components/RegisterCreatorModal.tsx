import React, { useState, useRef } from 'react';
import { MainCategory, UserProfile, Novel, SubmissionChapterDraft, GenreItem, StoryRole, NovelSubmission } from '../types';
import { 
  X, 
  BookPlus, 
  Sparkles, 
  ShieldCheck, 
  CheckCircle2, 
  FileText,
  AlertCircle,
  Plus,
  Image as ImageIcon,
  Layers,
  FileUp,
  Trash2,
  PenTool,
  Scissors,
  Coins,
  Percent,
  Building2,
  Upload,
  UserCheck
} from 'lucide-react';
import { DaoTamLogo } from './DaoTamLogo';

interface RegisterCreatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  genres: GenreItem[];
  onAddNewGenre?: (name: string) => void;
  onSubmitApplication: (submission: {
    title: string;
    author: string;
    editor?: string;
    publisherRoles: StoryRole[];
    isExclusive?: boolean;
    royaltyRate?: number;
    mainCategory: MainCategory;
    categories: string[];
    description: string;
    coverImage: string;
    chapters: SubmissionChapterDraft[];
    totalExpectedChapters: number;
    bankInfo: {
      bankName: string;
      accountNumber: string;
      accountHolder: string;
    };
    isCreatorApplication: boolean;
  }) => void;
  existingSubmission?: NovelSubmission | null;
}

const POPULAR_BANKS = [
  'MB Bank (Ngân Hàng Quân Đội)',
  'Vietcombank (Ngoại Thương Việt Nam)',
  'Techcombank (Kỹ Thương Việt Nam)',
  'BIDV (Đầu Tư và Phát Triển)',
  'Agribank (Nông Nghiệp)',
  'ACB (Á Châu)',
  'VPBank (Việt Nam Thịnh Vượng)',
  'TPBank (Tiên Phong)',
  'Sacombank (Sài Gòn Thương Tín)',
  'VIB (Quốc Tế)',
  'MSB (Hàng Hải)',
  'OCB (Phương Đông)',
];

export const RegisterCreatorModal: React.FC<RegisterCreatorModalProps> = ({
  isOpen,
  onClose,
  user,
  genres,
  onAddNewGenre,
  onSubmitApplication,
  existingSubmission,
}) => {
  const [penName, setPenName] = useState(user.displayName || '');
  const [roleType, setRoleType] = useState<'author' | 'editor'>('author');
  const [experienceBio, setExperienceBio] = useState('');

  // Thông tin đại diện cá nhân bắt buộc của Tác Giả & Editor
  const [facebookUrl, setFacebookUrl] = useState(user.facebookUrl || '');
  const [phoneNumber, setPhoneNumber] = useState(user.phoneNumber || '');

  // Bank Info (Bắt buộc để nhận tiền, rút tối thiểu 100 Xu)
  const [bankName, setBankName] = useState(user.bankInfo?.bankName || 'MB Bank (Ngân Hàng Quân Đội)');
  const [accountNumber, setAccountNumber] = useState(user.bankInfo?.accountNumber || '');
  const [accountHolder, setAccountHolder] = useState(user.bankInfo?.accountHolder || '');

  // Debut Novel Info
  const [novelTitle, setNovelTitle] = useState('');
  const [mainCategory, setMainCategory] = useState<MainCategory>('dam-my');
  const [selectedGenres, setSelectedGenres] = useState<string[]>(['Đam Mỹ', 'Ngọt Sủng']);
  const [customGenreInput, setCustomGenreInput] = useState('');
  const [novelDescription, setNovelDescription] = useState('');
  const [coverImage, setCoverImage] = useState<string>('');
  const [coverFileName, setCoverFileName] = useState<string>('');
  const [totalExpectedChapters, setTotalExpectedChapters] = useState(150);

  // 5 Chapter Drafts
  const [activeChapterTab, setActiveChapterTab] = useState<number>(0);
  const [draftChapters, setDraftChapters] = useState<SubmissionChapterDraft[]>([
    {
      number: 1,
      title: 'Chương 1: Khởi đầu định mệnh và sự thức tỉnh',
      content: 'Gió thu rít qua khe cửa sổ, mang theo hơi lạnh buốt giá. Hắn mở choàng mắt, ngơ ngác nhìn trần nhà phủ rèm lụa thêu hoa sen...',
    },
    {
      number: 2,
      title: 'Chương 2: Làn sóng ngầm nơi thâm cung nội viện',
      content: 'Sáng sớm hôm sau, tiếng bước chân vội vã vang lên ngoài hành lang. Tiểu nha hoàn hốt hoảng chạy vào thông báo...',
    },
    {
      number: 3,
      title: 'Chương 3: Cuộc chạm trán bất ngờ tại ngự hoa viên',
      content: 'Dưới tàng hoa quế thơm ngát, bóng dáng nam nhân cao lớn uy nghiêm đang đứng chắp tay sau lưng...',
    },
    {
      number: 4,
      title: 'Chương 4: Thăm dò lẫn nhau và manh mối bí ẩn',
      content: '"Ngươi thật sự không nhớ gì sao?" Ánh mắt sắc lạnh như băng tuyết găm chặt vào khuôn mặt thanh tú của y...',
    },
    {
      number: 5,
      title: 'Chương 5: Bước ngoặt nguy nan và quyết định trọng đại',
      content: 'Đêm đen như mực, một bức mật thư giấu kín trong hộp gỗ đàn hương bất ngờ bị phát hiện, báo hiệu một chuỗi giông bão sắp ập tới...',
    },
  ]);

  const [agreedToPolicy, setAgreedToPolicy] = useState(true);
  const [isSuccess, setIsSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const draftFileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Vui lòng chọn tệp hình ảnh hợp lệ (PNG, JPG, WEBP).');
      return;
    }

    setCoverFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setCoverImage(event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDraftFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const fullText = (event.target?.result as string) || '';
      if (!fullText.trim()) {
        alert('Tệp văn bản trống.');
        return;
      }

      // Check for chapter markers like "Chương 1", "Hồi 1"
      const chapterSplits = fullText.split(/(?=(?:Chương|Hồi|Chapter)\s+\d+[:.\s])/i);
      if (chapterSplits.length >= 5) {
        const newChapters = chapterSplits.slice(0, 5).map((chunk, idx) => {
          const lines = chunk.trim().split('\n');
          const firstLine = lines[0].trim();
          const body = lines.slice(1).join('\n').trim();
          return {
            number: idx + 1,
            title: firstLine.length < 100 ? firstLine : `Chương ${idx + 1}`,
            content: body || firstLine,
            wordCount: chunk.split(/\s+/).filter(Boolean).length,
          };
        });
        setDraftChapters(newChapters);
        alert(`Đã tự động trích xuất 5 chương đầu từ tệp "${file.name}"!`);
      } else {
        const chunkSize = Math.ceil(fullText.length / 5);
        const newChapters = [0, 1, 2, 3, 4].map((i) => {
          const slice = fullText.slice(i * chunkSize, (i + 1) * chunkSize).trim();
          return {
            number: i + 1,
            title: `Chương ${i + 1}: Bản thảo trích đoạn ${i + 1}`,
            content: slice,
            wordCount: slice.split(/\s+/).filter(Boolean).length,
          };
        });
        setDraftChapters(newChapters);
        alert(`Đã tải nội dung từ tệp "${file.name}" và chia đều vào 5 chương bản thảo!`);
      }
    };
    reader.readAsText(file);
  };

  const handleToggleGenre = (genreName: string) => {
    if (selectedGenres.includes(genreName)) {
      if (selectedGenres.length > 1) {
        setSelectedGenres(selectedGenres.filter((g) => g !== genreName));
      }
    } else {
      setSelectedGenres([...selectedGenres, genreName]);
    }
  };

  const handleAddNewCustomGenre = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = customGenreInput.trim();
    if (!trimmed) return;
    if (onAddNewGenre) onAddNewGenre(trimmed);
    if (!selectedGenres.includes(trimmed)) {
      setSelectedGenres([...selectedGenres, trimmed]);
    }
    setCustomGenreInput('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!agreedToPolicy) {
      alert('Vui lòng đồng ý với Cam kết bản quyền và quy định nhuận bút của Đạo Tâm.');
      return;
    }

    if (!penName.trim()) {
      alert('Vui lòng nhập Bút danh hoặc Tên dịch giả.');
      return;
    }

    // Kiểm tra thông tin đại diện cá nhân bắt buộc
    if (!facebookUrl.trim()) {
      alert('Mục đại diện cá nhân bắt buộc: Vui lòng cung cấp link Facebook hoặc Fanpage của bạn.');
      return;
    }

    if (!phoneNumber.trim()) {
      alert('Mục đại diện cá nhân bắt buộc: Vui lòng nhập Số điện thoại liên hệ.');
      return;
    }

    if (!bankName.trim() || !accountNumber.trim() || !accountHolder.trim()) {
      alert('Mục đại diện cá nhân bắt buộc: Vui lòng nhập đầy đủ Tên ngân hàng, Số tài khoản (STK) và Tên chủ tài khoản để nhận tiền nhuận bút (Rút tối thiểu 100 Xu).');
      return;
    }

    if (!novelTitle.trim() || !novelDescription.trim()) {
      alert('Vui lòng điền Tên tác phẩm khởi đầu và Tóm tắt nội dung.');
      return;
    }

    if (!coverImage) {
      alert('Vui lòng tải ảnh bìa cho tác phẩm đầu tay của bạn.');
      return;
    }

    const invalidChapter = draftChapters.find((c) => !c.title.trim() || !c.content.trim());
    if (invalidChapter) {
      alert(`Vui lòng hoàn thiện nội dung cho Chương ${invalidChapter.number} (yêu cầu tối thiểu 5 chương để BQT thẩm định chất lượng văn phong).`);
      return;
    }

    const publisherRoles: StoryRole[] = [roleType];
    const effectiveRoyaltyRate = roleType === 'author' ? 95 : 70;

    onSubmitApplication({
      title: novelTitle.trim(),
      author: roleType === 'author' ? penName.trim() : 'Khuyết danh',
      editor: roleType === 'editor' ? penName.trim() : undefined,
      publisherRoles,
      isExclusive: false,
      royaltyRate: effectiveRoyaltyRate,
      mainCategory,
      categories: selectedGenres,
      description: novelDescription.trim(),
      coverImage,
      chapters: draftChapters,
      totalExpectedChapters,
      bankInfo: {
        bankName: bankName.trim(),
        accountNumber: accountNumber.trim(),
        accountHolder: accountHolder.trim().toUpperCase(),
      },
      isCreatorApplication: true,
    });

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 text-slate-200">
      <div className="w-full max-w-4xl bg-[#090d16] border border-pink-500/40 rounded-2xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-6 py-4 bg-[#0e1424] border-b border-pink-500/20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-pink-600/20 border border-pink-500/40 flex items-center justify-center text-pink-400">
              <BookPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-white flex items-center gap-2">
                Đăng Ký Trở Thành Tác Giả &amp; Editor Chính Thức
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/40">
                  Nhuận Bút Lên Đến 95%
                </span>
              </h2>
              <p className="text-xs text-pink-300/80">
                Thăng cấp tài khoản Độc Giả thành Người Sáng Tác, tự do xuất bản truyện và rút nhuận bút về ngân hàng
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* DÒNG CẢNH BÁO BẮT BUỘC DÀNH CHO TÁC GIẢ & EDITOR */}
        <div className="px-6 py-3 bg-gradient-to-r from-rose-950/90 via-red-950/80 to-amber-950/80 border-b border-rose-500/40 text-rose-200 text-xs shadow-md">
          <div className="flex items-start gap-2.5 max-w-4xl">
            <span className="p-1 rounded-lg bg-rose-600/30 border border-rose-500/50 text-rose-300 flex-shrink-0 mt-0.5">
              ⚠️
            </span>
            <div className="leading-relaxed">
              <strong className="text-white uppercase font-bold tracking-wider block mb-0.5 text-[11px]">
                Cảnh báo quy chế bắt buộc khi đăng truyện:
              </strong>
              <p className="text-rose-100 font-medium">
                "Các tác giả, editor không được phép đăng truyện bản quyền, truyện 18+, không tự ý cố tình xóa chương đăng lại để hiện truyện lên trang. Ai vi phạm và có xác nhận từ web sẽ bị cấm vĩnh viễn, doanh thu tháng đó cũng sẽ mất. Các team lưu ý giúp mình."
              </p>
            </div>
          </div>
        </div>

        {/* Existing Application Notice if pending */}
        {existingSubmission && existingSubmission.status === 'pending' && (
          <div className="px-6 py-2.5 bg-amber-950/60 border-b border-amber-500/30 text-amber-200 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0 animate-spin" />
              <span>
                Hồ sơ tác phẩm <strong>"{existingSubmission.title}"</strong> của bạn đang được Ban Quản Trị thẩm định. Bạn có thể gửi thêm bản thảo hoặc cập nhật thông tin tại đây.
              </span>
            </div>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          
          {/* PHẦN 1: VAI TRÒ & QUYỀN LỢI NHUẬN BÚT */}
          <div className="p-4 rounded-xl bg-[#0e1424] border border-slate-800 space-y-3">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <PenTool className="w-4 h-4 text-pink-400" />
              1. Vai Trò Bạn Muốn Đăng Ký &amp; Tỷ Lệ Nhuận Bút
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setRoleType('author')}
                className={`p-3.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                  roleType === 'author'
                    ? 'bg-pink-600/15 border-pink-500 ring-2 ring-pink-500/40 text-white'
                    : 'bg-black/40 border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div>
                  <div className="font-bold text-sm flex items-center justify-between">
                    <span>✍️ Tác Giả Sáng Tác</span>
                    <span className="text-xs font-extrabold text-pink-400">95% Nhuận bút</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Viết truyện chính chủ của bạn. Hưởng 95% tổng doanh thu mở khóa chương VIP từ bạn đọc.
                  </p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setRoleType('editor')}
                className={`p-3.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                  roleType === 'editor'
                    ? 'bg-indigo-600/15 border-indigo-500 ring-2 ring-indigo-500/40 text-white'
                    : 'bg-black/40 border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div>
                  <div className="font-bold text-sm flex items-center justify-between">
                    <span>✂️ Editor / Dịch Giả</span>
                    <span className="text-xs font-extrabold text-indigo-400">70% - 90% Nhuận bút</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Dịch và biên tập truyện. Hưởng 70% không độc quyền hoặc 90% nếu chọn đăng độc quyền khi xuất bản.
                  </p>
                </div>
              </button>
            </div>
          </div>

          {/* PHẦN 2: THÔNG TIN ĐẠI DIỆN CÁ NHÂN BẮT BUỘC (FACEBOOK, SĐT, TÀI KHOẢN NGÂN HÀNG) */}
          <div className="p-4 rounded-xl bg-[#0e1424] border border-pink-500/30 space-y-3.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-emerald-400" />
                2. Thông Tin Đại Diện Cá Nhân &amp; Tài Khoản Nhận Nhuận Bút <span className="text-rose-400">*</span>
              </h3>
              <span className="text-[10px] text-emerald-300 bg-emerald-950/70 border border-emerald-500/40 px-2 py-0.5 rounded font-bold">
                Rút tối thiểu: 100 Xu
              </span>
            </div>

            <div className="p-2.5 rounded-lg bg-pink-950/30 border border-pink-500/30 text-[11px] text-pink-300 leading-relaxed">
              💡 <strong>Yêu cầu bắt buộc:</strong> Khi chọn làm tác giả hoặc editor, bạn bắt buộc phải bổ sung link Facebook hoặc Fanpage, Số điện thoại và Tài khoản ngân hàng để nhận tiền nhuận bút.
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-semibold">
                  Bút Danh / Tên Dịch Giả: <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={penName}
                  onChange={(e) => setPenName(e.target.value)}
                  placeholder="Nhập bút danh bạn muốn xuất hiện trên tác phẩm..."
                  className="w-full bg-black border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-pink-500 font-bold"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">
                  Số Điện Thoại (SĐT) Liên Hệ: <span className="text-rose-400">*</span>
                </label>
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="VD: 0912345678"
                  className="w-full bg-black border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-pink-500"
                  required
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-300 mb-1 font-semibold">
                  Link Facebook Cá Nhân hoặc Fanpage: <span className="text-rose-400">*</span>
                </label>
                <input
                  type="url"
                  value={facebookUrl}
                  onChange={(e) => setFacebookUrl(e.target.value)}
                  placeholder="https://facebook.com/trang.ca.nhan hoặc https://fb.com/fanpage"
                  className="w-full bg-black border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-pink-500"
                  required
                />
              </div>
            </div>

            {/* Thông tin tài khoản ngân hàng */}
            <div className="pt-3 border-t border-slate-800 space-y-2.5">
              <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5" />
                <span>Tài Khoản Ngân Hàng Nhận Tiền Nhuận Bút (Số xu rút tối thiểu: 100 Xu): <span className="text-rose-400">*</span></span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Ngân hàng:</label>
                  <select
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-lg bg-black border border-slate-700 text-xs text-white focus:outline-none focus:border-pink-500 cursor-pointer"
                    required
                  >
                    {POPULAR_BANKS.map((b) => (
                      <option key={b} value={b}>{b}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Số tài khoản (STK):</label>
                  <input
                    type="text"
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    placeholder="VD: 0381000123456"
                    className="w-full px-2.5 py-2 rounded-lg bg-black border border-slate-700 text-xs font-mono font-bold text-white focus:outline-none focus:border-pink-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Tên chủ tài khoản:</label>
                  <input
                    type="text"
                    value={accountHolder}
                    onChange={(e) => setAccountHolder(e.target.value.toUpperCase())}
                    placeholder="NGUYEN VAN A"
                    className="w-full px-2.5 py-2 rounded-lg bg-black border border-slate-700 text-xs font-bold uppercase text-white focus:outline-none focus:border-pink-500"
                    required
                  />
                </div>
              </div>
            </div>
          </div>

          {/* PHẦN 3: TÁC PHẨM ĐẦU TAY & 5 CHƯƠNG BẢN THẢO THẨM ĐỊNH */}
          <div className="p-4 rounded-xl bg-[#0e1424] border border-slate-800 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-sky-400" />
                3. Tác Phẩm Khởi Đầu &amp; 5 Chương Bản Thảo Mẫu Thẩm Định
              </h3>
              <span className="text-[11px] text-amber-400 bg-amber-500/15 border border-amber-500/30 px-2.5 py-0.5 rounded-full font-semibold">
                Yêu cầu bắt buộc 5 chương
              </span>
            </div>

            <p className="text-xs text-slate-400">
              Để đảm bảo quyền lợi độc giả và giữ vững chất lượng văn phong của Đạo Tâm, BQT yêu cầu bạn nộp trước 5 chương bản thảo đầu tay.
            </p>

            {/* Novel Basic Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="sm:col-span-2">
                <label className="block text-slate-400 mb-1 font-semibold">
                  Tên Truyện Đầu Tay: <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={novelTitle}
                  onChange={(e) => setNovelTitle(e.target.value)}
                  placeholder="Ví dụ: Ma Đạo Tông Sư, Trọng Sinh Nghịch Thiên..."
                  className="w-full bg-black border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-sky-500 text-sm font-bold"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">
                  Phân Mục Chính: <span className="text-rose-400">*</span>
                </label>
                <select
                  value={mainCategory}
                  onChange={(e) => setMainCategory(e.target.value as MainCategory)}
                  className="w-full bg-black border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-sky-500 cursor-pointer"
                >
                  <option value="dam-my">❤️ Đam Mỹ</option>
                  <option value="truyen-nam">⚔️ Truyện Nam (Tiên Hiệp, Huyền Huyễn)</option>
                  <option value="truyen-nu">🌸 Truyện Nữ (Ngôn Tình, Cổ Đại)</option>
                  <option value="truyen-sang-tac">✍️ Truyện Tự Sáng Tác</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-semibold">
                  Tổng Số Chương Dự Kiến:
                </label>
                <input
                  type="number"
                  min="30"
                  max="3000"
                  value={totalExpectedChapters}
                  onChange={(e) => setTotalExpectedChapters(Number(e.target.value))}
                  className="w-full bg-black border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-400 mb-1 font-semibold">
                  Tóm Tắt Nội Dung Cốt Truyện (Văn Án): <span className="text-rose-400">*</span>
                </label>
                <textarea
                  rows={3}
                  value={novelDescription}
                  onChange={(e) => setNovelDescription(e.target.value)}
                  placeholder="Mô tả bối cảnh, nhân vật chính và nội dung cuốn hút của tác phẩm..."
                  className="w-full bg-black border border-slate-700 rounded-lg p-3 text-white focus:outline-none focus:border-sky-500 text-xs"
                  required
                />
              </div>

              {/* Cover Image Upload */}
              <div className="sm:col-span-2 p-3 rounded-xl bg-black/40 border border-slate-800 flex flex-col sm:flex-row items-center gap-4">
                <div className="w-20 h-28 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center flex-shrink-0 overflow-hidden">
                  {coverImage ? (
                    <img src={coverImage} alt="Cover Preview" className="w-full h-full object-cover" />
                  ) : (
                    <ImageIcon className="w-8 h-8 text-slate-600" />
                  )}
                </div>

                <div className="flex-1 space-y-1.5 text-center sm:text-left">
                  <div className="font-bold text-white text-xs">Ảnh Bìa Tác Phẩm <span className="text-rose-400">*</span></div>
                  <p className="text-[11px] text-slate-400">
                    Tải lên ảnh bìa sắc nét (tỷ lệ 3:4 hoặc 2:3) từ điện thoại / máy tính của bạn
                  </p>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleCoverUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <div className="flex items-center justify-center sm:justify-start gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>{coverFileName ? 'Đổi ảnh bìa' : 'Tải ảnh bìa từ máy'}</span>
                    </button>
                    {coverFileName && (
                      <span className="text-[11px] text-emerald-400 truncate max-w-[200px]">
                        ✓ {coverFileName}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* 5 Chapters Editor & Uploader */}
            <div className="pt-3 border-t border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span>Nội Dung 5 Chương Bản Thảo Mẫu:</span>
                </label>

                <div className="flex items-center gap-2">
                  <input
                    type="file"
                    ref={draftFileInputRef}
                    onChange={handleDraftFileUpload}
                    accept=".txt,.doc,.docx"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => draftFileInputRef.current?.click()}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-300 text-xs flex items-center gap-1 cursor-pointer"
                    title="Tải tệp .txt lên hệ thống tự động tách thành 5 chương"
                  >
                    <FileUp className="w-3.5 h-3.5" />
                    <span>Tải tệp .txt</span>
                  </button>
                </div>
              </div>

              {/* 5 Tabs for Chapter 1 -> 5 */}
              <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
                {draftChapters.map((ch, idx) => (
                  <button
                    key={ch.number}
                    type="button"
                    onClick={() => setActiveChapterTab(idx)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap cursor-pointer transition-all ${
                      activeChapterTab === idx
                        ? 'bg-pink-600 text-white shadow'
                        : 'bg-black/40 text-slate-400 hover:text-white border border-slate-800'
                    }`}
                  >
                    Chương {ch.number}
                  </button>
                ))}
              </div>

              {/* Active Chapter Content */}
              <div className="space-y-2 p-3.5 rounded-xl bg-black/60 border border-slate-800">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Tiêu Đề Chương {draftChapters[activeChapterTab]?.number}:
                  </label>
                  <input
                    type="text"
                    value={draftChapters[activeChapterTab]?.title || ''}
                    onChange={(e) => {
                      const updated = [...draftChapters];
                      updated[activeChapterTab].title = e.target.value;
                      setDraftChapters(updated);
                    }}
                    placeholder={`Chương ${activeChapterTab + 1}: Tiêu đề chương...`}
                    className="w-full bg-[#0e1424] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-pink-500 font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Nội Dung Chương {draftChapters[activeChapterTab]?.number}:
                  </label>
                  <textarea
                    rows={6}
                    value={draftChapters[activeChapterTab]?.content || ''}
                    onChange={(e) => {
                      const updated = [...draftChapters];
                      updated[activeChapterTab].content = e.target.value;
                      setDraftChapters(updated);
                    }}
                    placeholder="Dán nội dung chương bản thảo vào đây..."
                    className="w-full bg-[#0e1424] border border-slate-700 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-pink-500 font-serif leading-relaxed"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Cam kết & Submit */}
          <div className="space-y-4 pt-2">
            <label className="flex items-start gap-2.5 cursor-pointer text-xs">
              <input
                type="checkbox"
                checked={agreedToPolicy}
                onChange={(e) => setAgreedToPolicy(e.target.checked)}
                className="rounded accent-pink-500 w-4 h-4 mt-0.5 cursor-pointer flex-shrink-0"
              />
              <span className="text-slate-300 leading-relaxed">
                Tôi cam kết toàn bộ thông tin đăng ký và bản thảo là chính xác, không vi phạm bản quyền hay thuần phong mỹ tục. Tôi đồng ý với chính sách trả thưởng và thẩm định của Đạo Tâm.
              </span>
            </label>

            <div className="flex items-center justify-between gap-4 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                Hủy bỏ
              </button>

              <button
                type="submit"
                disabled={isSuccess}
                className={`flex-1 py-3 px-6 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xl cursor-pointer transition-all ${
                  isSuccess
                    ? 'bg-emerald-600 text-white'
                    : 'bg-gradient-to-r from-pink-600 via-rose-600 to-indigo-600 hover:from-pink-500 hover:to-indigo-500 text-white shadow-pink-600/30 hover:scale-101'
                }`}
              >
                {isSuccess ? (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    <span>Đã Gửi Hồ Sơ Đăng Ký Thành Công!</span>
                  </>
                ) : (
                  <>
                    <BookPlus className="w-5 h-5" />
                    <span>Nộp Hồ Sơ Đăng Ký &amp; Gửi 5 Chương Bản Thảo</span>
                  </>
                )}
              </button>
            </div>
          </div>

        </form>

      </div>
    </div>
  );
};
