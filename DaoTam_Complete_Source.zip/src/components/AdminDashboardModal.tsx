import React, { useState } from 'react';
import { TopUpRequest, UserProfile, Novel, Chapter, NovelSubmission, WithdrawalRequest, NovelReport } from '../types';
import { parseBatchChapters, calculateChapterVip } from '../utils/rulesAndVoices';
import { 
  X, 
  ShieldCheck, 
  Coins, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  TrendingUp, 
  Users, 
  BookOpen, 
  Lock, 
  PlusCircle, 
  Sparkles, 
  Layers, 
  FileText, 
  BookPlus, 
  Eye,
  EyeOff,
  Trash2,
  AlertTriangle,
  Search,
  Edit3,
  Building2,
  Copy,
  Check,
  Percent,
  Sliders,
  FileCode2,
  QrCode,
  Flag,
  ShieldAlert,
  UserX
} from 'lucide-react';
import { DaoTamLogo } from './DaoTamLogo';

interface AdminDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  topUpRequests: TopUpRequest[];
  onApproveRequest: (requestId: string) => void;
  onRejectRequest: (requestId: string) => void;
  user: UserProfile;
  novels: Novel[];
  onAddBatchChapters: (novelId: string, chapters: Chapter[]) => void;
  novelSubmissions: NovelSubmission[];
  onApproveNovelSubmission: (submissionId: string) => void;
  onRejectNovelSubmission: (submissionId: string) => void;
  onToggleHideNovel?: (novelId: string) => void;
  onDeleteNovel?: (novelId: string) => void;
  onOpenEditNovel?: (novel: Novel) => void;
  withdrawalRequests?: WithdrawalRequest[];
  onApproveWithdrawal?: (requestId: string) => void;
  onRejectWithdrawal?: (requestId: string, reason?: string) => void;
  royaltyConfig?: { authorRate: number; editorRate: number; exclusiveRate: number };
  onUpdateRoyaltyConfig?: (config: { authorRate: number; editorRate: number; exclusiveRate: number }) => void;
  onOpenXmlModal?: () => void;
  onOpenArchitecture?: () => void;
  novelReports?: NovelReport[];
  onResolveReport?: (reportId: string, action: 'dismiss' | 'hide_novel' | 'delete_novel' | 'ban_author', novelId: string) => void;
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({
  isOpen,
  onClose,
  topUpRequests,
  onApproveRequest,
  onRejectRequest,
  user,
  novels,
  onAddBatchChapters,
  novelSubmissions,
  onApproveNovelSubmission,
  onRejectNovelSubmission,
  onToggleHideNovel,
  onDeleteNovel,
  onOpenEditNovel,
  withdrawalRequests = [],
  onApproveWithdrawal,
  onRejectWithdrawal,
  royaltyConfig = { authorRate: 95, editorRate: 70, exclusiveRate: 90 },
  onUpdateRoyaltyConfig,
  onOpenXmlModal,
  onOpenArchitecture,
  novelReports = [],
  onResolveReport,
}) => {
  const [activeTab, setActiveTab] = useState<'requests' | 'submissions' | 'payouts' | 'reports' | 'batch' | 'novels' | 'tools'>('requests');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved'>('pending');
  const [reportFilterStatus, setReportFilterStatus] = useState<'all' | 'pending' | 'resolved'>('pending');
  const [previewSubmission, setPreviewSubmission] = useState<NovelSubmission | null>(null);
  const [previewChapterIndex, setPreviewChapterIndex] = useState<number>(0);
  const [copiedStkId, setCopiedStkId] = useState<string | null>(null);

  // Novel Management state
  const [novelSearchQuery, setNovelSearchQuery] = useState('');
  const [novelStatusFilter, setNovelStatusFilter] = useState<'all' | 'visible' | 'hidden'>('all');
  const [confirmDeleteNovel, setConfirmDeleteNovel] = useState<Novel | null>(null);

  // Batch chapters state
  const [selectedNovelId, setSelectedNovelId] = useState<string>(novels[0]?.id || '');
  const [batchRawText, setBatchRawText] = useState('');
  const [batchSuccessMsg, setBatchSuccessMsg] = useState('');

  // Revenue Share rates
  const [authorRate, setAuthorRate] = useState(royaltyConfig.authorRate);
  const [editorRate, setEditorRate] = useState(royaltyConfig.editorRate);
  const [exclusiveRate, setExclusiveRate] = useState(royaltyConfig.exclusiveRate);
  const [configSaved, setConfigSaved] = useState(false);

  if (!isOpen) return null;

  const targetNovel = novels.find((n) => n.id === selectedNovelId) || novels[0];

  const filteredNovels = novels.filter((n) => {
    const q = novelSearchQuery.toLowerCase().trim();
    const matchesSearch = 
      !q ||
      n.title.toLowerCase().includes(q) ||
      n.author.toLowerCase().includes(q) ||
      (n.editor && n.editor.toLowerCase().includes(q));
    
    if (!matchesSearch) return false;
    if (novelStatusFilter === 'visible') return !n.isHidden;
    if (novelStatusFilter === 'hidden') return !!n.isHidden;
    return true;
  });

  const filteredRequests = topUpRequests.filter((r) => {
    if (filterStatus === 'all') return true;
    return r.status === filterStatus;
  });

  const pendingSubmissions = novelSubmissions.filter((s) => s.status === 'pending');
  const pendingTopUpCount = topUpRequests.filter((r) => r.status === 'pending').length;
  const pendingWithdrawalCount = withdrawalRequests.filter((w) => w.status === 'pending').length;
  const pendingReportsCount = novelReports.filter((r) => r.status === 'pending').length;

  const totalRevenueVnd = topUpRequests
    .filter((r) => r.status === 'approved')
    .reduce((acc, cur) => acc + cur.amountVnd, 0);

  const totalXuApproved = topUpRequests
    .filter((r) => r.status === 'approved')
    .reduce((acc, cur) => acc + cur.xuAmount, 0);

  const handleBatchPublish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetNovel || !batchRawText.trim()) return;

    const newChapters = parseBatchChapters(
      batchRawText,
      targetNovel.chapters.length,
      targetNovel.totalChapters + 50
    );

    if (newChapters.length > 0) {
      onAddBatchChapters(targetNovel.id, newChapters);
      setBatchSuccessMsg(`Đã đăng thành công hàng loạt ${newChapters.length} chương mới vào truyện "${targetNovel.title}"! Đã tự động phân loại VIP theo quy chuẩn.`);
      setBatchRawText('');
      setTimeout(() => setBatchSuccessMsg(''), 4000);
    }
  };

  const handleQuickGenerateDemo = (count: number) => {
    if (!targetNovel) return;
    const startNum = targetNovel.chapters.length + 1;

    let demoText = '';
    for (let i = 0; i < count; i++) {
      const num = startNum + i;
      demoText += `=== Chương ${num}: Diễn biến cao trào hồi mục ${num} ===\n\nGió thu thổi qua mái ngói lưu ly phủ đầy rêu phong. Nhân vật chính bước những bước đi vững chãi vào đại điện, ánh mắt ngập tràn sự kiên định sau chuỗi ngày khổ luyện gian nan.\n\n"Ngươi rốt cuộc đã chịu xuất hiện rồi sao?" Tiếng cười trầm thấp vang lên từ trong góc tối, báo hiệu một cuộc chạm trán không thể tránh khỏi.\n\n`;
    }
    setBatchRawText(demoText);
  };

  const handleCopyStk = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedStkId(id);
    setTimeout(() => setCopiedStkId(null), 2000);
  };

  const handleSaveRoyaltyConfig = (e: React.FormEvent) => {
    e.preventDefault();
    if (onUpdateRoyaltyConfig) {
      onUpdateRoyaltyConfig({ authorRate, editorRate, exclusiveRate });
    }
    setConfigSaved(true);
    setTimeout(() => setConfigSaved(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 text-slate-200">
      <div className="w-full max-w-5xl bg-[#090d16] border border-blue-500/40 rounded-2xl shadow-2xl flex flex-col h-[90vh] overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Top Header */}
        <div className="px-6 py-4 bg-[#0e1424] border-b border-blue-500/20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-sky-400 shadow-md">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-white flex items-center gap-2">
                Hệ Thống Quản Trị Admin &amp; Đối Soát Lương — Đạo Tâm
                {(pendingTopUpCount > 0 || pendingSubmissions.length > 0 || pendingWithdrawalCount > 0) && (
                  <span className="bg-rose-500 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-full animate-pulse">
                    {pendingTopUpCount + pendingSubmissions.length + pendingWithdrawalCount} việc cần xử lý
                  </span>
                )}
              </h2>
              <p className="text-xs text-sky-400">
                Kiểm duyệt truyện &amp; tác giả 5 chương, duyệt nạp xu, đối soát lương và duyệt lệnh rút nhuận bút
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-6 bg-[#0c101c] border-b border-slate-800 text-xs sm:text-sm overflow-x-auto">
          <button
            onClick={() => setActiveTab('requests')}
            className={`py-3 px-4 font-semibold border-b-2 flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'requests'
                ? 'border-blue-500 text-sky-300 bg-blue-600/15'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Coins className="w-4 h-4 text-sky-400" />
            <span>Duyệt Nạp Xu</span>
            {pendingTopUpCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] font-extrabold flex items-center justify-center">
                {pendingTopUpCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('submissions')}
            className={`py-3 px-4 font-semibold border-b-2 flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'submissions'
                ? 'border-blue-500 text-sky-300 bg-blue-600/15'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <BookOpen className="w-4 h-4 text-sky-400" />
            <span>Kiểm Duyệt Nội Dung &amp; Tác Giả (5 Chương)</span>
            {pendingSubmissions.length > 0 && (
              <span className="w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] font-extrabold flex items-center justify-center">
                {pendingSubmissions.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('payouts')}
            className={`py-3 px-4 font-semibold border-b-2 flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'payouts'
                ? 'border-emerald-500 text-emerald-300 bg-emerald-600/15'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Building2 className="w-4 h-4 text-emerald-400" />
            <span>Đối Soát Lương &amp; Duyệt Rút Xu</span>
            {pendingWithdrawalCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-emerald-500 text-white text-[10px] font-extrabold flex items-center justify-center animate-pulse">
                {pendingWithdrawalCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('reports')}
            className={`py-3 px-4 font-semibold border-b-2 flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'reports'
                ? 'border-rose-500 text-rose-300 bg-rose-600/15'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Flag className="w-4 h-4 text-rose-400" />
            <span>Báo Cáo Vi Phạm</span>
            {pendingReportsCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-rose-600 text-white text-[10px] font-extrabold flex items-center justify-center animate-pulse">
                {pendingReportsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('batch')}
            className={`py-3 px-4 font-semibold border-b-2 flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'batch'
                ? 'border-blue-500 text-sky-300 bg-blue-600/15'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <BookPlus className="w-4 h-4 text-sky-400" />
            <span>Đăng Chương Hàng Loạt</span>
          </button>

          <button
            onClick={() => setActiveTab('novels')}
            className={`py-3 px-4 font-semibold border-b-2 flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'novels'
                ? 'border-blue-500 text-sky-300 bg-blue-600/15'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-4 h-4 text-sky-400" />
            <span>Quản Lý Truyện ({novels.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('tools')}
            className={`py-3 px-4 font-semibold border-b-2 flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'tools'
                ? 'border-blue-500 text-sky-300 bg-blue-600/15'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <FileCode2 className="w-4 h-4 text-sky-400" />
            <span>Kiến Trúc Vercel &amp; Bảo Mật</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          
          {/* =========================================================================
              TAB 1: DUYỆT NẠP XU (TOP-UP QUEUE)
             ========================================================================= */}
          {activeTab === 'requests' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-4 rounded-xl bg-[#0e1424] border border-slate-800">
                  <div className="text-slate-400 text-xs">Tổng Doanh Thu Nạp:</div>
                  <div className="text-xl font-extrabold text-emerald-400 mt-1">
                    {totalRevenueVnd.toLocaleString('vi-VN')} VNĐ
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#0e1424] border border-slate-800">
                  <div className="text-slate-400 text-xs">Tổng Xu Đã Duyệt:</div>
                  <div className="text-xl font-extrabold text-sky-400 mt-1">
                    {totalXuApproved.toLocaleString('vi-VN')} Xu
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#0e1424] border border-slate-800">
                  <div className="text-slate-400 text-xs">Yêu Cầu Chờ Duyệt:</div>
                  <div className="text-xl font-extrabold text-rose-400 mt-1">
                    {pendingTopUpCount} lệnh nạp
                  </div>
                </div>
              </div>

              {filteredRequests.length === 0 ? (
                <div className="text-center py-12 text-slate-500 text-xs">
                  Không có yêu cầu nạp tiền nào theo bộ lọc.
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredRequests.map((req) => (
                    <div
                      key={req.id}
                      className="p-4 rounded-xl bg-[#0e1424] border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">
                            {req.userName}
                          </span>
                          <span className="text-xs text-slate-400">
                            ({req.userEmail})
                          </span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            req.status === 'approved' 
                              ? 'bg-emerald-500/20 text-emerald-300' 
                              : req.status === 'rejected'
                              ? 'bg-rose-500/20 text-rose-300'
                              : 'bg-amber-500/20 text-amber-300'
                          }`}>
                            {req.status === 'approved' ? 'Đã duyệt' : req.status === 'rejected' ? 'Đã từ chối' : 'Chờ duyệt'}
                          </span>
                        </div>

                        <div className="text-xs text-slate-300 flex items-center gap-3">
                          <span>Số tiền: <strong className="text-emerald-400">{req.amountVnd.toLocaleString('vi-VN')} đ</strong></span>
                          <span>Cộng ví: <strong className="text-sky-300">{req.xuAmount} Xu</strong></span>
                          <span>Mã GD: <strong className="font-mono text-sky-400">{req.transferCode}</strong></span>
                        </div>
                      </div>

                      {req.status === 'pending' && (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => onApproveRequest(req.id)}
                            className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Duyệt Ngay (+{req.xuAmount} Xu)
                          </button>
                          <button
                            onClick={() => onRejectRequest(req.id)}
                            className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300 font-semibold text-xs cursor-pointer"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            Từ chối
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* =========================================================================
              TAB 2: KIỂM DUYỆT NỘI DUNG & ĐƠN ĐĂNG KÝ TÁC GIẢ (KÈM 5 CHƯƠNG MẪU & STK)
             ========================================================================= */}
          {activeTab === 'submissions' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/30 text-xs text-blue-200">
                <strong>Quy chuẩn kiểm duyệt Tác Giả &amp; Editor:</strong> Độc giả khi muốn nâng cấp thành Tác giả/Editor phải nộp hồ sơ gồm thông tin STK ngân hàng nhận tiền và ít nhất 5 chương bản thảo mẫu để Admin thẩm định chất lượng. Khi được duyệt, tài khoản sẽ được nâng cấp thành Tác giả chính thức và truyện được xuất bản ra trang chủ.
              </div>

              {novelSubmissions.length === 0 ? (
                <div className="text-center py-12 text-slate-500 text-xs">
                  Hiện không có đơn đăng ký hoặc bản thảo nào đang chờ duyệt.
                </div>
              ) : (
                <div className="space-y-4">
                  {novelSubmissions.map((sub) => (
                    <div
                      key={sub.id}
                      className="p-4 rounded-xl bg-[#0e1424] border border-slate-800 flex flex-col md:flex-row gap-4 items-start"
                    >
                      <img
                        src={sub.coverImage}
                        alt={sub.title}
                        className="w-20 h-28 object-cover rounded-lg border border-slate-700 flex-shrink-0"
                      />

                      <div className="flex-1 min-w-0 space-y-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-serif text-base font-bold text-white">
                            {sub.title}
                          </h4>
                          {sub.isCreatorApplication && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-pink-500/20 text-pink-300 border border-pink-500/40 flex items-center gap-1">
                              <span>✍️</span> Đơn Đăng Ký Tác Giả / Editor Mới
                            </span>
                          )}
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                            {sub.mainCategory}
                          </span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            sub.status === 'approved' 
                              ? 'bg-emerald-500/20 text-emerald-300' 
                              : sub.status === 'rejected'
                              ? 'bg-rose-500/20 text-rose-300'
                              : 'bg-amber-500/20 text-amber-300'
                          }`}>
                            {sub.status === 'approved' ? 'Đã duyệt' : sub.status === 'rejected' ? 'Đã từ chối' : 'Chờ thẩm định'}
                          </span>
                        </div>

                        <div className="text-xs text-slate-300">
                          Bút danh: <strong className="text-sky-300">{sub.author}</strong>
                          {sub.editor && <> • Editor: <strong className="text-pink-300">{sub.editor}</strong></>}
                          {' '}• Tài khoản nộp: <span className="text-slate-400">{sub.submittedBy.userName} ({sub.submittedBy.userEmail})</span>
                        </div>

                        {sub.bankInfo && (
                          <div className="p-2.5 rounded-lg bg-black/50 border border-slate-800 text-[11px] text-slate-300 flex items-center gap-3">
                            <Building2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                            <span>STK Nhận Nhuận Bút: <strong>{sub.bankInfo.accountNumber}</strong> ({sub.bankInfo.bankName}) • Chủ thẻ: <strong>{sub.bankInfo.accountHolder}</strong></span>
                          </div>
                        )}

                        <p className="text-xs text-slate-400 line-clamp-2">
                          {sub.description}
                        </p>

                        <div className="flex items-center gap-2 pt-1 flex-wrap">
                          <span className="text-[11px] font-semibold text-amber-400 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                            <FileText className="w-3 h-3" />
                            Bản thảo: {sub.chapters?.length || 5} chương thẩm định
                          </span>

                          <button
                            onClick={() => {
                              setPreviewSubmission(sub);
                              setPreviewChapterIndex(0);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-300 text-xs flex items-center gap-1 cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            Đọc Thẩm Định 5 Chương
                          </button>
                        </div>
                      </div>

                      {sub.status === 'pending' && (
                        <div className="flex flex-col gap-2 w-full md:w-auto">
                          <button
                            onClick={() => onApproveNovelSubmission(sub.id)}
                            className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md cursor-pointer transition-all hover:scale-102"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            Duyệt &amp; Nâng Cấp Tác Giả
                          </button>

                          <button
                            onClick={() => onRejectNovelSubmission(sub.id)}
                            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <XCircle className="w-4 h-4" />
                            Từ chối đơn
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* =========================================================================
              TAB 3: ĐỐI SOÁT LƯƠNG & DUYỆT RÚT XU NHUẬN BÚT (PAYOUT MANAGEMENT)
             ========================================================================= */}
          {activeTab === 'payouts' && (
            <div className="space-y-6">
              
              {/* Configuration Section: Revenue Sharing Rates */}
              <div className="p-4 rounded-xl bg-[#0e1424] border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-emerald-400" />
                    Cấu Hình Tỷ Lệ Chia Sẻ Doanh Thu Nhuận Bút
                  </h3>
                  {configSaved && (
                    <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Đã lưu cấu hình tỷ lệ!
                    </span>
                  )}
                </div>

                <form onSubmit={handleSaveRoyaltyConfig} className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Tác Giả Sáng Tác:</label>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        min="50"
                        max="100"
                        value={authorRate}
                        onChange={(e) => setAuthorRate(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-black border border-slate-700 text-xs font-bold text-white"
                      />
                      <span className="text-xs text-slate-400">%</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Editor Không Độc Quyền:</label>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        min="50"
                        max="100"
                        value={editorRate}
                        onChange={(e) => setEditorRate(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-black border border-slate-700 text-xs font-bold text-white"
                      />
                      <span className="text-xs text-slate-400">%</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Editor Độc Quyền:</label>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        min="50"
                        max="100"
                        value={exclusiveRate}
                        onChange={(e) => setExclusiveRate(Number(e.target.value))}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-black border border-slate-700 text-xs font-bold text-white"
                      />
                      <span className="text-xs text-slate-400">%</span>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="py-1.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs cursor-pointer shadow"
                  >
                    Cập Nhật Tỷ Lệ
                  </button>
                </form>
              </div>

              {/* Moderation Payout Requests Table */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-emerald-400" />
                    Danh Sách Yêu Cầu Rút Xu Nhuận Bút (Đủ &gt;= 100 Xu)
                  </h3>
                  <span className="text-xs text-slate-400">
                    Quy chuẩn: 1 Xu = 1,000 VNĐ
                  </span>
                </div>

                {withdrawalRequests.length === 0 ? (
                  <div className="p-8 rounded-xl bg-[#0e1424] text-xs text-slate-500 text-center">
                    Hiện chưa có yêu cầu rút tiền nào từ tác giả hoặc editor.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {withdrawalRequests.map((req) => (
                      <div
                        key={req.id}
                        className="p-4 rounded-xl bg-[#0e1424] border border-slate-800 space-y-3"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-white text-sm">
                                {req.authorName}
                              </span>
                              <span className="text-xs text-slate-400">
                                ({req.authorEmail})
                              </span>
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                req.status === 'approved'
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                  : req.status === 'rejected'
                                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                              }`}>
                                {req.status === 'approved' ? '✅ Đã thanh toán' : req.status === 'rejected' ? '❌ Từ chối' : '⏳ Chờ chuyển khoản'}
                              </span>
                            </div>

                            <div className="text-xs text-slate-300 mt-1 flex items-center gap-4 flex-wrap">
                              <span>Số xu rút: <strong className="text-emerald-400 text-sm font-extrabold">{req.amountXu} Xu</strong></span>
                              <span>Số tiền VNĐ cần chuyển: <strong className="text-pink-400 text-sm font-extrabold">{req.amountVnd.toLocaleString('vi-VN')} VNĐ</strong></span>
                              <span>Số xu còn lại sau khi rút: <strong className="text-sky-300 font-bold">{req.remainingXu} Xu</strong></span>
                            </div>
                          </div>

                          <div className="text-[11px] text-slate-500">
                            Thời gian: {new Date(req.createdAt).toLocaleString('vi-VN')}
                          </div>
                        </div>

                        {/* STK Details Box */}
                        <div className="p-3 rounded-lg bg-black/60 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                          <div className="space-y-0.5">
                            <div className="text-slate-400">
                              Ngân hàng: <strong className="text-white">{req.bankName}</strong>
                            </div>
                            <div className="text-slate-400 flex items-center gap-2">
                              <span>Số tài khoản (STK): <strong className="text-emerald-400 font-mono text-sm">{req.accountNumber}</strong></span>
                              <button
                                onClick={() => handleCopyStk(req.id, req.accountNumber)}
                                className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
                                title="Sao chép STK"
                              >
                                {copiedStkId === req.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                              </button>
                            </div>
                            <div className="text-slate-400">
                              Chủ tài khoản: <strong className="text-white uppercase">{req.accountHolder}</strong>
                            </div>
                            {req.note && (
                              <div className="text-[11px] text-slate-400 italic">
                                Ghi chú: "{req.note}"
                              </div>
                            )}
                          </div>

                          {req.status === 'pending' && onApproveWithdrawal && (
                            <div className="flex items-center gap-2 flex-shrink-0">
                              <button
                                onClick={() => onApproveWithdrawal(req.id)}
                                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md cursor-pointer transition-all hover:scale-102"
                              >
                                <CheckCircle2 className="w-4 h-4" />
                                <span>Xác Nhận ĐÃ CHUYỂN KHOẢN &amp; Duyệt</span>
                              </button>

                              {onRejectWithdrawal && (
                                <button
                                  onClick={() => onRejectWithdrawal(req.id)}
                                  className="px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300 text-xs font-semibold cursor-pointer"
                                >
                                  Từ chối
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          )}

          {/* =========================================================================
              TAB: BÁO CÁO VI PHẠM TÁC PHẨM (BẢN QUYỀN, 18+, REUP, BÔI NHỌ VN, KHÁC)
             ========================================================================= */}
          {activeTab === 'reports' && (
            <div className="space-y-5">
              {/* Strict Policy Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-950/80 via-red-950/70 to-slate-900 border border-rose-500/40 text-rose-200 text-xs shadow-md">
                <div className="flex items-start gap-3">
                  <ShieldAlert className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <strong className="text-white uppercase font-bold tracking-wider block text-xs">
                      Quy chế xử lý vi phạm tác quyền &amp; nội dung Đạo Tâm:
                    </strong>
                    <p className="text-rose-100/90 leading-relaxed font-medium">
                      "Các tác giả, editor không được phép đăng truyện bản quyền, truyện 18+, không tự ý cố tình xóa chương đăng lại để hiện truyện lên trang. Ai vi phạm và có xác nhận từ web sẽ bị cấm vĩnh viễn, doanh thu tháng đó cũng sẽ mất. Các team lưu ý giúp mình."
                    </p>
                  </div>
                </div>
              </div>

              {/* Filter controls */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400 font-semibold">Lọc trạng thái:</span>
                  <div className="flex items-center bg-[#0e1424] p-1 rounded-xl border border-slate-800 text-xs">
                    {(['pending', 'resolved', 'all'] as const).map((st) => (
                      <button
                        key={st}
                        onClick={() => setReportFilterStatus(st)}
                        className={`px-3 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                          reportFilterStatus === st
                            ? 'bg-rose-600 text-white shadow-sm'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {st === 'pending' ? 'Chờ xử lý' : st === 'resolved' ? 'Đã giải quyết' : 'Tất cả'}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="text-xs text-slate-400">
                  Tổng cộng: <strong className="text-white">{novelReports.length}</strong> báo cáo ({pendingReportsCount} đang chờ xử lý)
                </div>
              </div>

              {/* Reports List */}
              {novelReports.filter((r) => {
                if (reportFilterStatus === 'all') return true;
                return r.status === reportFilterStatus;
              }).length === 0 ? (
                <div className="p-10 rounded-2xl bg-[#0e1424] border border-slate-800 text-center space-y-2">
                  <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                  <h4 className="font-bold text-sm text-white">Không Có Báo Cáo Vi Phạm Nào Cần Xử Lý</h4>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto">
                    Toàn bộ tác phẩm trên sàn hiện tại đều tuân thủ tốt chính sách bản quyền và chuẩn mực nội dung.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {novelReports
                    .filter((r) => {
                      if (reportFilterStatus === 'all') return true;
                      return r.status === reportFilterStatus;
                    })
                    .map((report) => {
                      const targetNovel = novels.find((n) => n.id === report.novelId);
                      return (
                        <div
                          key={report.id}
                          className="p-4 sm:p-5 rounded-2xl bg-[#0e1424] border border-slate-800 hover:border-rose-500/40 transition-all space-y-3.5 shadow-md"
                        >
                          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                            <div className="flex items-start gap-3.5">
                              {report.novelCover ? (
                                <img
                                  src={report.novelCover}
                                  alt={report.novelTitle}
                                  className="w-12 h-16 object-cover rounded-lg border border-slate-700 flex-shrink-0 shadow"
                                />
                              ) : (
                                <div className="w-12 h-16 rounded-lg bg-slate-800 flex items-center justify-center text-slate-500 flex-shrink-0">
                                  <BookOpen className="w-5 h-5" />
                                </div>
                              )}

                              <div>
                                <div className="flex items-center gap-2 flex-wrap mb-1">
                                  <span className={`text-[11px] font-extrabold px-2 py-0.5 rounded-full border ${
                                    report.reason === 'Truyện bản quyền'
                                      ? 'bg-amber-950/70 text-amber-300 border-amber-500/40'
                                      : report.reason === 'Truyện 18+'
                                      ? 'bg-rose-950/70 text-rose-300 border-rose-500/40'
                                      : report.reason === 'Truyện reup'
                                      ? 'bg-orange-950/70 text-orange-300 border-orange-500/40'
                                      : report.reason === 'Truyện bôi nhọ Việt Nam'
                                      ? 'bg-red-950/80 text-red-300 border-red-500/50'
                                      : 'bg-sky-950/70 text-sky-300 border-sky-500/40'
                                  }`}>
                                    🚩 {report.reason}
                                  </span>

                                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                    report.status === 'pending'
                                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse'
                                      : 'bg-slate-700 text-slate-300'
                                  }`}>
                                    {report.status === 'pending' ? 'Chờ thẩm định' : 'Đã giải quyết'}
                                  </span>

                                  {targetNovel?.isHidden && (
                                    <span className="text-[10px] bg-purple-950 text-purple-300 px-2 py-0.5 rounded border border-purple-500/40 font-bold">
                                      Đã ẩn khỏi trang chủ
                                    </span>
                                  )}
                                </div>

                                <h4 className="font-bold text-sm sm:text-base text-white">
                                  {report.novelTitle}
                                </h4>

                                <div className="text-xs text-slate-400 mt-0.5">
                                  Tác giả: <strong className="text-sky-300">{report.author}</strong>
                                </div>
                              </div>
                            </div>

                            <div className="text-right text-[11px] text-slate-400">
                              <div>Người gửi: <strong className="text-slate-200">{report.reporterName || 'Độc giả'}</strong></div>
                              {report.reporterEmail && <div className="text-slate-500">{report.reporterEmail}</div>}
                              <div className="text-slate-500 mt-1">{new Date(report.createdAt).toLocaleString('vi-VN')}</div>
                            </div>
                          </div>

                          {/* Reason details */}
                          {report.details && (
                            <div className="p-3 rounded-xl bg-black/50 border border-slate-800 text-xs text-slate-300 leading-relaxed font-sans">
                              <span className="text-slate-400 font-semibold block mb-0.5">Nội dung phản ánh từ người dùng:</span>
                              "{report.details}"
                            </div>
                          )}

                          {/* Admin Resolution Toolbar */}
                          <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2.5">
                            <span className="text-[11px] text-slate-400 italic">
                              Hành động quản trị viên:
                            </span>

                            <div className="flex items-center gap-2 flex-wrap">
                              {/* 1. Toggle Hide Novel */}
                              {onToggleHideNovel && targetNovel && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    onToggleHideNovel(report.novelId);
                                    if (onResolveReport) onResolveReport(report.id, 'hide_novel', report.novelId);
                                  }}
                                  className="px-3 py-1.5 rounded-lg bg-purple-600/20 hover:bg-purple-600/40 text-purple-300 border border-purple-500/40 font-semibold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                                  title="Ẩn truyện khỏi độc giả để kiểm tra"
                                >
                                  {targetNovel.isHidden ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                                  <span>{targetNovel.isHidden ? 'Mở Lại Truyện' : 'Ẩn Truyện Ngay'}</span>
                                </button>
                              )}

                              {/* 2. Permanent Ban Author & Forfeit monthly revenue */}
                              {onResolveReport && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (window.confirm(`Xác nhận xử phạt vi phạm: Cấm vĩnh viễn tài khoản của "${report.author}", tịch thu toàn bộ doanh thu tháng này theo quy chế web?`)) {
                                      onResolveReport(report.id, 'ban_author', report.novelId);
                                    }
                                  }}
                                  className="px-3 py-1.5 rounded-lg bg-rose-950/70 hover:bg-rose-900 text-rose-300 border border-rose-500/40 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                                  title="Cấm tác giả vĩnh viễn & tịch thu toàn bộ doanh thu tháng đó"
                                >
                                  <UserX className="w-3.5 h-3.5 text-rose-400" />
                                  <span>Cấm Vĩnh Viễn &amp; Hủy Nhuận Bút</span>
                                </button>
                              )}

                              {/* 3. Delete Novel Permanently */}
                              {onDeleteNovel && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (window.confirm(`Bạn có chắc chắn muốn xóa vĩnh viễn truyện "${report.novelTitle}" khỏi hệ thống không?`)) {
                                      onDeleteNovel(report.novelId);
                                      if (onResolveReport) onResolveReport(report.id, 'delete_novel', report.novelId);
                                    }
                                  }}
                                  className="px-3 py-1.5 rounded-lg bg-rose-600/20 hover:bg-rose-600/40 text-rose-300 border border-rose-500/30 font-semibold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                                  title="Xóa truyện vi phạm vĩnh viễn"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>Xóa Truyện</span>
                                </button>
                              )}

                              {/* 4. Dismiss / Mark Resolved */}
                              {report.status === 'pending' && onResolveReport && (
                                <button
                                  type="button"
                                  onClick={() => onResolveReport(report.id, 'dismiss', report.novelId)}
                                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors shadow"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                  <span>Đã Xác Minh / Bỏ Qua</span>
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          )}

          {/* =========================================================================
              TAB 4: ĐĂNG CHƯƠNG HÀNG LOẠT
             ========================================================================= */}
          {activeTab === 'batch' && (
            <div className="space-y-4">
              {batchSuccessMsg && (
                <div className="p-3.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{batchSuccessMsg}</span>
                </div>
              )}

              <form onSubmit={handleBatchPublish} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Chọn tác phẩm cần đăng thêm chương hàng loạt:
                  </label>
                  <select
                    value={selectedNovelId}
                    onChange={(e) => setSelectedNovelId(e.target.value)}
                    className="w-full bg-[#181924] border border-slate-700 focus:border-sky-500 rounded-xl p-2.5 text-xs text-slate-200 cursor-pointer"
                  >
                    {novels.map((n) => (
                      <option key={n.id} value={n.id}>
                        {n.title} (Hiện có: {n.chapters.length}/{n.totalChapters} chương)
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <label className="block text-xs font-semibold text-slate-300">
                    Dán nội dung nhiều chương (Cấu trúc: === Chương [X]: Tiêu đề ===):
                  </label>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-500">Mẫu thử nhanh:</span>
                    <button
                      type="button"
                      onClick={() => handleQuickGenerateDemo(5)}
                      className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-sky-300 text-[11px] cursor-pointer"
                    >
                      + 5 Chương mẫu
                    </button>
                    <button
                      type="button"
                      onClick={() => handleQuickGenerateDemo(20)}
                      className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-sky-300 text-[11px] cursor-pointer"
                    >
                      + 20 Chương mẫu
                    </button>
                  </div>
                </div>

                <textarea
                  value={batchRawText}
                  onChange={(e) => setBatchRawText(e.target.value)}
                  placeholder="Dán toàn bộ văn bản của hàng chục chương vào đây..."
                  rows={9}
                  className="w-full bg-[#151620] border border-slate-700 focus:border-sky-500 rounded-xl p-3 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none"
                />

                <button
                  type="submit"
                  disabled={!batchRawText.trim()}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 text-white font-bold text-sm shadow-xl flex items-center justify-center gap-2 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                >
                  <PlusCircle className="w-4 h-4" />
                  Đăng Tự Động Toàn Bộ Chương (Áp Dụng Phân Quyền VIP Chuẩn)
                </button>
              </form>
            </div>
          )}

          {/* =========================================================================
              TAB 5: QUẢN LÝ TRUYỆN (ẨN & XÓA)
             ========================================================================= */}
          {activeTab === 'novels' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#090d16] p-4 rounded-xl border border-slate-800">
                <div className="flex-1 max-w-md relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={novelSearchQuery}
                    onChange={(e) => setNovelSearchQuery(e.target.value)}
                    placeholder="Tìm theo tên truyện, tác giả, editor..."
                    className="w-full bg-[#0e1424] border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div className="flex items-center gap-2">
                  {(['all', 'visible', 'hidden'] as const).map((st) => (
                    <button
                      key={st}
                      onClick={() => setNovelStatusFilter(st)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                        novelStatusFilter === st
                          ? 'bg-blue-600 text-white shadow-md'
                          : 'bg-[#0e1424] text-slate-400 hover:text-white border border-slate-800'
                      }`}
                    >
                      {st === 'all' 
                        ? `Tất cả (${novels.length})` 
                        : st === 'visible' 
                        ? `Đang hiện (${novels.filter((n) => !n.isHidden).length})` 
                        : `Đã ẩn (${novels.filter((n) => n.isHidden).length})`}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2.5">
                {filteredNovels.map((novel) => (
                  <div
                    key={novel.id}
                    className="p-3.5 rounded-xl bg-[#0e1424] border border-slate-800 hover:border-blue-500/40 flex items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={novel.coverImage}
                        alt={novel.title}
                        className="w-12 h-16 object-cover rounded-lg border border-slate-700 flex-shrink-0"
                      />
                      <div className="min-w-0">
                        <h4 className="font-bold text-sm text-white truncate">
                          {novel.title}
                        </h4>
                        <div className="text-xs text-slate-400">
                          Tác giả: {novel.author} • {novel.chapters.length} chương • {novel.views.toLocaleString()} lượt xem
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {onOpenEditNovel && (
                        <button
                          onClick={() => onOpenEditNovel(novel)}
                          className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-300 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          Sửa
                        </button>
                      )}

                      {onToggleHideNovel && (
                        <button
                          onClick={() => onToggleHideNovel(novel.id)}
                          className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer ${
                            novel.isHidden 
                              ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/40' 
                              : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                          }`}
                        >
                          {novel.isHidden ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                          {novel.isHidden ? 'Hiện truyện' : 'Ẩn truyện'}
                        </button>
                      )}

                      {onDeleteNovel && (
                        <button
                          onClick={() => setConfirmDeleteNovel(novel)}
                          className="p-1.5 rounded-lg hover:bg-rose-950 text-slate-400 hover:text-rose-400 cursor-pointer"
                          title="Xóa truyện"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* =========================================================================
              TAB 6: CÔNG CỤ NỘI BỘ (ẨN KHỎI KHÁCH VÀ ĐỘC GIẢ TRANG CHỦ)
             ========================================================================= */}
          {activeTab === 'tools' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/30 text-xs text-blue-200">
                <strong>Khu vực công cụ kỹ thuật dành riêng cho Admin:</strong> Các chức năng này đã được ẩn hoàn toàn khỏi người dùng và độc giả bên ngoài để bảo vệ tính bảo mật và trải nghiệm gọn gàng cho trang web.
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-5 rounded-2xl bg-[#0e1424] border border-slate-800 space-y-3">
                  <div className="w-10 h-10 rounded-xl bg-sky-600/20 border border-sky-500/40 flex items-center justify-center text-sky-400">
                    <FileCode2 className="w-5 h-5" />
                  </div>
                  <h4 className="font-bold text-sm text-white">Kiến Trúc Vercel Serverless &amp; API Bảo Mật</h4>
                  <p className="text-xs text-slate-400">
                    Toàn bộ logic trừ Xu, kiểm tra quyền VIP, trả nội dung đã mã hóa và chia nhuận bút được chạy trên môi trường Server an toàn chống can thiệp.
                  </p>
                  {onOpenArchitecture && (
                    <button
                      onClick={() => {
                        onClose();
                        onOpenArchitecture();
                      }}
                      className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer shadow"
                    >
                      Xem Hồ Sơ Kiến Trúc Vercel
                    </button>
                  )}
                </div>

                <div className="p-5 rounded-2xl bg-[#0e1424] border border-slate-800 space-y-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
                    <Layers className="w-5 h-5" />
                  </div>
                  <h4 className="font-bold text-sm text-white">Âm Thanh Edge TTS Chunking &amp; DRM Bản Quyền</h4>
                  <p className="text-xs text-slate-400">
                    Công nghệ chia nhỏ câu thông minh, phát đoạn 1 ngay lập tức, tải ngầm đoạn kế tiếp và đồng bộ Karaoke highlight chính xác 100%.
                  </p>
                  {onOpenArchitecture && (
                    <button
                      onClick={() => {
                        onClose();
                        onOpenArchitecture();
                      }}
                      className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs cursor-pointer shadow"
                    >
                      Xem Ma Trận Bảo Mật DRM
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

        </div>

      </div>

      {/* Delete Confirmation Modal */}
      {confirmDeleteNovel && (
        <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-[#121420] border border-rose-500/50 p-6 rounded-2xl max-w-sm w-full space-y-4">
            <h4 className="font-bold text-base text-white flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-rose-500" />
              Xác Nhận Xóa Truyện
            </h4>
            <p className="text-xs text-slate-300">
              Bạn có chắc chắn muốn xóa tác phẩm <strong>"{confirmDeleteNovel.title}"</strong> không? Hành động này không thể hoàn tác.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setConfirmDeleteNovel(null)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                Hủy
              </button>
              <button
                onClick={() => {
                  if (onDeleteNovel) onDeleteNovel(confirmDeleteNovel.id);
                  setConfirmDeleteNovel(null);
                }}
                className="px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold cursor-pointer"
              >
                Xóa Vĩnh Viễn
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5-Chapter Preview Modal */}
      {previewSubmission && (
        <div className="fixed inset-0 z-60 bg-black/85 flex items-center justify-center p-4">
          <div className="bg-[#0e1424] border border-blue-500/50 rounded-2xl max-w-2xl w-full p-6 max-h-[85vh] flex flex-col space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h4 className="font-serif font-bold text-base text-white">
                Thẩm Định Bản Thảo: "{previewSubmission.title}"
              </h4>
              <button
                onClick={() => setPreviewSubmission(null)}
                className="p-1 rounded text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Chapter tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {(previewSubmission.chapters || []).map((ch: any, idx: number) => (
                <button
                  key={idx}
                  onClick={() => setPreviewChapterIndex(idx)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold whitespace-nowrap cursor-pointer ${
                    previewChapterIndex === idx
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-800 text-slate-300 hover:text-white'
                  }`}
                >
                  Chương {ch.number}
                </button>
              ))}
            </div>

            {/* Chapter Content Preview */}
            <div className="flex-1 overflow-y-auto p-4 rounded-xl bg-black/50 border border-slate-800 font-serif text-xs sm:text-sm text-slate-200 leading-relaxed">
              <h5 className="font-bold text-sm text-sky-300 mb-2">
                {previewSubmission.chapters?.[previewChapterIndex]?.title || `Chương ${previewChapterIndex + 1}`}
              </h5>
              <div className="whitespace-pre-line">
                {previewSubmission.chapters?.[previewChapterIndex]?.content || 'Chưa có nội dung'}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => {
                  onApproveNovelSubmission(previewSubmission.id);
                  setPreviewSubmission(null);
                }}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs cursor-pointer shadow"
              >
                Duyệt Bản Thảo Này
              </button>
              <button
                onClick={() => setPreviewSubmission(null)}
                className="px-3 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
