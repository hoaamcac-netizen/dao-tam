import React, { useState, useEffect, useRef } from 'react';
import { Novel, Chapter, ReaderSettings, ReadingProgress, UserProfile } from '../types';
import { 
  EDGE_TTS_VOICES, 
  fetchAvailableEdgeVoices, 
  normalizeEdgeVoiceId 
} from '../utils/rulesAndVoices';
import { useSeamlessTTS } from '../hooks/useSeamlessTTS';
import { backgroundAudioManager } from '../utils/backgroundAudio';
import { CommentsSection } from './CommentsSection';
import { 
  ArrowLeft, 
  ChevronLeft, 
  ChevronRight, 
  Sliders, 
  Headphones, 
  List, 
  Bookmark, 
  BookmarkCheck, 
  Play, 
  Pause, 
  Lock, 
  Coins, 
  ShieldAlert, 
  ShieldCheck,
  Smartphone,
  Sparkles, 
  X, 
  Volume2, 
  SkipBack, 
  SkipForward,
  Mic,
  Flag,
  FastForward
} from 'lucide-react';

interface ChapterReaderProps {
  novel: Novel;
  chapter: Chapter;
  readerSettings: ReaderSettings;
  setReaderSettings: React.Dispatch<React.SetStateAction<ReaderSettings>>;
  onSelectChapter: (novel: Novel, chapter: Chapter) => void;
  onBackToNovel: () => void;
  onSaveProgress: (progress: ReadingProgress) => void;
  user: UserProfile;
  onOpenVipPurchase: (novel: Novel, chapter: Chapter) => void;
  onOpenTopUp: () => void;
  onOpenReport?: (novel: Novel) => void;
}

export const ChapterReader: React.FC<ChapterReaderProps> = ({
  novel,
  chapter,
  readerSettings,
  setReaderSettings,
  onSelectChapter,
  onBackToNovel,
  onSaveProgress,
  user,
  onOpenVipPurchase,
  onOpenTopUp,
  onOpenReport,
}) => {
  const [scrollProgress, setScrollProgress] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const [showChapterDrawer, setShowChapterDrawer] = useState(false);
  const [savedToast, setSavedToast] = useState(false);
  const [drmWarning, setDrmWarning] = useState<string | null>(null);
  const [isWindowBlurred, setIsWindowBlurred] = useState(false);
  const [showSecurityModal, setShowSecurityModal] = useState(false);
  const [availableVoices, setAvailableVoices] = useState(EDGE_TTS_VOICES);

  const sentenceRefs = useRef<(HTMLSpanElement | null)[]>([]);
  const shouldAutoPlayRef = useRef<boolean>(false);

  // Kiểm tra quyền mở khóa chương VIP
  const isFullBookUnlocked = user.unlockedFullBooks.includes(novel.id);
  const isChapterUnlocked =
    !chapter.isVip ||
    isFullBookUnlocked ||
    (user.unlockedChapters[novel.id] && user.unlockedChapters[novel.id].includes(chapter.id));

  // Điều hướng chương trước / sau
  const currentIndex = novel.chapters.findIndex((c) => c.id === chapter.id);
  const prevChapter = currentIndex > 0 ? novel.chapters[currentIndex - 1] : null;
  const nextChapter = currentIndex < novel.chapters.length - 1 ? novel.chapters[currentIndex + 1] : null;

  // Quét danh sách giọng Edge TTS tiếng Việt thực tế
  useEffect(() => {
    fetchAvailableEdgeVoices().then((voices) => {
      if (voices && voices.length > 0) {
        setAvailableVoices(voices);
      }
    });
  }, []);

  // TÍCH HỢP CUSTOM HOOK: useSeamlessTTS (Không độ trễ, không gián đoạn, hàng đợi prefetch ngầm)
  const {
    chunks,
    currentChunkIndex,
    currentChunk,
    isPlaying: isTtsPlaying,
    isLoading: isTtsLoading,
    playbackRate,
    voiceId: activeVoiceId,
    progress: ttsProgress,
    bufferedIndices,
    error: ttsError,
    play: playTts,
    pause: pauseTts,
    togglePlay: toggleTtsPlay,
    stop: stopTts,
    seekToChunk,
    skipNext: skipNextTts,
    skipPrev: skipPrevTts,
    setVoiceId,
    setPlaybackRate,
  } = useSeamlessTTS({
    content: isChapterUnlocked ? chapter.content || '' : '',
    initialVoiceId: readerSettings.selectedVoiceId || 'vi-VN-HoaiMyNeural',
    initialPlaybackRate: readerSettings.voiceSpeed || 1.0,
    onChunkChange: (index) => {
      // Tự động cuộn mượt mà đưa câu đang phát vào giữa màn hình (Karaoke auto-scroll)
      if (sentenceRefs.current[index]) {
        sentenceRefs.current[index]?.scrollIntoView({
          behavior: 'smooth',
          block: 'center',
        });
      }
    },
    onComplete: () => {
      // Tự động chuyển chương kế tiếp nếu người dùng bật tùy chọn
      if (readerSettings.autoNextChapter && nextChapter) {
        const unlocked =
          !nextChapter.isVip ||
          isFullBookUnlocked ||
          (user.unlockedChapters[novel.id] && user.unlockedChapters[novel.id].includes(nextChapter.id));

        if (unlocked) {
          shouldAutoPlayRef.current = true;
          onSelectChapter(novel, nextChapter);
        } else {
          setDrmWarning(
            `Đã đọc xong chương ${chapter.number}. Chương tiếp theo là chương VIP, vui lòng mở khóa để tiếp tục!`
          );
          setTimeout(() => setDrmWarning(null), 4000);
        }
      }
    },
  });

  // Tự động kích hoạt Play chương mới khi tự động chuyển chương
  useEffect(() => {
    if (shouldAutoPlayRef.current && isChapterUnlocked) {
      shouldAutoPlayRef.current = false;
      const playTimer = setTimeout(() => {
        playTts(0).catch((err) => {
          console.warn('[ChapterReader] Auto-play next chapter caught:', err);
        });
      }, 400);
      return () => clearTimeout(playTimer);
    }
  }, [chapter.id, isChapterUnlocked, playTts]);

  // Đồng bộ Background Audio & Lock Screen Media Session
  useEffect(() => {
    if (isTtsPlaying && currentChunkIndex >= 0) {
      backgroundAudioManager.startBackgroundPlayback({
        title: `${novel.title} - ${chapter.title}`,
        artist: `Tác giả: ${novel.author} • Giọng: ${
          activeVoiceId.includes('NamMinh') ? 'Nam Minh (Nam)' : 'Hoài My (Nữ)'
        }`,
        coverImage: novel.coverImage,
        onPlay: () => toggleTtsPlay(),
        onPause: () => pauseTts(),
        onNext: () => skipNextTts(),
        onPrev: () => skipPrevTts(),
      });
    } else if (!isTtsPlaying) {
      backgroundAudioManager.pauseBackgroundPlayback();
    }
  }, [isTtsPlaying, currentChunkIndex, activeVoiceId, novel, chapter]);

  const handleChangeVoice = (newVoiceId: string) => {
    setReaderSettings((prev) => ({ ...prev, selectedVoiceId: newVoiceId }));
    setVoiceId(newVoiceId);
  };

  // Anti-Theft & Protection Listeners
  useEffect(() => {
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      setDrmWarning('Chuột phải đã bị vô hiệu hóa.');
      setTimeout(() => setDrmWarning(null), 2500);
    };

    const handleCopy = (e: ClipboardEvent) => {
      e.preventDefault();
      if (e.clipboardData) {
        e.clipboardData.setData(
          'text/plain',
          `[NỘI DUNG ĐẠO TÂM]\nTác phẩm: "${novel.title}" - ${chapter.title}\nTác giả: ${novel.author}\nNền tảng phát hành: Đạo Tâm (daotam.vn)\nCảnh báo: Nội dung được bảo vệ chống cào tự động.`
        );
      }
      setDrmWarning('Cảnh báo: Nội dung được bảo vệ chống sao chép!');
      setTimeout(() => setDrmWarning(null), 3000);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        (e.ctrlKey || e.metaKey) &&
        (e.key === 'c' || e.key === 'C' || e.key === 'u' || e.key === 'U' || e.key === 's' || e.key === 'S' || e.key === 'p' || e.key === 'P')
      ) {
        e.preventDefault();
        setDrmWarning('Phím tắt bị khóa để bảo vệ tác phẩm!');
        setTimeout(() => setDrmWarning(null), 2500);
      }
      if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J'))) {
        e.preventDefault();
        setDrmWarning('Công cụ kiểm tra phần tử (DevTools) bị vô hiệu hóa.');
        setTimeout(() => setDrmWarning(null), 2500);
      }
    };

    const handleBlur = () => setIsWindowBlurred(true);
    const handleFocus = () => setIsWindowBlurred(false);

    window.addEventListener('contextmenu', handleContextMenu);
    window.addEventListener('copy', handleCopy);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('blur', handleBlur);
    window.addEventListener('focus', handleFocus);

    return () => {
      window.removeEventListener('contextmenu', handleContextMenu);
      window.removeEventListener('copy', handleCopy);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('blur', handleBlur);
      window.removeEventListener('focus', handleFocus);
      stopTts();
      backgroundAudioManager.pauseBackgroundPlayback();
    };
  }, []);

  // Restore scroll position
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    const existing = user.readingHistory.find(
      (h) => h.novelId === novel.id && h.chapterNumber === chapter.number
    );
    if (existing && existing.scrollPercentage > 5) {
      setTimeout(() => {
        const docHeight = document.documentElement.scrollHeight - window.innerHeight;
        const targetScroll = (existing.scrollPercentage / 100) * docHeight;
        window.scrollTo({ top: targetScroll, behavior: 'smooth' });
      }, 400);
    }
  }, [chapter.id]);

  // Track scroll percentage and auto-save
  useEffect(() => {
    let timeoutId: any = null;

    const handleScroll = () => {
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (docHeight <= 0) return;
      const scrolled = window.scrollY;
      const pct = Math.min(100, Math.max(0, Math.round((scrolled / docHeight) * 100)));
      setScrollProgress(pct);

      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        onSaveProgress({
          novelId: novel.id,
          novelTitle: novel.title,
          novelCover: novel.coverImage,
          chapterNumber: chapter.number,
          chapterTitle: chapter.title,
          chapterId: chapter.id,
          scrollPercentage: pct,
          lastSentenceIndex: currentChunkIndex,
          lastReadAt: Date.now(),
        });
      }, 1500);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      clearTimeout(timeoutId);
    };
  }, [novel, chapter, currentChunkIndex, onSaveProgress]);

  const handleManualSave = () => {
    onSaveProgress({
      novelId: novel.id,
      novelTitle: novel.title,
      novelCover: novel.coverImage,
      chapterNumber: chapter.number,
      chapterTitle: chapter.title,
      chapterId: chapter.id,
      scrollPercentage: scrollProgress,
      lastSentenceIndex: currentChunkIndex,
      lastReadAt: Date.now(),
    });
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 2000);
  };

  const isLightMode =
    readerSettings.theme === 'light' ||
    readerSettings.theme === 'sepia' ||
    (typeof document !== 'undefined' && document.documentElement.classList.contains('light'));

  const getThemeClasses = () => {
    if (isLightMode) {
      if (readerSettings.theme === 'sepia') {
        return 'reader-theme-sepia bg-[#f8f5eb] text-[#2c2214]';
      }
      return 'bg-slate-50 text-slate-800';
    }
    switch (readerSettings.theme) {
      case 'dark':
        return 'bg-slate-900 text-slate-200';
      case 'midnight':
        return 'bg-[#090d16] text-slate-200';
      case 'sepia':
        return 'reader-theme-sepia bg-[#f8f5eb] text-[#2c2214]';
      case 'light':
      default:
        return 'bg-slate-50 text-slate-800';
    }
  };

  return (
    <div className={`reader-container min-h-screen relative transition-colors duration-300 select-none ${getThemeClasses()}`}>
      {/* Scroll Progress Bar (Oceanic Blue) */}
      <div 
        className="fixed top-0 left-0 h-1 bg-gradient-to-r from-blue-600 via-sky-400 to-cyan-400 z-50 transition-all duration-150"
        style={{ width: `${scrollProgress}%` }}
      />

      {/* Floating Reader Top Bar (Borderless, modern shadow) */}
      <div className="sticky top-0 z-40 backdrop-blur-md bg-white/90 dark:bg-slate-900/90 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.06)] dark:shadow-md dark:shadow-black/40 px-4 py-2.5">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
          <button
            onClick={onBackToNovel}
            className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-white py-1.5 px-3 rounded-lg bg-slate-100 dark:bg-slate-800 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Mục lục</span>
          </button>

          {/* Chapter selector */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              onClick={() => prevChapter && onSelectChapter(novel, prevChapter)}
              disabled={!prevChapter}
              className={`p-1.5 rounded-lg text-xs transition-colors ${
                prevChapter
                  ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-blue-600 hover:text-white cursor-pointer'
                  : 'bg-slate-100/50 dark:bg-slate-800/40 text-slate-400 dark:text-slate-600 cursor-not-allowed'
              }`}
              title="Chương trước"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <button
              onClick={() => setShowChapterDrawer(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs text-blue-600 dark:text-cyan-400 font-semibold cursor-pointer max-w-[190px] sm:max-w-xs truncate"
              title="Mục lục chương nhanh"
            >
              <List className="w-3.5 h-3.5 text-blue-600 dark:text-cyan-400 flex-shrink-0" />
              <span className="truncate">Chương {chapter.number}</span>
              {chapter.isVip && !isChapterUnlocked && (
                <Lock className="w-3 h-3 text-rose-500 flex-shrink-0 ml-1" />
              )}
            </button>

            <button
              onClick={() => nextChapter && onSelectChapter(novel, nextChapter)}
              disabled={!nextChapter}
              className={`p-1.5 rounded-lg text-xs transition-colors ${
                nextChapter
                  ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-blue-600 hover:text-white cursor-pointer'
                  : 'bg-slate-100/50 dark:bg-slate-800/40 text-slate-400 dark:text-slate-600 cursor-not-allowed'
              }`}
              title="Chương sau"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            {/* Voice Switcher (Hoài My - Nữ & Nam Minh - Nam) */}
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl shadow-xs">
              <button
                type="button"
                onClick={() => handleChangeVoice('vi-VN-HoaiMyNeural')}
                className={`px-2.5 sm:px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer ${
                  normalizeEdgeVoiceId(readerSettings.selectedVoiceId) === 'vi-VN-HoaiMyNeural'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Giọng Nữ: Hoài My (Microsoft Edge Neural)"
              >
                <span>👩</span>
                <span className="hidden sm:inline">Hoài My</span>
              </button>
              <button
                type="button"
                onClick={() => handleChangeVoice('vi-VN-NamMinhNeural')}
                className={`px-2.5 sm:px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer ${
                  normalizeEdgeVoiceId(readerSettings.selectedVoiceId) === 'vi-VN-NamMinhNeural'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Giọng Nam: Nam Minh (Microsoft Edge Neural)"
              >
                <span>👨</span>
                <span className="hidden sm:inline">Nam Minh</span>
              </button>
            </div>

            {/* Play/Pause Button (Edge TTS Zero Latency) */}
            <button
              onClick={() => {
                if (!isChapterUnlocked) {
                  onOpenVipPurchase(novel, chapter);
                  return;
                }
                toggleTtsPlay();
              }}
              className={`p-2 sm:px-3 sm:py-2 rounded-xl text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-sm ${
                isTtsPlaying
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-bold'
                  : 'bg-blue-600 hover:bg-blue-500 text-white font-semibold'
              }`}
              title={isTtsPlaying ? 'Tạm dừng nghe' : 'Bắt đầu nghe Edge TTS'}
            >
              {isTtsLoading ? (
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : isTtsPlaying ? (
                <Pause className="w-3.5 h-3.5 fill-current" />
              ) : (
                <Play className="w-3.5 h-3.5 fill-current" />
              )}
              <span className="hidden md:inline font-medium">
                {isTtsLoading ? 'Đang đệm...' : isTtsPlaying ? 'Đang đọc' : 'Phát Audio'}
              </span>
            </button>

            {/* Settings */}
            <button
              onClick={() => setShowSettings(!showSettings)}
              className={`p-2 rounded-lg text-xs transition-colors cursor-pointer ${
                showSettings
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-600'
              }`}
              title="Cài đặt đọc"
            >
              <Sliders className="w-3.5 h-3.5" />
            </button>

            {/* Manual Save */}
            <button
              onClick={handleManualSave}
              className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-600 text-xs transition-colors cursor-pointer"
              title="Lưu tiến trình đọc"
            >
              <Bookmark className="w-3.5 h-3.5" />
            </button>

            {/* Report */}
            {onOpenReport && (
              <button
                onClick={() => onOpenReport(novel)}
                className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs transition-colors cursor-pointer"
                title="Báo cáo vi phạm"
              >
                <Flag className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Reader Settings Panel (Borderless & Flat) */}
        {showSettings && (
          <div className="max-w-4xl mx-auto mt-2.5 p-4 bg-white dark:bg-slate-800 rounded-2xl shadow-[0_4px_25px_-4px_rgba(0,0,0,0.08)] dark:shadow-2xl grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs text-slate-700 dark:text-slate-300">
            {/* Speed Selector */}
            <div>
              <label className="block text-slate-500 dark:text-slate-400 mb-1.5 font-medium">Tốc độ đọc Audio:</label>
              <div className="grid grid-cols-4 gap-1.5">
                {[0.8, 1.0, 1.25, 1.5].map((speed) => (
                  <button
                    key={speed}
                    onClick={() => {
                      setReaderSettings({ ...readerSettings, voiceSpeed: speed });
                      setPlaybackRate(speed);
                    }}
                    className={`py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                      playbackRate === speed
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {speed}x
                  </button>
                ))}
              </div>
            </div>

            {/* Font size */}
            <div>
              <div className="flex justify-between items-center mb-1.5 text-slate-500 dark:text-slate-400">
                <span>Cỡ chữ:</span>
                <span className="text-blue-600 dark:text-cyan-400 font-semibold">{readerSettings.fontSize}px</span>
              </div>
              <input
                type="range"
                min="15"
                max="26"
                step="1"
                value={readerSettings.fontSize}
                onChange={(e) =>
                  setReaderSettings({ ...readerSettings, fontSize: Number(e.target.value) })
                }
                className="w-full accent-blue-600 cursor-pointer"
              />
            </div>

            {/* Background Theme */}
            <div>
              <label className="block text-slate-500 dark:text-slate-400 mb-1.5 font-medium">Màu nền:</label>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { id: 'light', label: 'Sáng', bg: 'bg-slate-100 text-slate-800' },
                  { id: 'sepia', label: 'Ấm', bg: 'bg-[#f8f5eb] text-[#2c2214]' },
                  { id: 'dark', label: 'Tối', bg: 'bg-slate-900 text-white' },
                ].map((th) => (
                  <button
                    key={th.id}
                    onClick={() => setReaderSettings({ ...readerSettings, theme: th.id as any })}
                    className={`py-1.5 rounded-lg font-medium text-center transition-all cursor-pointer text-xs ${th.bg} ${
                      readerSettings.theme === th.id ? 'ring-2 ring-blue-600 font-bold' : ''
                    }`}
                  >
                    {th.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Auto Next Chapter Setting */}
            <div className="sm:col-span-3 pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
              <div>
                <span className="font-semibold text-slate-900 dark:text-slate-100 block">Tự động chuyển chương (Audio)</span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">Tự động tải và phát chương kế tiếp khi nghe hết chương hiện tại</span>
              </div>
              <button
                type="button"
                onClick={() =>
                  setReaderSettings((prev) => ({ ...prev, autoNextChapter: !prev.autoNextChapter }))
                }
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                  readerSettings.autoNextChapter
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                }`}
              >
                <FastForward className="w-3.5 h-3.5" />
                <span>{readerSettings.autoNextChapter ? 'Đang BẬT' : 'Đang TẮT'}</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Floating Karaoke TTS Audio Control Bar */}
      {isTtsPlaying && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl p-3 shadow-[0_10px_35px_-5px_rgba(0,0,0,0.12)] dark:shadow-2xl flex flex-wrap items-center justify-center gap-3 animate-in slide-in-from-bottom duration-200">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${isTtsLoading ? 'bg-amber-400' : 'bg-cyan-400'} opacity-75`}></span>
              <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${isTtsLoading ? 'bg-amber-500' : 'bg-blue-600'}`}></span>
            </span>
            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
              {isTtsLoading ? 'Đang nạp âm thanh...' : `Câu ${currentChunkIndex + 1}/${chunks.length} (${ttsProgress}%)`}
            </span>
          </div>

          {/* Skip buttons */}
          <div className="flex items-center gap-1">
            <button
              onClick={skipPrevTts}
              className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-600 cursor-pointer"
              title="Câu trước"
            >
              <SkipBack className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={toggleTtsPlay}
              className="p-1.5 rounded-lg bg-blue-600 text-white hover:bg-blue-500 cursor-pointer"
              title="Tạm dừng"
            >
              <Pause className="w-3.5 h-3.5 fill-current" />
            </button>
            <button
              onClick={skipNextTts}
              className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-600 cursor-pointer"
              title="Câu tiếp theo"
            >
              <SkipForward className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Auto Next Chapter Toggle */}
          <button
            onClick={() => setReaderSettings((prev) => ({ ...prev, autoNextChapter: !prev.autoNextChapter }))}
            className={`px-2.5 py-1 rounded-xl text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer ${
              readerSettings.autoNextChapter
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
            title="Tự động chuyển sang chương tiếp theo khi kết thúc audio"
          >
            <FastForward className="w-3.5 h-3.5" />
            <span className="text-[11px] font-medium hidden sm:inline">{readerSettings.autoNextChapter ? 'Tự chuyển: BẬT' : 'Tự chuyển: TẮT'}</span>
          </button>

          {/* Buffer Indicator Badge */}
          <span className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded-full font-medium">
            Đệm sẵn: {bufferedIndices.length} câu
          </span>

          {/* Close audio player */}
          <button
            onClick={stopTts}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white cursor-pointer"
            title="Dừng nghe audio"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Chapter Content Body (Sans-serif flat layout) */}
      <article className={`max-w-3xl mx-auto px-5 sm:px-8 py-10 relative select-none ${isWindowBlurred ? 'filter blur-sm transition-all' : ''}`}>
        <div className="text-center mb-3">
          <span className="text-xs uppercase tracking-wider text-blue-600 dark:text-blue-400 font-semibold">
            {novel.title}
          </span>
        </div>

        <h1 className="text-xl sm:text-2xl font-bold text-center text-slate-900 dark:text-slate-100 leading-snug mb-3">
          {chapter.title}
        </h1>

        <div className="flex items-center justify-center gap-3 text-xs text-slate-500 dark:text-slate-400 mb-8 pb-4 border-b border-slate-200 dark:border-slate-800/80 flex-wrap">
          <span>{chapter.wordCount || 3200} từ</span>
          <span>•</span>
          <span>Cập nhật: {chapter.publishedDate || 'Hôm nay'}</span>
          <span>•</span>
          <span className="text-blue-600 dark:text-blue-400">Tiến trình: {scrollProgress}%</span>
          {chapter.isVip && (
            <span className="bg-blue-50 dark:bg-slate-800 text-blue-600 dark:text-cyan-400 font-semibold px-2 py-0.5 rounded-full text-[10px]">
              VIP • {Number((typeof chapter.priceXu === 'number' ? chapter.priceXu : 5).toFixed(2))} Xu
            </span>
          )}
        </div>

        {/* Text Body with Karaoke Mode Highlighting */}
        <div
          style={{
            fontSize: `${readerSettings.fontSize}px`,
            lineHeight: readerSettings.lineHeight || 1.8,
          }}
          className="text-justify leading-relaxed space-y-4 select-none relative z-10"
        >
          {isChapterUnlocked ? (
            chunks.map((chunk, idx) => {
              const isCurrentSentence = currentChunkIndex === idx;
              return (
                <span
                  key={idx}
                  ref={(el) => {
                    sentenceRefs.current[idx] = el;
                  }}
                  onClick={() => seekToChunk(idx)}
                  className={`chapter-sentence inline rounded-md px-1 py-0.5 transition-all duration-150 cursor-pointer ${
                    isCurrentSentence
                      ? 'tts-karaoke-active font-semibold shadow-xs'
                      : 'tts-karaoke-chunk hover:text-blue-600 dark:hover:text-cyan-300'
                  }`}
                  title="Bấm để nghe từ câu này"
                >
                  {chunk.text}{' '}
                </span>
              );
            })
          ) : (
            <div className="relative">
              <div className="space-y-4 text-slate-500 dark:text-slate-400">
                {chunks.slice(0, 4).map((chunk, idx) => (
                  <p key={idx} className="indent-6">
                    {chunk.text}
                  </p>
                ))}
              </div>

              <div className="relative mt-4 filter blur-md select-none opacity-40 pointer-events-none space-y-4">
                {chunks.slice(4, 10).map((chunk, idx) => (
                  <p key={idx} className="indent-6">
                    {chunk.text}
                  </p>
                ))}
              </div>

              {/* VIP Frosted Lock Overlay (Borderless, modern shadow) */}
              <div className="absolute inset-x-0 bottom-0 top-20 backdrop-blur-md bg-white/95 dark:bg-slate-900/95 rounded-2xl p-6 sm:p-8 flex flex-col items-center justify-center text-center shadow-xl">
                <div className="w-12 h-12 rounded-xl bg-blue-50 dark:bg-slate-800 text-blue-600 dark:text-cyan-400 flex items-center justify-center mb-3">
                  <Lock className="w-6 h-6" />
                </div>

                <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-slate-100 mb-2">
                  Chương Này Thuộc Nội Dung VIP
                </h3>

                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-md mb-6 leading-relaxed">
                  Mở khóa để đọc toàn văn và nghe giọng đọc Audio Edge TTS tự động không gián đoạn.
                </p>

                <div className="flex flex-col sm:flex-row items-center gap-3 w-full max-w-sm">
                  <button
                    onClick={() => onOpenVipPurchase(novel, chapter)}
                    className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Coins className="w-4 h-4 text-cyan-200" />
                    Mở Khóa ({Number((typeof chapter.priceXu === 'number' ? chapter.priceXu : 5).toFixed(2))} Xu)
                  </button>

                  <button
                    onClick={() => onOpenVipPurchase(novel, chapter)}
                    className="w-full py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-blue-600 dark:text-cyan-300 font-semibold text-xs sm:text-sm transition-all cursor-pointer"
                  >
                    Mua Trọn Bộ
                  </button>
                </div>

                <div className="mt-4 text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
                  <span>Ví: <strong className="text-blue-600 dark:text-cyan-400 font-bold">{Number(user.xuBalance.toFixed(2))} Xu</strong></span>
                  <span>•</span>
                  <button
                    onClick={onOpenTopUp}
                    className="text-blue-600 dark:text-cyan-400 hover:underline font-semibold cursor-pointer"
                  >
                    Nạp Xu Ngay &rarr;
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Navigation */}
        <div className="mt-12 pt-8 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-start">
            {prevChapter ? (
              <button
                onClick={() => onSelectChapter(novel, prevChapter)}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-blue-600 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                Chương trước
              </button>
            ) : (
              <div />
            )}

            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-all cursor-pointer shadow-sm"
            >
              Lên đầu trang
            </button>

            {nextChapter ? (
              <button
                onClick={() => onSelectChapter(novel, nextChapter)}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-blue-600 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
              >
                Chương sau
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <div />
            )}
          </div>
        </div>

        {/* Comments Section */}
        <CommentsSection novelId={novel.id} chapterNumber={chapter.number} user={user} />
      </article>

      {/* Quick Chapter Drawer */}
      {showChapterDrawer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 h-full p-6 flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                <List className="w-4 h-4 text-blue-600" />
                Mục lục chương
              </h3>
              <button
                onClick={() => setShowChapterDrawer(false)}
                className="text-slate-400 hover:text-slate-700 dark:hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-4 space-y-1.5 pr-1">
              {novel.chapters.map((c) => {
                const unlocked =
                  !c.isVip ||
                  isFullBookUnlocked ||
                  (user.unlockedChapters[novel.id] && user.unlockedChapters[novel.id].includes(c.id));
                return (
                  <button
                    key={c.id}
                    onClick={() => {
                      onSelectChapter(novel, c);
                      setShowChapterDrawer(false);
                    }}
                    className={`w-full text-left p-2.5 rounded-xl text-xs transition-colors flex items-center justify-between cursor-pointer ${
                      c.id === chapter.id
                        ? 'bg-blue-600 text-white font-semibold'
                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <span className="truncate pr-2">{c.title}</span>
                    {c.isVip && !unlocked && (
                      <Lock className="w-3 h-3 text-rose-500 flex-shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
