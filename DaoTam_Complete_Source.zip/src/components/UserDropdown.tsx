import React, { useRef, useEffect } from 'react';
import { 
  User, 
  Heart, 
  UserCheck, 
  BookOpen, 
  PenTool, 
  History, 
  Bookmark, 
  BarChart2, 
  Info, 
  Key, 
  LogOut,
  Coins,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';
import { UserProfile } from '../types';

interface UserDropdownProps {
  user: UserProfile;
  isOpen: boolean;
  onToggle: () => void;
  onClose: () => void;
  onOpenProfile: () => void;
  onOpenInterestedNovels: () => void;
  onOpenFollowingCreators: () => void;
  onOpenMyNovels: () => void;
  onOpenSubmitNovel: () => void;
  onOpenReadingHistory: () => void;
  onOpenBookmarks: () => void;
  onOpenStats: () => void;
  onOpenInfo: () => void;
  onOpenChangePassword: () => void;
  onLogout: () => void;
  onLogin: () => void;
}

export const UserDropdown: React.FC<UserDropdownProps> = ({
  user,
  isOpen,
  onToggle,
  onClose,
  onOpenProfile,
  onOpenInterestedNovels,
  onOpenFollowingCreators,
  onOpenMyNovels,
  onOpenSubmitNovel,
  onOpenReadingHistory,
  onOpenBookmarks,
  onOpenStats,
  onOpenInfo,
  onOpenChangePassword,
  onLogout,
  onLogin,
}) => {
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose]);

  const isAdmin = user.role === 'admin';
  const isAuthor = user.role === 'author';

  // If not logged in, clicking avatar prompts login
  if (!user.isLoggedIn || user.id === 'guest') {
    return (
      <button
        onClick={onLogin}
        className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md transition-all cursor-pointer"
        title="Đăng nhập tài khoản"
      >
        <User className="w-3.5 h-3.5" />
        <span>Đăng Nhập</span>
      </button>
    );
  }

  const menuItems = [
    {
      id: 'profile',
      label: 'Trang cá nhân',
      icon: <User className="w-4 h-4 text-blue-600 dark:text-cyan-400" />,
      onClick: () => { onClose(); onOpenProfile(); },
    },
    {
      id: 'interested',
      label: 'Truyện được quan tâm',
      icon: <Heart className="w-4 h-4 text-rose-500" />,
      onClick: () => { onClose(); onOpenInterestedNovels(); },
    },
    {
      id: 'following',
      label: 'Đang theo dõi',
      icon: <UserCheck className="w-4 h-4 text-emerald-500" />,
      badge: user.followingCreators?.length || 0,
      onClick: () => { onClose(); onOpenFollowingCreators(); },
    },
    {
      id: 'my-novels',
      label: 'Truyện của bạn',
      icon: <BookOpen className="w-4 h-4 text-amber-500" />,
      onClick: () => { onClose(); onOpenMyNovels(); },
    },
    {
      id: 'submit',
      label: 'Đăng truyện',
      icon: <PenTool className="w-4 h-4 text-indigo-500" />,
      onClick: () => { onClose(); onOpenSubmitNovel(); },
    },
    {
      id: 'history',
      label: 'Truyện đã đọc',
      icon: <History className="w-4 h-4 text-blue-500" />,
      badge: user.readingHistory?.length || 0,
      onClick: () => { onClose(); onOpenReadingHistory(); },
    },
    {
      id: 'bookmarks',
      label: 'Truyện đã lưu',
      icon: <Bookmark className="w-4 h-4 text-purple-500" />,
      badge: user.bookmarks?.length || 0,
      onClick: () => { onClose(); onOpenBookmarks(); },
    },
    {
      id: 'stats',
      label: 'Thống kê',
      icon: <BarChart2 className="w-4 h-4 text-teal-500" />,
      onClick: () => { onClose(); onOpenStats(); },
    },
    {
      id: 'info',
      label: 'Thông tin',
      icon: <Info className="w-4 h-4 text-sky-500" />,
      onClick: () => { onClose(); onOpenInfo(); },
    },
    {
      id: 'change-password',
      label: 'Đổi mật khẩu',
      icon: <Key className="w-4 h-4 text-orange-500" />,
      onClick: () => { onClose(); onOpenChangePassword(); },
    },
    {
      id: 'logout',
      label: 'Đăng xuất',
      icon: <LogOut className="w-4 h-4 text-red-500" />,
      isDanger: true,
      onClick: () => { onClose(); onLogout(); },
    },
  ];

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Avatar Button Trigger */}
      <button
        onClick={onToggle}
        className="flex items-center gap-2 p-1 rounded-full bg-slate-100 dark:bg-slate-800 hover:ring-2 hover:ring-blue-600 transition-all cursor-pointer shadow-xs focus:outline-none"
        title="Menu người dùng"
        aria-expanded={isOpen}
      >
        <div className="relative">
          <img
            src={user.avatarUrl}
            alt={user.displayName}
            className="w-8 h-8 rounded-full object-cover shadow-sm"
          />
          {isAdmin ? (
            <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-amber-500 rounded-full flex items-center justify-center text-[8px] text-black font-extrabold shadow-xs" title="Quản Trị Viên">
              ★
            </span>
          ) : isAuthor ? (
            <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-blue-600 rounded-full flex items-center justify-center text-[8px] text-white font-extrabold shadow-xs" title="Tác Giả">
              ✍
            </span>
          ) : null}
        </div>
        <span className="hidden md:inline font-semibold text-xs text-slate-800 dark:text-slate-200 max-w-[90px] truncate pr-1">
          {user.displayName}
        </span>
      </button>

      {/* Dropdown Menu Modal */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-72 sm:w-80 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-100 dark:border-slate-800 z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
          {/* Header Profile Summary */}
          <div className="p-4 bg-gradient-to-br from-blue-600/10 via-slate-50 to-white dark:from-blue-950/40 dark:via-slate-900 dark:to-slate-900 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-3">
              <img
                src={user.avatarUrl}
                alt={user.displayName}
                className="w-12 h-12 rounded-full object-cover shadow-md ring-2 ring-blue-500/30"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white truncate">
                    {user.displayName}
                  </h4>
                  {isAdmin ? (
                    <span className="px-1.5 py-0.5 rounded text-[9.5px] font-bold bg-amber-500/20 text-amber-600 dark:text-amber-400">
                      ADMIN
                    </span>
                  ) : isAuthor ? (
                    <span className="px-1.5 py-0.5 rounded text-[9.5px] font-bold bg-blue-500/20 text-blue-600 dark:text-cyan-400">
                      TÁC GIẢ
                    </span>
                  ) : (
                    <span className="px-1.5 py-0.5 rounded text-[9.5px] font-semibold bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                      ĐỘC GIẢ
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                  {user.email}
                </p>
                {user.bio && (
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 italic line-clamp-1 mt-1">
                    "{user.bio}"
                  </p>
                )}
              </div>
            </div>

            {/* Quick Balances */}
            <div className="mt-3 pt-3 border-t border-slate-200/60 dark:border-slate-800 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1 text-blue-600 dark:text-cyan-400 font-bold">
                <Coins className="w-3.5 h-3.5" />
                <span>{Number(user.xuBalance.toFixed(2))} Xu</span>
              </div>
              <div className="flex items-center gap-1 text-slate-700 dark:text-slate-300 font-semibold">
                <span>🌸 {isAdmin ? 'Vô hạn' : (user.flowerBalance || 0)} Hoa</span>
              </div>
            </div>
          </div>

          {/* 11 Exact Menu Items */}
          <div className="py-2 max-h-[65vh] overflow-y-auto scrollbar-thin">
            {menuItems.map((item, index) => {
              const isDanger = item.isDanger;
              return (
                <button
                  key={item.id}
                  onClick={item.onClick}
                  className={`w-full px-4 py-2 text-left flex items-center justify-between transition-colors cursor-pointer text-xs font-medium ${
                    isDanger 
                      ? 'text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30' 
                      : 'text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                  } ${index === 9 ? 'border-b border-slate-100 dark:border-slate-800 pb-2.5 mb-1' : ''}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center flex-shrink-0">
                      {item.icon}
                    </div>
                    <span>{item.label}</span>
                  </div>

                  <div className="flex items-center gap-1.5 text-slate-400">
                    {typeof item.badge === 'number' && item.badge > 0 && (
                      <span className="px-1.5 py-0.2 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-cyan-300 text-[10px] font-bold">
                        {item.badge}
                      </span>
                    )}
                    <ChevronRight className="w-3 h-3 text-slate-400" />
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
