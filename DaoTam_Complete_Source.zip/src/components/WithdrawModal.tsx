import React, { useState } from 'react';
import { UserProfile } from '../types';
import { 
  X, 
  Coins, 
  CreditCard, 
  AlertCircle, 
  CheckCircle2, 
  Building2, 
  User, 
  ArrowRight,
  ShieldCheck,
  Clock,
  Sparkles
} from 'lucide-react';
import { DaoTamLogo } from './DaoTamLogo';

interface WithdrawModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onSubmitWithdrawal: (data: {
    amountXu: number;
    amountVnd: number;
    bankName: string;
    accountNumber: string;
    accountHolder: string;
    note?: string;
  }) => void;
}

const COMMON_BANKS = [
  'MB Bank (Ngân hàng Quân Đội)',
  'Vietcombank',
  'Techcombank',
  'BIDV',
  'VietinBank',
  'ACB',
  'TPBank',
  'VPBank',
  'Sacombank',
  'HDBank',
  'Khác',
];

export const WithdrawModal: React.FC<WithdrawModalProps> = ({
  isOpen,
  onClose,
  user,
  onSubmitWithdrawal,
}) => {
  const currentEarnedXu = user.authorEarnedXu || 0;
  const isEligible = currentEarnedXu >= 100;

  const [amountXu, setAmountXu] = useState<number>(() => Math.max(100, Math.min(currentEarnedXu, 100)));
  const [bankName, setBankName] = useState<string>(user.bankInfo?.bankName || '');
  const [accountNumber, setAccountNumber] = useState<string>(user.bankInfo?.accountNumber || '');
  const [accountHolder, setAccountHolder] = useState<string>(user.bankInfo?.accountHolder || '');
  const [note, setNote] = useState<string>('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const amountVnd = amountXu * 1000;
  const remainingXu = Math.max(0, currentEarnedXu - amountXu);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!isEligible) {
      setErrorMessage('Số dư nhuận bút cần đạt tối thiểu 100 Xu để tạo lệnh rút tiền.');
      return;
    }

    if (amountXu < 100) {
      setErrorMessage('Số xu rút tối thiểu là 100 Xu.');
      return;
    }

    if (amountXu > currentEarnedXu) {
      setErrorMessage(`Bạn chỉ có tối đa ${currentEarnedXu} Xu để rút.`);
      return;
    }

    if (!accountNumber.trim()) {
      setErrorMessage('Vui lòng nhập số tài khoản ngân hàng (STK).');
      return;
    }

    if (!accountHolder.trim()) {
      setErrorMessage('Vui lòng nhập tên chủ tài khoản ngân hàng.');
      return;
    }

    onSubmitWithdrawal({
      amountXu,
      amountVnd,
      bankName,
      accountNumber: accountNumber.trim(),
      accountHolder: accountHolder.trim().toUpperCase(),
      note: note.trim(),
    });

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 text-[#231c26] dark:text-slate-100 animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-[#faf6f0] dark:bg-[#12101e] border border-[#ebdcd5] dark:border-pink-500/25 rounded-3xl shadow-2xl flex flex-col overflow-hidden relative transition-colors">
        
        {/* Header */}
        <div className="px-6 py-4 bg-white dark:bg-[#181528] border-b border-[#ebdcd5] dark:border-pink-500/20 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/20">
              <Coins className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-serif text-lg sm:text-xl font-bold text-[#231c26] dark:text-white">
                Rút Xu Nhuận Bút Tác Giả &amp; Editor
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Quy đổi tỷ lệ 1:1 tương ứng 1 Xu = 1,000 VNĐ
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5">
          
          {/* Balance Status Banner */}
          <div className="bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-sky-500/10 border border-emerald-500/30 rounded-2xl p-4 flex items-center justify-between gap-4">
            <div>
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Số xu nhuận bút hiện có:
              </span>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-2xl sm:text-3xl font-extrabold text-emerald-600 dark:text-emerald-400">
                  {currentEarnedXu.toLocaleString()} Xu
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  (~ {(currentEarnedXu * 1000).toLocaleString()} đ)
                </span>
              </div>
            </div>

            <div className="text-right">
              <span className="inline-block text-[11px] font-bold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-700/50">
                {isEligible ? '✅ Đủ điều kiện rút' : '⚠️ Cần tối thiểu 100 Xu'}
              </span>
            </div>
          </div>

          {/* Success Screen */}
          {isSuccess ? (
            <div className="py-8 text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-300 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h4 className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
                Gửi Yêu Cầu Rút Xu Thành Công!
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 max-w-sm mx-auto">
                Yêu cầu rút {amountXu} Xu ({amountVnd.toLocaleString()} đ) đã được gửi tới Quản Trị Viên. Sau khi BQT đối soát và chuyển khoản tới STK của bạn, hệ thống sẽ gửi thông báo xác nhận.
              </p>
            </div>
          ) : !isEligible ? (
            /* Ineligible warning */
            <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-600/40 rounded-2xl p-5 text-center space-y-3">
              <AlertCircle className="w-10 h-10 text-amber-500 mx-auto" />
              <h4 className="text-base font-bold text-amber-800 dark:text-amber-300">
                Chưa Đạt Hạn Mức Tối Thiểu 100 Xu
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-w-md mx-auto">
                Theo quy định sàn Đạo Tâm, tác giả và editor cần tích lũy tối thiểu <strong>100 Xu</strong> từ độc giả mua chương truyện VIP trước khi có thể yêu cầu rút tiền về tài khoản ngân hàng.
              </p>
              <div className="pt-2 text-xs font-semibold text-slate-500">
                Hiện bạn có: <span className="text-amber-600 font-bold">{currentEarnedXu} Xu</span> (còn thiếu {100 - currentEarnedXu} Xu nữa).
              </div>
              <button
                type="button"
                onClick={onClose}
                className="mt-2 px-5 py-2 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white cursor-pointer shadow"
              >
                Tiếp Tục Sáng Tác &amp; Đăng Truyện
              </button>
            </div>
          ) : (
            /* Eligible Form */
            <form onSubmit={handleSubmit} className="space-y-4">
              
              {errorMessage && (
                <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-300 dark:border-rose-700 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Amount to Withdraw */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Số Xu Yêu Cầu Rút (Tối thiểu 100 Xu):
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="100"
                    max={currentEarnedXu}
                    step="1"
                    value={amountXu}
                    onChange={(e) => setAmountXu(Number(e.target.value))}
                    className="w-full pl-3 pr-16 py-2.5 rounded-xl bg-white dark:bg-[#1a172a] border border-[#ebdcd5] dark:border-slate-700 font-bold text-lg text-emerald-600 dark:text-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                  <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                    Xu
                  </span>
                </div>

                {/* Quick Select Buttons */}
                <div className="flex items-center gap-2 mt-2">
                  <button
                    type="button"
                    onClick={() => setAmountXu(100)}
                    className="px-2.5 py-1 text-[11px] font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 cursor-pointer"
                  >
                    100 Xu (100k)
                  </button>
                  {currentEarnedXu >= 200 && (
                    <button
                      type="button"
                      onClick={() => setAmountXu(200)}
                      className="px-2.5 py-1 text-[11px] font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 cursor-pointer"
                    >
                      200 Xu (200k)
                    </button>
                  )}
                  {currentEarnedXu >= 500 && (
                    <button
                      type="button"
                      onClick={() => setAmountXu(500)}
                      className="px-2.5 py-1 text-[11px] font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 cursor-pointer"
                    >
                      500 Xu (500k)
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setAmountXu(currentEarnedXu)}
                    className="px-2.5 py-1 text-[11px] font-bold rounded-lg bg-emerald-100 hover:bg-emerald-200 dark:bg-emerald-950/60 dark:hover:bg-emerald-900/80 text-emerald-800 dark:text-emerald-300 cursor-pointer"
                  >
                    Tất cả ({currentEarnedXu} Xu)
                  </button>
                </div>
              </div>

              {/* Conversion Preview Box */}
              <div className="bg-slate-50 dark:bg-[#1a172a] rounded-xl p-3 border border-slate-200 dark:border-slate-800 space-y-1.5 text-xs">
                <div className="flex justify-between items-center text-slate-600 dark:text-slate-400">
                  <span>Số tiền thực nhận (1 Xu = 1,000đ):</span>
                  <span className="font-extrabold text-base text-pink-600 dark:text-pink-400">
                    {amountVnd.toLocaleString()} VNĐ
                  </span>
                </div>
                <div className="flex justify-between items-center text-slate-500 dark:text-slate-400 text-[11px]">
                  <span>Số xu còn lại sau khi rút:</span>
                  <span className="font-semibold text-slate-700 dark:text-slate-200">
                    {remainingXu.toLocaleString()} Xu
                  </span>
                </div>
              </div>

              {/* Bank Information for Payout */}
              <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-800">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
                  <Building2 className="w-4 h-4 text-sky-500" />
                  Thông Tin Tài Khoản Ngân Hàng Nhận Tiền
                </h4>

                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    Ngân hàng:
                  </label>
                  <select
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#1a172a] border border-[#ebdcd5] dark:border-slate-700 text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500 cursor-pointer"
                  >
                    <option value="">-- Chọn ngân hàng thụ hưởng --</option>
                    {COMMON_BANKS.map((b) => (
                      <option key={b} value={b}>{b}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Số tài khoản (STK):
                    </label>
                    <input
                      type="text"
                      placeholder="Nhập số tài khoản ngân hàng..."
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#1a172a] border border-[#ebdcd5] dark:border-slate-700 text-xs font-mono font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                      Tên chủ tài khoản:
                    </label>
                    <input
                      type="text"
                      placeholder="Nhập họ và tên chủ tài khoản..."
                      value={accountHolder}
                      onChange={(e) => setAccountHolder(e.target.value.toUpperCase())}
                      className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#1a172a] border border-[#ebdcd5] dark:border-slate-700 text-xs font-bold uppercase text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                    Ghi chú thêm cho BQT (không bắt buộc):
                  </label>
                  <input
                    type="text"
                    placeholder="VD: Rút nhuận bút truyện tháng này..."
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-[#1a172a] border border-[#ebdcd5] dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-3">
                <button
                  type="submit"
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all hover:scale-101"
                >
                  <Coins className="w-4 h-4" />
                  <span>Xác Nhận Gửi Yêu Cầu Rút {amountXu} Xu ({amountVnd.toLocaleString()} đ)</span>
                </button>
              </div>

            </form>
          )}

        </div>

        {/* Footer info */}
        <div className="px-6 py-3 bg-white dark:bg-[#181528] border-t border-[#ebdcd5] dark:border-pink-500/20 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
          <span>Tác giả được hưởng tới 98% nhuận bút VIP.</span>
          <span>Hỗ trợ chuyển khoản 24/7 qua MB Bank</span>
        </div>

      </div>
    </div>
  );
};
