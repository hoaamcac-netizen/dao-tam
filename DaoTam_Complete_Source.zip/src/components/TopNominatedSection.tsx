import React from 'react';
import { Novel, UserProfile } from '../types';
import { Trophy, Crown, Sparkles, ChevronRight, BookOpen } from 'lucide-react';

interface TopNominatedSectionProps {
  novels: Novel[];
  onSelectNovel: (novel: Novel) => void;
  onOpenNominate?: (novel: Novel) => void;
  onOpenDailyReward: () => void;
  user: UserProfile;
  onSelectCreator?: (creatorName: string) => void;
}

export const TopNominatedSection: React.FC<TopNominatedSectionProps> = ({
  novels,
  onSelectNovel,
  onOpenDailyReward,
  user,
  onSelectCreator,
}) => {
  // Sắp xếp theo số lượt đề cử/hoa giảm dần và lấy top 12
  const top12Novels = [...novels]
    .filter((n) => !n.isHidden && n.publishStatus !== 'hidden')
    .sort((a, b) => (b.flowerCount || 0) - (a.flowerCount || 0))
    .slice(0, 12);

  if (top12Novels.length === 0) return null;

  return (
    <section className="mb-12 relative">
      {/* Decorative background glow */}
      <div className="absolute -top-10 left-1/4 w-96 h-48 bg-gradient-to-r from-blue-500/10 via-cyan-500/10 to-sky-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-6 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-sky-500 to-cyan-400 p-0.5 shadow-md">
            <div className="w-full h-full rounded-[10px] bg-white dark:bg-slate-900 flex items-center justify-center text-lg">
              🏆
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-slate-100">
                Bảng Vàng Đề Cử • Top 12 Tác Phẩm Hay
              </h2>
              <span className="hidden md:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-blue-50 dark:bg-slate-800 text-blue-600 dark:text-cyan-400 text-[11px] font-semibold">
                <Sparkles className="w-3 h-3 text-amber-500" />
                Vinh danh tuần
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              12 tác phẩm xuất sắc nhất được bạn đọc &amp; BQT trao tặng nhiều phiếu đề cử nhất
            </p>
          </div>
        </div>

        {/* Action Button: Check-in / My Flowers */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenDailyReward}
            className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-md shadow-blue-600/20 transition-all hover:scale-102 cursor-pointer"
            title="Điểm danh nhận hoa đề cử truyện yêu thích"
          >
            <span>🌸</span>
            <span>Điểm Danh Nhận Hoa (+5)</span>
          </button>
        </div>
      </div>

      {/* Grid of Top 12 Nominated Novels (Flat, borderless, soft shadow) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5 sm:gap-4">
        {top12Novels.map((novel, index) => {
          const rank = index + 1;
          const isTop1 = rank === 1;
          const isTop2 = rank === 2;
          const isTop3 = rank === 3;

          return (
            <div
              key={novel.id}
              onClick={() => onSelectNovel(novel)}
              className="group relative rounded-xl overflow-hidden flex flex-col cursor-pointer transition-all duration-300 transform hover:-translate-y-1 bg-white dark:bg-slate-800 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] dark:shadow-lg dark:shadow-black/40 hover:shadow-xl hover:shadow-blue-500/10"
            >
              {/* Thumbnail Container */}
              <div className="relative aspect-[2/3] w-full overflow-hidden bg-slate-900">
                <img
                  src={novel.coverImage}
                  alt={novel.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />

                {/* Rank Badge */}
                <div className="absolute top-2 left-2 z-10">
                  {isTop1 ? (
                    <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 font-bold text-xs shadow-md flex items-center gap-1">
                      <Crown className="w-3.5 h-3.5 fill-slate-950" />
                      #1
                    </span>
                  ) : isTop2 ? (
                    <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-slate-200 to-slate-400 text-slate-950 font-bold text-xs shadow-md flex items-center gap-1">
                      <Trophy className="w-3 h-3 text-slate-900" />
                      #2
                    </span>
                  ) : isTop3 ? (
                    <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-600 to-amber-700 text-white font-bold text-xs shadow-md flex items-center gap-1">
                      <Trophy className="w-3 h-3 text-amber-200" />
                      #3
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full bg-black/60 text-slate-200 font-bold text-xs shadow-xs backdrop-blur-xs">
                      #{rank}
                    </span>
                  )}
                </div>

                {/* Flower Count Badge */}
                <div className="absolute top-2 right-2 z-10">
                  <span className="px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-xs text-cyan-300 text-[10px] font-semibold flex items-center gap-0.5 shadow-xs">
                    🌸 {novel.flowerCount || 0}
                  </span>
                </div>

                {/* Bottom Overlay with Chapters */}
                <div className="absolute inset-x-0 bottom-0 pt-6 pb-2 px-2 bg-gradient-to-t from-black/85 via-black/40 to-transparent flex items-center justify-between text-[11px] text-white">
                  <span className="flex items-center gap-1 font-medium bg-black/50 px-2 py-0.5 rounded-full backdrop-blur-xs text-slate-200">
                    <BookOpen className="w-3 h-3 text-cyan-400" />
                    {novel.totalChapters} c
                  </span>
                </div>
              </div>

              {/* Info Container - Pure white background with solid black high-contrast text */}
              <div className="p-2.5 flex-1 flex flex-col justify-between bg-white">
                <div>
                  <h3 className="font-bold text-xs text-black !text-black group-hover:!text-blue-600 transition-colors line-clamp-2 leading-snug">
                    {novel.title}
                  </h3>
                  <div 
                    onClick={(e) => {
                      if (onSelectCreator) {
                        e.stopPropagation();
                        onSelectCreator(novel.author);
                      }
                    }}
                    className="text-[11px] text-black !text-black font-semibold mt-1 line-clamp-1 hover:text-blue-600 hover:underline cursor-pointer"
                    title={`Xem trang cá nhân của ${novel.author}`}
                  >
                    {novel.author}
                  </div>
                </div>

                <div className="mt-2 pt-2 border-t border-slate-200 flex items-center justify-between text-[10.5px]">
                  <span className="text-blue-700 !text-blue-700 font-bold truncate">
                    {novel.categories[0]}
                  </span>
                  <span className="text-slate-500 font-medium text-[10px]">
                    🌸 {novel.flowerCount || 0} hoa
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
