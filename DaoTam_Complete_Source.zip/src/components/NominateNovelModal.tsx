import React, { useState } from 'react';
import { Novel, UserProfile } from '../types';
import { X, Sparkles, Trophy, Heart, CheckCircle2, AlertCircle } from 'lucide-react';

interface NominateNovelModalProps {
  isOpen: boolean;
  onClose: () => void;
  novel: Novel | null;
  user: UserProfile;
  onNominate: (novelId: string, flowerCount: number) => void;
  onOpenDailyReward: () => void;
}

export const NominateNovelModal: React.FC<NominateNovelModalProps> = ({
  isOpen,
  onClose,
  novel,
  user,
  onNominate,
  onOpenDailyReward,
}) => {
  const [selectedAmount, setSelectedAmount] = useState<number>(5);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen || !novel) return null;

  const isAdmin = user.role === 'admin';
  const userFlowers = user.flowerBalance ?? 0;

  const quickAmounts = [1, 5, 10, 20, 50, 100];
  if (isAdmin) {
    quickAmounts.push(500, 1000);
  }

  const effectiveAmount = customAmount ? parseInt(customAmount, 10) || 0 : selectedAmount;

  const handleNominateSubmit = () => {
    setErrorMsg('');
    if (!effectiveAmount || effectiveAmount <= 0) {
      setErrorMsg('Vui lòng chọn hoặc nhập số hoa hợp lệ (tối thiểu 1 hoa)!');
      return;
    }

    if (!isAdmin && effectiveAmount > userFlowers) {
      setErrorMsg(`Bạn không đủ hoa (Hiện có: ${userFlowers} hoa). Hãy điểm danh mỗi ngày để nhận thêm!`);
      return;
    }

    onNominate(novel.id, effectiveAmount);
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 1400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-lg bg-[#110e1c] border-2 border-pink-500/40 rounded-3xl p-6 sm:p-7 shadow-2xl shadow-pink-950/60 overflow-hidden text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Ambient background bloom */}
        <div className="absolute -top-20 -right-20 w-56 h-56 bg-pink-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-56 h-56 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Title */}
        <div className="flex items-center gap-2 mb-4">
          <span className="text-2xl">🌸</span>
          <div>
            <h2 className="font-serif text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-300 via-rose-200 to-amber-200">
              Đề Cử Tác Phẩm
            </h2>
            <p className="text-xs text-slate-400">Tặng hoa hồng để vinh danh tác phẩm lên Bảng Vàng</p>
          </div>
        </div>

        {/* Novel Card Preview */}
        <div className="flex items-center gap-3.5 p-3 rounded-2xl bg-[#19152b] border border-pink-500/30 mb-5">
          <img
            src={novel.coverImage}
            alt={novel.title}
            className="w-14 h-20 object-cover rounded-xl border border-pink-500/40 flex-shrink-0 shadow"
          />
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-sm text-white truncate">{novel.title}</h3>
            <p className="text-xs text-slate-400 mt-0.5">Tác giả: <span className="text-pink-300 font-medium">{novel.author}</span></p>
            <div className="flex items-center gap-2 mt-2">
              <span className="px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30 text-[11px] font-bold flex items-center gap-1">
                <span>🌸</span>
                <span>{(novel.flowerCount || 0).toLocaleString()} Hoa hiện có</span>
              </span>
            </div>
          </div>
        </div>

        {/* User Balance & Admin Indicator */}
        <div className="p-3.5 rounded-2xl bg-[#181328] border border-slate-800 mb-5 flex items-center justify-between">
          <div>
            <div className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Túi Hoa Của Bạn</div>
            <div className="text-lg font-black text-pink-300 flex items-center gap-1.5 mt-0.5">
              <span>🌸</span>
              <span>{isAdmin ? 'Vô Hạn (∞)' : userFlowers}</span>
              <span className="text-xs text-slate-400 font-normal">hoa</span>
            </div>
          </div>

          {!isAdmin && (
            <button
              onClick={() => {
                onClose();
                onOpenDailyReward();
              }}
              className="text-xs text-pink-400 hover:text-pink-300 underline font-semibold cursor-pointer"
            >
              + Nhận 5 hoa hôm nay
            </button>
          )}

          {isAdmin && (
            <span className="px-2.5 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[11px] font-bold">
              👑 Admin: Hoa Vô Hạn
            </span>
          )}
        </div>

        {/* Quick Amount Options */}
        <div className="mb-4">
          <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
            Chọn số lượng hoa đề cử:
          </label>
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
            {quickAmounts.map((amt) => {
              const isSelected = !customAmount && selectedAmount === amt;
              return (
                <button
                  key={amt}
                  type="button"
                  onClick={() => {
                    setSelectedAmount(amt);
                    setCustomAmount('');
                    setErrorMsg('');
                  }}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1 border ${
                    isSelected
                      ? 'bg-pink-600 text-white border-pink-400 shadow-md shadow-pink-600/40 scale-102'
                      : 'bg-[#181328] text-slate-300 hover:text-white border-slate-800 hover:border-pink-500/40'
                  }`}
                >
                  <span>🌸</span>
                  <span>{amt}</span>
                  <span className="text-[10px] opacity-80">hoa</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Custom Amount Input */}
        <div className="mb-5">
          <div className="relative">
            <input
              type="number"
              min="1"
              max={isAdmin ? 999999 : userFlowers}
              value={customAmount}
              onChange={(e) => {
                setCustomAmount(e.target.value);
                setErrorMsg('');
              }}
              placeholder="Hoặc tự nhập số hoa muốn tặng..."
              className="w-full bg-[#181328] border border-slate-800 focus:border-pink-500 rounded-xl py-2.5 pl-3.5 pr-14 text-xs text-white placeholder-slate-500 focus:outline-none transition-all"
            />
            <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-pink-400">
              🌸 Hoa
            </span>
          </div>
        </div>

        {/* Error message */}
        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Success message */}
        {isSuccess ? (
          <div className="py-3.5 rounded-2xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 font-bold text-sm flex items-center justify-center gap-2 shadow-inner">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span>Đã đề cử thành công {effectiveAmount} hoa cho tác phẩm!</span>
          </div>
        ) : (
          <button
            onClick={handleNominateSubmit}
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-pink-600 via-rose-500 to-amber-500 hover:from-pink-500 hover:to-amber-400 text-white font-black text-sm uppercase tracking-wide flex items-center justify-center gap-2 shadow-xl shadow-pink-600/40 hover:scale-[1.01] active:scale-[0.98] transition-all cursor-pointer"
          >
            <Heart className="w-4 h-4 fill-white text-white" />
            <span>Xác Nhận Đề Cử ({effectiveAmount} Hoa)</span>
          </button>
        )}
      </div>
    </div>
  );
};
