import React, { useState, useRef, useMemo } from 'react';
import { MainCategory, UserProfile, Novel, SubmissionChapterDraft, Chapter, GenreItem, StoryRole } from '../types';
import { 
  X, 
  Upload, 
  CheckCircle2, 
  FileText, 
  Plus, 
  Sparkles, 
  Calendar, 
  Clock, 
  Layers, 
  Info,
  BookOpen,
  Image as ImageIcon,
  Check
} from 'lucide-react';

interface SubmitNovelModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  genres: GenreItem[];
  onAddNewGenre?: (name: string) => void;
  onSubmitForApproval: (submission: {
    title: string;
    author: string;
    editor?: string;
    publisherRoles: StoryRole[];
    isExclusive?: boolean;
    royaltyRate?: number;
    mainCategory: MainCategory;
    categories: string[];
    description: string;
    coverImage: string;
    chapters: SubmissionChapterDraft[];
    totalExpectedChapters: number;
    isOriginal?: boolean;
    isSensitive?: boolean;
    status?: 'Hoàn thành' | 'Đang ra';
    scheduledPublishAt?: number;
    bankInfo?: {
      bankName: string;
      accountNumber: string;
      accountHolder: string;
    };
    isCreatorApplication?: boolean;
  }) => void;
  onDirectPublishByAdmin?: (newNovel: Novel) => void;
}

// 60 phổ biến và phong phú theo đúng ảnh mẫu giao diện
const DEFAULT_GENRE_OPTIONS = [
  'ABO', 'BE', 'Chủ công', 'Chủ thụ', 'Chữa Lành', 'Cổ Đại', 
  'Cung Đấu', 'Cưới Trước Yêu Sau', 'Cường Thủ Hào Đoạt', 'Dị Năng', 
  'Dưỡng Thành', 'Điền Văn', 'Đô Thị', 'Đoản Văn', 'Độc Tâm', 
  'Giả Thây', 'Gia Đình', 'Hài Hước', 'Hành Động', 'Hào Môn Thế Gia', 
  'HE', 'Hệ Thống', 'Hiện Đại', 'Hoán Đổi Thân Xác', 'Học Đường', 
  'Hư Cấu Kỳ Ảo', 'Huyền Huyễn', 'Kinh Dị', 'Linh Dị', 'Mạt Thế', 
  'Ngọt', 'Ngược Luyến Tàn Tâm', 'Nhân Thú', 'Niên Đại', 'OE', 
  'Phép Thuật', 'Phiêu Lưu', 'Phương Đông', 'Phương Tây', 'Quỷ Tắc', 
  'Sáng Văn', 'SE', 'Showbiz', 'Sủng', 'Thanh Xuân Vườn Trường', 
  'Tiên Hiệp', 'Tiểu Thuyết', 'Tổng Tài', 'Trinh Thám', 'Trọng Sinh', 
  'Truy Thê', 'Vô Năng', 'Vô Tri', 'Xuyên Không', 'Xuyên Nhanh'
];

export const SubmitNovelModal: React.FC<SubmitNovelModalProps> = ({
  isOpen,
  onClose,
  user,
  genres,
  onAddNewGenre,
  onSubmitForApproval,
  onDirectPublishByAdmin,
}) => {
  // Phân quyền: Admin hoặc Tác giả chính thức đã duyệt
  const isApprovedCreator = user.role === 'admin' || user.role === 'author';

  // Left Column States
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState(user.displayName || '');
  const [isOriginal, setIsOriginal] = useState(false); // Toggle Truyện sáng tác
  const [description, setDescription] = useState('');
  const [isCompleted, setIsCompleted] = useState(false); // Toggle Đã bộ / Hoàn thành
  const [coverImage, setCoverImage] = useState<string>('');
  const [coverFileName, setCoverFileName] = useState<string>('');
  const [coverUrlInput, setCoverUrlInput] = useState<string>('');
  const [isSensitive, setIsSensitive] = useState(false);

  // Right Column States
  const [mainCategory, setMainCategory] = useState<MainCategory>('dam-my');
  const [selectedGenres, setSelectedGenres] = useState<string[]>(['Đam Mỹ', 'Cổ Đại']);
  const [customGenreInput, setCustomGenreInput] = useState('');
  const [scheduledPublishAt, setScheduledPublishAt] = useState<string>('');

  // 5 Chapter Drafts (bắt buộc đối với Tác giả / Editor MỚI chưa duyệt)
  const [activeDraftTab, setActiveDraftTab] = useState<number>(0);
  const [draftChapters, setDraftChapters] = useState<SubmissionChapterDraft[]>([
    {
      number: 1,
      title: 'Chương 1: Khởi đầu định mệnh',
      content: '',
    },
    {
      number: 2,
      title: 'Chương 2: Làn sóng ngầm',
      content: '',
    },
    {
      number: 3,
      title: 'Chương 3: Cuộc chạm trán bất ngờ',
      content: '',
    },
    {
      number: 4,
      title: 'Chương 4: Thăm dò và manh mối',
      content: '',
    },
    {
      number: 5,
      title: 'Chương 5: Quyết định trọng đại',
      content: '',
    },
  ]);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const draftFileRef = useRef<HTMLInputElement>(null);

  // Tính số đoạn (Paragraphs) và số từ (Words) của Mô tả truyện
  const { paragraphsCount, wordsCount } = useMemo(() => {
    if (!description.trim()) return { paragraphsCount: 0, wordsCount: 0 };
    const paragraphs = description.split(/\n+/).filter((p) => p.trim().length > 0);
    const words = description.trim().split(/\s+/).filter(Boolean);
    return {
      paragraphsCount: paragraphs.length,
      wordsCount: words.length,
    };
  }, [description]);

  // Hợp nhất danh sách thể loại từ props và mặc định
  const allGenreList = useMemo(() => {
    const customNames = genres.map((g) => g.name);
    const combined = Array.from(new Set([...DEFAULT_GENRE_OPTIONS, ...customNames]));
    return combined.sort((a, b) => a.localeCompare(b, 'vi'));
  }, [genres]);

  if (!isOpen) return null;

  // Xử lý tải ảnh bìa từ máy
  const handleCoverFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Vui lòng chọn tệp hình ảnh hợp lệ (PNG, JPG, WEBP).');
      return;
    }

    setCoverFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setCoverImage(event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  // Tải bản thảo từ tệp .txt
  const handleDraftFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (!text) return;

      const splits = text.split(/(?:===|\b)(?:Chương|Hồi)\s+\d+[:\s.-]*/i).filter((s) => s.trim().length > 0);
      if (splits.length >= 5) {
        setDraftChapters(
          splits.slice(0, 5).map((content, idx) => ({
            number: idx + 1,
            title: `Chương ${idx + 1}: Bản thảo trích xuất từ tệp`,
            content: content.trim(),
            wordCount: content.split(/\s+/).filter(Boolean).length,
          }))
        );
        alert(`Đã trích xuất thành công 5 chương từ tệp "${file.name}"!`);
      } else {
        const paragraphs = text.split(/\n\s*\n/).filter((p) => p.trim().length > 0);
        const perChap = Math.max(1, Math.ceil(paragraphs.length / 5));
        const newChapters = Array.from({ length: 5 }).map((_, idx) => {
          const slice = paragraphs.slice(idx * perChap, (idx + 1) * perChap).join('\n\n');
          return {
            number: idx + 1,
            title: `Chương ${idx + 1}: Trích đoạn bản thảo`,
            content: slice.trim() || `Nội dung chương ${idx + 1}...`,
            wordCount: slice.split(/\s+/).filter(Boolean).length,
          };
        });
        setDraftChapters(newChapters);
        alert(`Đã tải nội dung từ "${file.name}" và chia vào 5 chương bản thảo!`);
      }
    };
    reader.readAsText(file);
  };

  const handleToggleGenre = (genreName: string) => {
    if (selectedGenres.includes(genreName)) {
      if (selectedGenres.length > 1) {
        setSelectedGenres(selectedGenres.filter((g) => g !== genreName));
      }
    } else {
      setSelectedGenres([...selectedGenres, genreName]);
    }
  };

  const handleAddCustomGenre = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = customGenreInput.trim();
    if (!trimmed) return;
    if (onAddNewGenre) onAddNewGenre(trimmed);
    if (!selectedGenres.includes(trimmed)) {
      setSelectedGenres([...selectedGenres, trimmed]);
    }
    setCustomGenreInput('');
  };

  const updateDraftChapter = (idx: number, field: 'title' | 'content', value: string) => {
    setDraftChapters((prev) =>
      prev.map((c, i) =>
        i === idx
          ? {
              ...c,
              [field]: value,
              wordCount: field === 'content' ? value.split(/\s+/).filter(Boolean).length : c.wordCount,
            }
          : c
      )
    );
  };

  // Submit Handler
  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      alert('Vui lòng nhập Tên truyện.');
      return;
    }

    if (!author.trim()) {
      alert('Vui lòng nhập Tên tác giả.');
      return;
    }

    if (!description.trim()) {
      alert('Vui lòng nhập Mô tả truyện.');
      return;
    }

    const finalCover = coverImage || coverUrlInput.trim() || 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80';

    // Parse scheduled date/time if selected
    let scheduledTimestamp: number | undefined = undefined;
    if (scheduledPublishAt) {
      const parsedTime = new Date(scheduledPublishAt).getTime();
      if (!isNaN(parsedTime) && parsedTime > Date.now()) {
        scheduledTimestamp = parsedTime;
      }
    }

    // Nếu là Tác giả / Editor MỚI (chưa duyệt): Bắt buộc kiểm tra 5 chương bản thảo
    if (!isApprovedCreator) {
      for (let i = 0; i < 5; i++) {
        const chap = draftChapters[i];
        if (!chap.title.trim()) {
          alert(`Vui lòng nhập tiêu đề cho Chương bản thảo số ${i + 1}.`);
          setActiveDraftTab(i);
          return;
        }
        if (!chap.content.trim() || chap.content.trim().length < 50) {
          alert(`Nội dung Chương ${i + 1} quá ngắn. Vui lòng gửi tối thiểu 50 ký tự mỗi chương để Ban Quản Trị duyệt bản thảo.`);
          setActiveDraftTab(i);
          return;
        }
      }
    }

    setIsSubmitting(true);

    try {
      if (isApprovedCreator) {
        // Tác giả/Admin được duyệt: Đăng truyện ngay
        if (user.role === 'admin' && onDirectPublishByAdmin) {
          const slug = title
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/[^\w\s-]/g, '')
            .replace(/\s+/g, '-');

          const newNovel: Novel = {
            id: `novel-${Date.now()}`,
            title: title.trim(),
            slug: `${slug}-${Date.now().toString().slice(-4)}`,
            author: author.trim(),
            editor: user.displayName,
            coverImage: finalCover,
            mainCategory,
            status: isCompleted ? 'Hoàn thành' : 'Đang ra',
            publishStatus: 'published',
            isHidden: false,
            isOriginal,
            isSensitive,
            isExclusive: false,
            royaltyRate: 0.95,
            totalChapters: 1,
            views: 0,
            dailyViews: 0,
            rating: 5.0,
            categories: selectedGenres,
            description: description.trim(),
            updatedAt: Date.now(),
            lastUpdated: 'Vừa xong',
            hasAudio: true,
            fullBookPriceXu: 150,
            chapters: [
              {
                id: `chap-${Date.now()}-1`,
                number: 1,
                title: 'Chương 1: Mở đầu câu chuyện',
                slug: 'chuong-1',
                content: description.trim(),
                wordCount: description.split(/\s+/).filter(Boolean).length,
                publishedDate: new Date().toLocaleDateString('vi-VN'),
                isVip: false,
                priceXu: 0,
              },
            ],
          };

          onDirectPublishByAdmin(newNovel);
        } else {
          // Tác giả chính thức
          onSubmitForApproval({
            title: title.trim(),
            author: author.trim(),
            editor: user.displayName,
            publisherRoles: ['author'],
            isExclusive: false,
            royaltyRate: 0.95,
            mainCategory,
            categories: selectedGenres,
            description: description.trim(),
            coverImage: finalCover,
            chapters: [
              {
                number: 1,
                title: 'Chương 1: Mở đầu tác phẩm',
                content: description.trim(),
                wordCount: description.split(/\s+/).filter(Boolean).length,
              },
            ],
            totalExpectedChapters: 100,
            isOriginal,
            isSensitive,
            status: isCompleted ? 'Hoàn thành' : 'Đang ra',
            scheduledPublishAt: scheduledTimestamp,
          });
        }
        alert('🎉 Đã đăng truyện thành công lên hệ thống!');
      } else {
        // Tác giả / Editor MỚI -> Gửi bản thảo 5 chương để xét duyệt
        onSubmitForApproval({
          title: title.trim(),
          author: author.trim(),
          editor: user.displayName,
          publisherRoles: ['author'],
          isExclusive: false,
          royaltyRate: 0.90,
          mainCategory,
          categories: selectedGenres,
          description: description.trim(),
          coverImage: finalCover,
          chapters: draftChapters,
          totalExpectedChapters: 100,
          isOriginal,
          isSensitive,
          status: isCompleted ? 'Hoàn thành' : 'Đang ra',
          scheduledPublishAt: scheduledTimestamp,
          isCreatorApplication: true,
        });
        alert('✅ Đã gửi 5 chương bản thảo thành công! Ban Quản Trị sẽ xem xét và phản hồi trong thời gian sớm nhất.');
      }

      onClose();
    } catch (err) {
      console.error('Lỗi khi đăng truyện:', err);
      alert('Có lỗi xảy ra khi xử lý yêu cầu. Vui lòng thử lại!');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-6xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col my-auto max-h-[96vh] animate-in fade-in zoom-in-95 duration-200">
        
        {/* Top Header / Breadcrumbs */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
              <span>Trang chủ</span>
              <span>&gt;</span>
              <span className="text-slate-800 font-medium">Thêm truyện mới</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-blue-500" />
              Thêm truyện mới
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200/70 rounded-full transition cursor-pointer"
            title="Đóng cửa sổ"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body - 2 Columns */}
        <form onSubmit={handleSubmitForm} className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* ==========================================
                CỘT TRÁI (LEFT COLUMN - 7 COLS)
               ========================================== */}
            <div className="lg:col-span-7 space-y-5">
              
              {/* Tên truyện */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Tên truyện <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Nhập tên truyện"
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition"
                  required
                />
              </div>

              {/* Tác giả */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Tác giả <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={author}
                  onChange={(e) => setAuthor(e.target.value)}
                  placeholder="Tên tác giả"
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition"
                  required
                />
              </div>

              {/* Toggle Truyện sáng tác */}
              <div className="flex items-center justify-between py-2 border-y border-slate-100">
                <div>
                  <span className="text-sm font-medium text-slate-800">Truyện sáng tác</span>
                  <p className="text-xs text-slate-500">Đánh dấu tác phẩm do chính bạn sáng tác</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isOriginal}
                    onChange={(e) => setIsOriginal(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                </label>
              </div>

              {/* Mô tả truyện */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Mô tả truyện <span className="text-rose-500">*</span>
                </label>
                <div className="border border-slate-300 rounded-lg overflow-hidden focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-100 transition">
                  <textarea
                    rows={8}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Nhập nội dung văn án, tóm tắt truyện..."
                    className="w-full p-3.5 bg-white text-sm text-slate-900 placeholder-slate-400 focus:outline-none resize-y min-h-[160px]"
                    required
                  />
                  {/* Live Word & Paragraph Counter */}
                  <div className="px-3.5 py-2 bg-slate-50 border-t border-slate-200 text-right text-xs text-slate-500 font-mono">
                    Paragraphs: <span className="font-semibold text-slate-700">{paragraphsCount}</span>, Words: <span className="font-semibold text-slate-700">{wordsCount}</span>
                  </div>
                </div>
              </div>

              {/* Toggle Đã bộ / Hoàn thành */}
              <div className="flex items-center justify-between py-2 border-y border-slate-100">
                <div>
                  <span className="text-sm font-medium text-slate-800">Đã bộ</span>
                  <p className="text-xs text-slate-500">Bật nếu truyện đã hoàn thành toàn bộ nội dung</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isCompleted}
                    onChange={(e) => setIsCompleted(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                </label>
              </div>

              {/* Ảnh bìa */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Ảnh bìa
                </label>
                <div className="flex flex-col sm:flex-row gap-4 items-start">
                  <div className="flex-1 space-y-2 w-full">
                    <div className="flex items-center gap-3">
                      <input
                        type="file"
                        ref={fileInputRef}
                        accept="image/*"
                        onChange={handleCoverFileUpload}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="px-4 py-2 border border-slate-300 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-700 transition cursor-pointer flex items-center gap-1.5"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        Chọn tệp
                      </button>
                      <span className="text-xs text-slate-500 truncate max-w-[200px]">
                        {coverFileName || 'Chưa có tệp nào được chọn'}
                      </span>
                    </div>

                    <div className="relative">
                      <input
                        type="url"
                        value={coverUrlInput}
                        onChange={(e) => setCoverUrlInput(e.target.value)}
                        placeholder="Hoặc dán link ảnh bìa (URL https://...)"
                        className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-400"
                      />
                    </div>
                  </div>

                  {/* Thumbnail Preview */}
                  {(coverImage || coverUrlInput) && (
                    <div className="w-16 h-24 rounded-lg overflow-hidden border border-slate-200 shadow-sm flex-shrink-0 bg-slate-50">
                      <img
                        src={coverImage || coverUrlInput}
                        alt="Bìa truyện"
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=200&q=80';
                        }}
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* =========================================================================
                  5 KHUNG NHẬP LIỆU BẢN THẢO (Bắt buộc cho Tác giả / Editor MỚI chưa duyệt)
                 ========================================================================= */}
              {!isApprovedCreator && (
                <div className="mt-6 p-4 rounded-xl bg-blue-50/70 border border-blue-200 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-blue-200/70 pb-3">
                    <div>
                      <h4 className="font-bold text-sm text-blue-900 flex items-center gap-2">
                        <FileText className="w-4 h-4 text-blue-600" />
                        5 Chương Bản Thảo Xét Duyệt
                      </h4>
                      <p className="text-xs text-blue-700">
                        Bạn chưa là tác giả chính thức. Vui lòng cung cấp 5 chương mẫu để BQT duyệt quyền đăng truyện.
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <input
                        type="file"
                        ref={draftFileRef}
                        accept=".txt"
                        onChange={handleDraftFileUpload}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => draftFileRef.current?.click()}
                        className="px-3 py-1.5 rounded-lg bg-white border border-blue-300 text-blue-700 hover:bg-blue-100 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        Tải từ tệp .txt
                      </button>
                    </div>
                  </div>

                  {/* Tabs chọn 5 chương */}
                  <div className="flex items-center gap-1 overflow-x-auto pb-1">
                    {draftChapters.map((chap, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setActiveDraftTab(idx)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition whitespace-nowrap cursor-pointer ${
                          activeDraftTab === idx
                            ? 'bg-blue-500 text-white shadow-sm'
                            : 'bg-white text-slate-700 hover:bg-blue-100/60 border border-slate-200'
                        }`}
                      >
                        Chương {idx + 1} {chap.content.trim() ? '✓' : ''}
                      </button>
                    ))}
                  </div>

                  {/* Khung nhập liệu chương đang chọn */}
                  <div className="space-y-3 bg-white p-3.5 rounded-lg border border-blue-200">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Tiêu đề Chương {activeDraftTab + 1} <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={draftChapters[activeDraftTab].title}
                        onChange={(e) => updateDraftChapter(activeDraftTab, 'title', e.target.value)}
                        placeholder={`Ví dụ: Chương ${activeDraftTab + 1}: Diễn biến câu chuyện`}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-blue-500"
                        required={!isApprovedCreator}
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center justify-between">
                        <span>Nội dung Chương {activeDraftTab + 1} <span className="text-rose-500">*</span></span>
                        <span className="text-[11px] text-slate-400 font-normal">
                          {draftChapters[activeDraftTab].content.split(/\s+/).filter(Boolean).length} từ
                        </span>
                      </label>
                      <textarea
                        rows={6}
                        value={draftChapters[activeDraftTab].content}
                        onChange={(e) => updateDraftChapter(activeDraftTab, 'content', e.target.value)}
                        placeholder="Nhập hoặc dán nội dung chương bản thảo vào đây..."
                        className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-blue-500 resize-y"
                        required={!isApprovedCreator}
                      />
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* ==========================================
                CỘT PHẢI (RIGHT COLUMN - 5 COLS)
               ========================================== */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Danh mục chính (3 Radio Buttons) */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-800 mb-3">
                  Danh mục chính <span className="text-rose-500">*</span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'dam-my', label: 'Đam Mỹ' },
                    { id: 'truyen-nam', label: 'Truyện Nam' },
                    { id: 'truyen-nu', label: 'Truyện Nữ' },
                  ].map((cat) => (
                    <label
                      key={cat.id}
                      className={`flex items-center justify-center gap-2 p-2.5 rounded-lg border text-xs font-semibold cursor-pointer transition ${
                        mainCategory === cat.id
                          ? 'bg-blue-50 border-blue-400 text-blue-700 ring-1 ring-blue-400'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <input
                        type="radio"
                        name="mainCategory"
                        value={cat.id}
                        checked={mainCategory === cat.id}
                        onChange={() => setMainCategory(cat.id as MainCategory)}
                        className="w-3.5 h-3.5 text-blue-500 focus:ring-blue-400 border-slate-300"
                      />
                      <span>{cat.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Thể loại (2 Cột Checkbox phong phú) */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-800">
                    Thể loại ({selectedGenres.length})
                  </label>
                  <span className="text-[11px] text-slate-500">Chọn nhiều thể loại</span>
                </div>

                {/* 2-column genres checklist */}
                <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 max-h-64 overflow-y-auto pr-1 text-xs">
                  {allGenreList.map((gName) => {
                    const isChecked = selectedGenres.includes(gName);
                    return (
                      <label
                        key={gName}
                        className={`flex items-center gap-2 p-1 rounded hover:bg-slate-200/50 cursor-pointer select-none transition ${
                          isChecked ? 'text-blue-700 font-semibold' : 'text-slate-700'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleToggleGenre(gName)}
                          className="w-3.5 h-3.5 rounded text-blue-500 focus:ring-blue-400 border-slate-300 cursor-pointer"
                        />
                        <span className="truncate">{gName}</span>
                      </label>
                    );
                  })}
                </div>

                {/* Thêm thể loại tùy chỉnh */}
                <div className="mt-3 pt-2.5 border-t border-slate-200 flex items-center gap-2">
                  <input
                    type="text"
                    value={customGenreInput}
                    onChange={(e) => setCustomGenreInput(e.target.value)}
                    placeholder="Thêm thể loại khác..."
                    className="flex-1 px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-400"
                  />
                  <button
                    type="button"
                    onClick={handleAddCustomGenre}
                    className="px-3 py-1.5 rounded-lg bg-blue-100 hover:bg-blue-200 text-blue-700 text-xs font-semibold transition cursor-pointer flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Thêm
                  </button>
                </div>
              </div>

              {/* Hẹn giờ lên truyện */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <label className="block text-xs font-semibold text-slate-800">
                  Hẹn giờ lên truyện
                </label>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  (Để huỷ hẹn giờ, chỉ cần chọn lại thời gian nhỏ hơn thời gian hiện tại)
                </p>
                <div className="relative">
                  <input
                    type="datetime-local"
                    value={scheduledPublishAt}
                    onChange={(e) => setScheduledPublishAt(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>
              </div>

              {/* Nút Đăng Truyện / Gửi Bản Thảo (TONE XANH BIỂN PASTEL - TUYỆT ĐỐI KHÔNG DÙNG HỒNG/ĐỎ) */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 px-6 rounded-xl bg-blue-500 hover:bg-blue-600 active:bg-blue-700 text-white font-semibold text-sm shadow-md shadow-blue-500/20 transition-all duration-200 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <span className="flex items-center gap-2">
                      <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                      </svg>
                      Đang xử lý...
                    </span>
                  ) : isApprovedCreator ? (
                    <>
                      <Sparkles className="w-4 h-4" />
                      Đăng Truyện Ngay
                    </>
                  ) : (
                    <>
                      <FileText className="w-4 h-4" />
                      Gửi Bản Thảo Xét Duyệt
                    </>
                  )}
                </button>
                <p className="text-center text-[11px] text-slate-400 mt-2">
                  {isApprovedCreator
                    ? 'Bạn có quyền xuất bản truyện trực tiếp lên kệ sách Đạo Tâm.'
                    : 'Bản thảo 5 chương sẽ được gửi tới Ban Quản Trị thẩm định chất lượng.'}
                </p>
              </div>

            </div>

          </div>
        </form>

      </div>
    </div>
  );
};
