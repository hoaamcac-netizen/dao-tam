import React, { useState, useMemo } from 'react';
import { 
  ArrowLeft, 
  Heart, 
  Eye, 
  BookOpen, 
  UserCheck, 
  UserPlus, 
  DollarSign, 
  Sparkles, 
  Flame, 
  Search,
  Plus,
  SlidersHorizontal,
  Edit3,
  Coins
} from 'lucide-react';
import { Novel, UserProfile } from '../types';
import { NovelCard } from './NovelCard';

export interface CreatorProfileData {
  id?: string;
  name: string;
  avatarUrl?: string;
  bio?: string;
  role?: string;
  followers?: string[];
  email?: string;
  xuBalance?: number;
}

interface CreatorProfileProps {
  creator: CreatorProfileData;
  allNovels: Novel[];
  currentUser: UserProfile;
  onBack: () => void;
  onSelectNovel: (novel: Novel) => void;
  onFollowToggle: (creatorIdOrName: string, shouldFollow: boolean) => void;
  onOpenDonateModal: (creator: CreatorProfileData) => void;
  onSelectCreator?: (creatorName: string) => void;
  onOpenEditProfile?: () => void;
  onOpenSubmitNovel?: () => void;
}

export const CreatorProfile: React.FC<CreatorProfileProps> = ({
  creator,
  allNovels,
  currentUser,
  onBack,
  onSelectNovel,
  onFollowToggle,
  onOpenDonateModal,
  onSelectCreator,
  onOpenEditProfile,
  onOpenSubmitNovel,
}) => {
  const [novelSearch, setNovelSearch] = useState('');
  const [selectedGenreFilter, setSelectedGenreFilter] = useState('all');

  const isSelf = currentUser.isLoggedIn && (
    (creator.id && creator.id === currentUser.id) ||
    (creator.email && creator.email === currentUser.email) ||
    creator.name.toLowerCase().trim() === currentUser.displayName.toLowerCase().trim()
  );

  // Lọc tất cả truyện liên quan đến Creator này
  const creatorNovels = useMemo(() => {
    const creatorNameLower = (creator.name || '').toLowerCase().trim();
    return allNovels.filter((n) => {
      const matchAuthor = n.author?.toLowerCase().trim() === creatorNameLower;
      const matchEditor = n.editor?.toLowerCase().trim() === creatorNameLower;
      const matchUserId = creator.id && n.submittedBy?.userId === creator.id;
      return matchAuthor || matchEditor || matchUserId;
    });
  }, [allNovels, creator]);

  // Thống kê tổng
  const totalNovels = creatorNovels.length;
  const totalViews = useMemo(() => {
    return creatorNovels.reduce((sum, n) => sum + (n.views || 0), 0);
  }, [creatorNovels]);

  // Số dư xu hiển thị (nếu là chính mình thì lấy từ currentUser.xuBalance)
  const displayXu = isSelf 
    ? (currentUser.xuBalance || 0)
    : (typeof creator.xuBalance === 'number' ? creator.xuBalance : 0);

  // Kiểm tra trạng thái đã theo dõi hay chưa
  const creatorKey = creator.id || creator.name;
  const isFollowing = useMemo(() => {
    if (!currentUser.followingCreators) return false;
    return (
      (creator.id && currentUser.followingCreators.includes(creator.id)) ||
      currentUser.followingCreators.includes(creator.name)
    );
  }, [currentUser.followingCreators, creator]);

  const followersCount = (creator.followers?.length || 0) + (isFollowing && !creator.followers?.includes(currentUser.id) ? 1 : 0);

  // Danh sách truyện có nhiều lượt xem trong tháng
  const topViewedNovels = useMemo(() => {
    return [...creatorNovels]
      .sort((a, b) => (b.dailyViews || b.views || 0) - (a.dailyViews || a.views || 0))
      .slice(0, 10);
  }, [creatorNovels]);

  // Lọc danh sách truyện theo ô tìm kiếm & thể loại
  const filteredAllNovels = useMemo(() => {
    return creatorNovels.filter((n) => {
      const matchSearch = !novelSearch.trim() || n.title.toLowerCase().includes(novelSearch.toLowerCase().trim());
      const matchGenre = selectedGenreFilter === 'all' || n.categories?.includes(selectedGenreFilter);
      return matchSearch && matchGenre;
    });
  }, [creatorNovels, novelSearch, selectedGenreFilter]);

  // Danh sách thể loại có trong truyện của tác giả này
  const availableGenres = useMemo(() => {
    const set = new Set<string>();
    creatorNovels.forEach((n) => n.categories?.forEach((c) => set.add(c)));
    return Array.from(set);
  }, [creatorNovels]);

  // Avatar: nếu chưa có ảnh hoặc rỗng thì dùng placeholder trung tính
  const avatarUrl = isSelf ? currentUser.avatarUrl : creator.avatarUrl;
  const displayName = isSelf ? currentUser.displayName : creator.name;
  const bioText = isSelf ? currentUser.bio : creator.bio;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 animate-in fade-in duration-200">
      
      {/* Top Navigation Back Button */}
      <div className="mb-4">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-blue-600 hover:text-white text-slate-700 dark:text-slate-300 text-xs font-semibold transition-all cursor-pointer shadow-2xs"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Quay lại trang trước</span>
        </button>
      </div>

      {/* =========================================================================
          KHỐI THÔNG TIN HỒ SƠ CÁ NHÂN (Chuẩn theo hình 4 - image_5e179d1d.png)
         ========================================================================= */}
      <div className="rounded-2xl bg-white dark:bg-slate-900 shadow-sm border border-slate-200 dark:border-slate-800 p-6 sm:p-8 mb-8">
        <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
          
          {/* Avatar Lớn */}
          <div className="relative flex-shrink-0">
            {avatarUrl ? (
              <img
                src={avatarUrl}
                alt={displayName}
                className="w-28 h-28 sm:w-32 sm:h-32 rounded-full object-cover border-4 border-amber-300/40 shadow-md bg-slate-100"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80';
                }}
              />
            ) : (
              /* Avatar trống khi mới tạo tài khoản */
              <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-full border-4 border-dashed border-slate-300 dark:border-slate-700 flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-800 text-slate-400">
                <span className="text-3xl font-bold uppercase">{displayName?.charAt(0) || 'U'}</span>
                <span className="text-[10px] mt-1">Chưa đổi ảnh</span>
              </div>
            )}
            
            {isSelf && onOpenEditProfile && (
              <button
                type="button"
                onClick={onOpenEditProfile}
                className="absolute bottom-1 right-1 p-2 rounded-full bg-blue-500 hover:bg-blue-600 text-white shadow-md transition cursor-pointer"
                title="Thay đổi ảnh đại diện"
              >
                <Edit3 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Chi tiết Tên, Tiểu sử, Thống kê, Cụm nút bấm */}
          <div className="flex-1 text-center md:text-left space-y-3">
            
            {/* Tên người dùng */}
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {displayName || 'Độc Giả Mới'}
            </h1>

            {/* Tiểu sử (Bio) */}
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
              {bioText?.trim() ? (
                bioText
              ) : isSelf ? (
                <span className="italic text-slate-400">
                  Chưa có tiểu sử giới thiệu. Nhấn "Thiết lập danh sách truyện hay" hoặc icon cây bút ở ảnh đại diện để điền thông tin và đổi ảnh đại diện.
                </span>
              ) : (
                <span className="italic text-slate-400">
                  Tác giả này chưa cập nhật tiểu sử.
                </span>
              )}
            </p>

            {/* 4 Thống kê chính: Xu hiện có, Lượt theo dõi, Lượt xem, Số truyện */}
            <div className="pt-2 text-xs text-slate-700 dark:text-slate-300 space-y-1 font-medium">
              <div>
                <span className="font-semibold text-slate-900 dark:text-white">Xu hiện có:</span>{' '}
                <span className="text-blue-600 dark:text-cyan-400 font-bold">{displayXu.toLocaleString('vi-VN')} xu</span>
              </div>
              <div>
                <span className="font-semibold text-slate-900 dark:text-white">Lượt theo dõi:</span>{' '}
                <span>{followersCount.toLocaleString('vi-VN')}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-900 dark:text-white">Lượt xem:</span>{' '}
                <span>{totalViews.toLocaleString('vi-VN')}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-900 dark:text-white">Số truyện:</span>{' '}
                <span>{totalNovels}</span>
              </div>
            </div>

            {/* Cụm Nút Bấm: $ Donate, + Theo dõi, Thiết lập danh sách truyện hay */}
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-2.5 pt-3">
              
              {/* Nút $ Donate màu đỏ/hồng */}
              <button
                type="button"
                onClick={() => onOpenDonateModal(creator)}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition cursor-pointer"
              >
                <DollarSign className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>$ Donate</span>
              </button>

              {/* Nút + Theo dõi / Đang theo dõi */}
              {!isSelf && (
                <button
                  type="button"
                  onClick={() => onFollowToggle(creatorKey, !isFollowing)}
                  className={`px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-sm ${
                    isFollowing
                      ? 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200'
                      : 'bg-blue-500 hover:bg-blue-600 text-white'
                  }`}
                >
                  {isFollowing ? (
                    <>
                      <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Đang theo dõi</span>
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>+ Theo dõi</span>
                    </>
                  )}
                </button>
              )}

              {/* Nút THIẾT LẬP DANH SÁCH TRUYỆN HAY (Màu vàng/amber chuẩn hình 4) */}
              <button
                type="button"
                onClick={() => {
                  if (onOpenEditProfile) {
                    onOpenEditProfile();
                  } else {
                    alert('Chức năng thiết lập danh sách truyện');
                  }
                }}
                className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-sm transition cursor-pointer uppercase tracking-wider"
              >
                <span>🎨 THIẾT LẬP DANH SÁCH TRUYỆN HAY</span>
              </button>

            </div>

          </div>

        </div>
      </div>

      {/* =========================================================================
          MỤC 1: TRUYỆN CÓ NHIỀU LƯỢT XEM TRONG THÁNG
         ========================================================================= */}
      <section className="mb-10 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6">
        <div className="flex items-center justify-between pb-3 mb-5 border-b border-slate-200 dark:border-slate-800">
          <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            TRUYỆN CÓ NHIỀU LƯỢT XEM TRONG THÁNG
          </h2>
          <span className="text-xs text-slate-500">
            {topViewedNovels.length} bộ truyện
          </span>
        </div>

        {topViewedNovels.length === 0 ? (
          <div className="text-center py-12 text-slate-400">
            <BookOpen className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
            <p className="text-xs font-medium">Chưa có truyện nào trong tháng này.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {topViewedNovels.map((novel) => (
              <div 
                key={`top-${novel.id}`}
                onClick={() => onSelectNovel(novel)}
                className="cursor-pointer group flex flex-col"
              >
                <div className="relative aspect-[2/3] rounded-xl overflow-hidden mb-2 bg-slate-100 dark:bg-slate-800 shadow-sm">
                  <img
                    src={novel.coverImage}
                    alt={novel.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=200&q=80';
                    }}
                  />
                  {/* Badge Lượt xem & số chương */}
                  <div className="absolute bottom-1.5 left-1.5 flex items-center gap-1.5 bg-black/60 backdrop-blur-xs text-white text-[10px] px-2 py-0.5 rounded-md font-medium">
                    <span className="flex items-center gap-0.5">
                      <Eye className="w-3 h-3" />
                      {novel.views || 0}
                    </span>
                    <span className="flex items-center gap-0.5">
                      <BookOpen className="w-3 h-3" />
                      {novel.chapters?.length || 1}
                    </span>
                  </div>
                </div>

                <h3 className="text-xs font-bold text-slate-800 dark:text-white line-clamp-2 group-hover:text-blue-500 transition-colors">
                  {novel.title}
                </h3>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* =========================================================================
          MỤC 2: DANH SÁCH TRUYỆN (Chuẩn theo hình 4 - image_5e179d1d.png)
         ========================================================================= */}
      <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6">
        
        {/* Title */}
        <div className="mb-4">
          <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            DANH SÁCH TRUYỆN
          </h2>
        </div>

        {/* Thanh Tìm Kiếm, Chọn Thể Loại, Lọc và Nút + Thêm */}
        <div className="flex flex-col sm:flex-row items-center gap-3 mb-6">
          
          {/* Ô Tìm truyện */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={novelSearch}
              onChange={(e) => setNovelSearch(e.target.value)}
              placeholder="Tìm truyện..."
              className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:border-blue-500 transition"
            />
          </div>

          {/* Chọn thể loại */}
          <div className="w-full sm:w-48">
            <select
              value={selectedGenreFilter}
              onChange={(e) => setSelectedGenreFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-blue-500 cursor-pointer"
            >
              <option value="all">Chọn thể loại...</option>
              {availableGenres.map((g) => (
                <option key={g} value={g}>{g}</option>
              ))}
            </select>
          </div>

          {/* Nút Lọc (Xanh Biển) */}
          <button
            type="button"
            className="w-full sm:w-auto px-5 py-2 rounded-full bg-blue-500 hover:bg-blue-600 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Lọc</span>
          </button>

          {/* Nút + Thêm (Xanh Biển) */}
          {onOpenSubmitNovel && (
            <button
              type="button"
              onClick={onOpenSubmitNovel}
              className="w-full sm:w-auto px-5 py-2 rounded-full bg-blue-500 hover:bg-blue-600 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Thêm</span>
            </button>
          )}

        </div>

        {/* Danh sách các tác phẩm dạng lưới */}
        {filteredAllNovels.length === 0 ? (
          <div className="text-center py-16 text-slate-400 bg-slate-50/50 dark:bg-slate-800/30 rounded-xl border border-dashed border-slate-200 dark:border-slate-800">
            <BookOpen className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
              {isSelf ? 'Bạn chưa đăng tác phẩm nào.' : 'Tác giả chưa có tác phẩm nào.'}
            </p>
            <p className="text-xs text-slate-400 mt-1">
              {isSelf 
                ? 'Nhấn vào nút "+ Thêm" bên trên để bắt đầu sáng tác và gửi bản thảo!' 
                : 'Hãy quay lại sau để đón đọc những bộ truyện mới nhất.'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {filteredAllNovels.map((novel) => (
              <NovelCard
                key={novel.id}
                novel={novel}
                onSelect={(n) => onSelectNovel(n)}
                onSelectCreator={onSelectCreator}
              />
            ))}
          </div>
        )}

      </section>

    </div>
  );
};
