import React, { useState, useMemo } from 'react';
import { Novel, Chapter, ReadingProgress, UserProfile } from '../types';
import { CommentsSection } from './CommentsSection';
import { 
  BookOpen, 
  Play, 
  Headphones, 
  Bookmark, 
  BookmarkCheck, 
  ArrowLeft, 
  Search, 
  ArrowDownUp, 
  Eye, 
  EyeOff,
  Edit3,
  Trash2,
  AlertTriangle,
  Star, 
  Lock,
  Unlock,
  Coins,
  CheckCircle2,
  Sparkles,
  ShoppingBag,
  Flag
} from 'lucide-react';

interface NovelDetailProps {
  novel: Novel;
  savedProgress?: ReadingProgress;
  isBookmarked: boolean;
  onToggleBookmark: (novelId: string) => void;
  onSelectChapter: (novel: Novel, chapter: Chapter) => void;
  onBack: () => void;
  user: UserProfile;
  onOpenVipPurchase: (novel: Novel, chapter: Chapter) => void;
  onToggleHideNovel?: (novelId: string) => void;
  onDeleteNovel?: (novelId: string) => void;
  onOpenEditNovel?: (novel: Novel) => void;
  onOpenNominate?: (novel: Novel) => void;
  onOpenAuthorShowcase?: (name: string, role: 'author' | 'editor') => void;
  onOpenReport?: (novel: Novel) => void;
}

export const NovelDetail: React.FC<NovelDetailProps> = ({
  novel,
  savedProgress,
  isBookmarked,
  onToggleBookmark,
  onSelectChapter,
  onBack,
  user,
  onOpenVipPurchase,
  onToggleHideNovel,
  onDeleteNovel,
  onOpenEditNovel,
  onOpenNominate,
  onOpenAuthorShowcase,
  onOpenReport,
}) => {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [searchChapter, setSearchChapter] = useState('');
  const [selectedRange, setSelectedRange] = useState<number>(0);
  const [isAscending, setIsAscending] = useState(true);

  const CHUNK_SIZE = 50;
  const totalChunks = Math.ceil(novel.chapters.length / CHUNK_SIZE) || 1;

  const isFullBookUnlocked = user.unlockedFullBooks.includes(novel.id);
  const unlockedChapterIds = user.unlockedChapters[novel.id] || [];

  // Filtered and sorted chapters
  const filteredChapters = useMemo(() => {
    let list = [...novel.chapters];

    if (searchChapter.trim()) {
      const q = searchChapter.toLowerCase().trim();
      list = list.filter(
        (c) =>
          c.title.toLowerCase().includes(q) ||
          c.number.toString().includes(q)
      );
    } else {
      const start = selectedRange * CHUNK_SIZE;
      const end = start + CHUNK_SIZE;
      list = list.slice(start, end);
    }

    if (!isAscending) {
      list.reverse();
    }

    return list;
  }, [novel.chapters, searchChapter, selectedRange, isAscending]);

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 text-[#231c26] dark:text-slate-200 transition-colors">
      {/* Back button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 text-sm text-slate-500 hover:text-pink-600 dark:text-slate-400 dark:hover:text-sky-300 mb-6 transition-colors group cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
        Trở về danh sách truyện
      </button>

      {/* Admin Quick Toolbar for Hiding and Deleting Novel */}
      {user.role === 'admin' && (
        <div className="mb-6 p-4 rounded-xl bg-purple-50/60 dark:bg-[#14101e] border border-purple-300 dark:border-purple-500/40 flex flex-wrap items-center justify-between gap-3 text-xs shadow-sm dark:shadow-lg">
          <div className="flex items-center gap-2.5">
            <span className="font-bold text-purple-700 dark:text-purple-300">Quản Trị Viên:</span>
            {novel.isHidden ? (
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 border border-purple-300 dark:border-purple-500/50 flex items-center gap-1">
                <EyeOff className="w-3.5 h-3.5" /> Truyện Đang Ẩn Khỏi Độc Giả
              </span>
            ) : (
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-500/50 flex items-center gap-1">
                <Eye className="w-3.5 h-3.5" /> Đang Hiển Thị Công Khai
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {onOpenEditNovel && (
              <button
                onClick={() => onOpenEditNovel(novel)}
                className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold flex items-center gap-1.5 cursor-pointer transition-colors shadow-md shadow-blue-600/30"
                title="Sửa thông tin truyện, ảnh bìa, văn án và quản lý các chương"
              >
                <Edit3 className="w-3.5 h-3.5" /> Chỉnh Sửa Truyện &amp; Chương
              </button>
            )}

            {onToggleHideNovel && (
              <button
                onClick={() => onToggleHideNovel(novel.id)}
                className={`px-3.5 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 cursor-pointer transition-colors ${
                  novel.isHidden
                    ? 'bg-purple-600 hover:bg-purple-500 text-white shadow-md'
                    : 'bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700'
                }`}
              >
                {novel.isHidden ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                {novel.isHidden ? 'Bỏ Ẩn Truyện' : 'Ẩn Truyện Khỏi Độc Giả'}
              </button>
            )}

            {onDeleteNovel && (
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="px-3.5 py-1.5 rounded-lg bg-rose-100 dark:bg-rose-950/70 hover:bg-rose-600 text-rose-700 hover:text-white dark:text-rose-300 border border-rose-300 dark:border-rose-500/50 font-semibold flex items-center gap-1.5 cursor-pointer transition-colors shadow-xs"
              >
                <Trash2 className="w-3.5 h-3.5" /> Xóa Vĩnh Viễn Truyện
              </button>
            )}
          </div>
        </div>
      )}

      {/* Novel Hero Banner */}
      <div className="bg-white dark:bg-[#1c1a2c] border border-[#ebdcd5] dark:border-pink-500/25 rounded-2xl p-6 sm:p-8 shadow-sm dark:shadow-xl dark:shadow-black/60 mb-10 transition-colors">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Cover image */}
          <div className="w-48 sm:w-56 mx-auto md:mx-0 flex-shrink-0">
            <div className="relative aspect-[2/3] rounded-xl overflow-hidden shadow-2xl border-2 border-pink-200 dark:border-blue-500/40 bg-[#120d20]">
              <img
                src={novel.coverImage}
                alt={novel.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2 left-2 bg-emerald-600 text-white text-[10px] font-extrabold px-2 py-0.5 rounded shadow">
                {novel.status}
              </div>
              {novel.hasAudio && (
                <div className="absolute top-2 right-2 bg-blue-600 text-white text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1 shadow">
                  <Headphones className="w-2.5 h-2.5" /> AUDIO TTS
                </div>
              )}
            </div>
          </div>

          {/* Metadata & Synopsis */}
          <div className="flex-1 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                {(novel.mainCategory === 'truyen-sang-tac' || novel.isOriginal) && (
                  <span className="bg-indigo-100 dark:bg-indigo-600/30 text-indigo-700 dark:text-indigo-300 text-xs font-bold px-2.5 py-0.5 rounded-full border border-indigo-200 dark:border-indigo-500/40 flex items-center gap-1">
                    ✍️ Truyện Sáng Tác Chính Chủ
                  </span>
                )}
                {novel.isExclusive && (
                  <span className="bg-amber-100 dark:bg-amber-500/25 text-amber-800 dark:text-amber-300 text-xs font-bold px-2.5 py-0.5 rounded-full border border-amber-200 dark:border-amber-500/40 flex items-center gap-1">
                    ⭐ Phát Hành Độc Quyền
                  </span>
                )}
                {isFullBookUnlocked && (
                  <span className="bg-emerald-100 dark:bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 text-xs font-bold px-2.5 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-500/30 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" /> Đã Mở Khóa Trọn Bộ VIP
                  </span>
                )}
              </div>

              <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#231c26] dark:text-white leading-tight">
                {novel.title}
              </h1>

              {/* Author & Stats */}
              <div className="flex flex-wrap items-center gap-y-2 gap-x-4 mt-3 text-xs sm:text-sm text-slate-300">
                {novel.publisherRoles?.includes('author') && novel.publisherRoles?.includes('editor') ? (
                  <button
                    onClick={() => onOpenAuthorShowcase && onOpenAuthorShowcase(novel.author, 'author')}
                    className="bg-blue-100 hover:bg-blue-200 dark:bg-blue-950/60 dark:hover:bg-blue-900/60 border border-blue-300 dark:border-blue-500/30 px-2.5 py-1 rounded-lg cursor-pointer transition-all inline-flex items-center gap-1.5 shadow-xs"
                    title="Xem hồ sơ và các tác phẩm của Tác giả & Editor này"
                  >
                    <span className="text-blue-700 dark:text-sky-300 font-bold">✍️ Tác giả &amp; Editor:</span>
                    <span className="text-slate-900 dark:text-white font-semibold underline decoration-dotted">{novel.author}</span>
                  </button>
                ) : (
                  <>
                    <div className="flex items-center gap-1">
                      <span className="text-slate-500 dark:text-slate-400">Tác giả:</span>
                      <button
                        onClick={() => onOpenAuthorShowcase && onOpenAuthorShowcase(novel.author, 'author')}
                        className="text-pink-600 dark:text-sky-300 hover:underline font-semibold cursor-pointer px-1 py-0.5 rounded hover:bg-pink-50 dark:hover:bg-slate-800 transition-colors"
                        title="Xem hồ sơ và các tác phẩm của tác giả này"
                      >
                        {novel.author}
                      </button>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-slate-500 dark:text-slate-400">Editor/Dịch:</span>
                      <button
                        onClick={() => onOpenAuthorShowcase && onOpenAuthorShowcase(novel.editor || novel.translator || 'Đạo Tâm Team', 'editor')}
                        className="text-indigo-600 dark:text-indigo-300 hover:underline font-semibold cursor-pointer px-1 py-0.5 rounded hover:bg-indigo-50 dark:hover:bg-slate-800 transition-colors"
                        title="Xem hồ sơ và các tác phẩm của editor này"
                      >
                        {novel.editor || novel.translator || 'Đạo Tâm Team'}
                      </button>
                    </div>
                  </>
                )}
                <div>
                  <span className="text-slate-500 dark:text-slate-400">Tình trạng:</span>{' '}
                  <span className="text-emerald-600 dark:text-emerald-400 font-semibold">{novel.status}</span>
                </div>
                <div className="flex items-center gap-1 text-sky-400">
                  <Star className="w-3.5 h-3.5 fill-sky-400" />
                  <span>{novel.rating} / 5.0</span>
                </div>
                <div className="flex items-center gap-1 text-slate-400">
                  <Eye className="w-3.5 h-3.5 text-sky-400" />
                  <span>{(novel.views / 1000).toFixed(1)}k lượt đọc</span>
                </div>
                <div className="flex items-center gap-1.5 text-pink-300 font-bold bg-pink-950/60 border border-pink-500/30 px-2.5 py-0.5 rounded-full">
                  <span>🌸</span>
                  <span>{(novel.flowerCount || 0).toLocaleString()} Hoa Đề Cử</span>
                </div>
              </div>

              {/* Pricing Tag */}
              <div className="mt-3 flex items-center gap-3 text-xs">
                <span className="text-slate-400">Trọn bộ VIP:</span>
                <span className="line-through text-slate-500">{novel.fullBookPriceXu} Xu</span>
                <span className="font-bold text-sky-300 flex items-center gap-1">
                  <Coins className="w-3.5 h-3.5 text-sky-400" />
                  {novel.fullBookDiscountPriceXu} Xu
                  <span className="text-[10px] bg-blue-500/20 text-sky-300 px-1.5 py-0.2 rounded border border-blue-500/30">
                    Giảm giá combo
                  </span>
                </span>
              </div>

              {/* Genres / Tags */}
              <div className="flex flex-wrap gap-2 mt-4">
                {novel.categories.map((cat) => (
                  <span
                    key={cat}
                    className="px-2.5 py-1 rounded-md text-xs font-medium bg-blue-950/60 border border-blue-500/30 text-sky-300"
                  >
                    #{cat}
                  </span>
                ))}
              </div>

              {/* Synopsis */}
              <div className="mt-5 text-slate-300 text-sm leading-relaxed border-t border-slate-800/80 pt-4">
                <h4 className="text-xs uppercase tracking-wider text-sky-400/90 font-semibold mb-2">
                  Giới thiệu tác phẩm:
                </h4>
                <p className="whitespace-pre-line text-slate-300/90 leading-relaxed font-sans">
                  {novel.description}
                </p>
              </div>
            </div>

            {/* Action Bar */}
            <div className="mt-6 pt-5 border-t border-slate-800/80 flex flex-wrap gap-3">
              {/* Read button */}
              {savedProgress ? (
                <button
                  onClick={() => {
                    const chapterToRead =
                      novel.chapters.find((c) => c.number === savedProgress.chapterNumber) ||
                      novel.chapters[0];
                    onSelectChapter(novel, chapterToRead);
                  }}
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-blue-600/30 transition-all hover:scale-102 cursor-pointer"
                >
                  <BookOpen className="w-4 h-4" />
                  Đọc tiếp: Chương {savedProgress.chapterNumber} ({savedProgress.scrollPercentage}%)
                </button>
              ) : (
                <button
                  onClick={() => onSelectChapter(novel, novel.chapters[0])}
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-blue-600/30 transition-all hover:scale-102 cursor-pointer"
                >
                  <BookOpen className="w-4 h-4" />
                  Đọc từ đầu (Chương 1)
                </button>
              )}

              {/* Nghe Audio Edge TTS Button (Hoài My & Nam Minh) */}
              <button
                onClick={() => {
                  const targetChapter = savedProgress
                    ? novel.chapters.find((c) => c.number === savedProgress.chapterNumber) || novel.chapters[0]
                    : novel.chapters[0];
                  onSelectChapter(novel, targetChapter);
                }}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-700 via-blue-700 to-sky-700 hover:from-indigo-600 hover:to-sky-600 text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition-all hover:scale-102 cursor-pointer"
                title="Bật tính năng đọc truyện tự động bằng giọng Edge TTS Nữ Hoài My & Nam Nam Minh"
              >
                <Headphones className="w-4 h-4 text-sky-300 animate-pulse" />
                <span>Nghe Audio (👩 Hoài My • 👨 Nam Minh)</span>
              </button>

              {/* Buy Combo Full Book */}
              {!isFullBookUnlocked && (
                <button
                  onClick={() => onOpenVipPurchase(novel, novel.chapters[3] || novel.chapters[0])}
                  className="px-5 py-2.5 rounded-xl bg-blue-950/60 hover:bg-blue-900/60 text-sky-300 border border-blue-500/40 font-bold text-sm flex items-center gap-2 transition-all cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4 text-sky-400" />
                  Mua Trọn Bộ (Tự động trừ Xu lẻ)
                </button>
              )}

              {/* Nominate / Give Flowers Button */}
              {onOpenNominate && (
                <button
                  onClick={() => onOpenNominate(novel)}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white font-bold text-sm flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-pink-600/30 hover:scale-102"
                >
                  <span className="text-base">🌸</span>
                  Đề Cử Truyện ({novel.flowerCount || 0} Hoa)
                </button>
              )}

              {/* Bookmark Button */}
              <button
                onClick={() => onToggleBookmark(novel.id)}
                className={`px-4 py-2.5 rounded-xl border text-sm font-medium flex items-center gap-2 transition-all cursor-pointer ${
                  isBookmarked
                    ? 'bg-blue-600/30 border-blue-400 text-white'
                    : 'bg-[#090d16] border-slate-800 text-slate-300 hover:border-blue-500/40 hover:text-sky-300'
                }`}
              >
                {isBookmarked ? (
                  <>
                    <BookmarkCheck className="w-4 h-4 text-sky-400" />
                    Đã lưu tủ sách
                  </>
                ) : (
                  <>
                    <Bookmark className="w-4 h-4" />
                    Thêm vào tủ sách
                  </>
                )}
              </button>

              {/* Nút Báo Cáo Vi Phạm (Bản quyền, 18+, Reup, Bôi nhọ Việt Nam, Khác) */}
              {onOpenReport && (
                <button
                  onClick={() => onOpenReport(novel)}
                  className="px-4 py-2.5 rounded-xl border border-rose-500/40 hover:border-rose-500 bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 dark:text-rose-400 font-semibold text-xs sm:text-sm flex items-center gap-1.5 transition-all cursor-pointer shadow-sm hover:scale-102"
                  title="Báo cáo vi phạm (Truyện bản quyền, 18+, reup, bôi nhọ Việt Nam, lý do khác)"
                >
                  <Flag className="w-4 h-4 text-rose-500" />
                  <span>Báo Cáo Vi Phạm</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* MỤC LỤC CHƯƠNG CHI TIẾT */}
      <section className="bg-white dark:bg-[#1c1a2c] border border-[#ebdcd5] dark:border-slate-800 rounded-2xl p-6 shadow-sm dark:shadow-xl transition-colors">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#ebdcd5] dark:border-slate-800/80">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-pink-100 dark:bg-blue-600/20 border border-pink-300 dark:border-blue-500/30 flex items-center justify-center text-pink-600 dark:text-sky-400">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-[#231c26] dark:text-white">
                Mục Lục Chương Chi Tiết
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Tổng cộng {novel.chapters.length} chương đã phát hành
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            <div className="relative">
              <input
                type="text"
                value={searchChapter}
                onChange={(e) => setSearchChapter(e.target.value)}
                placeholder="Tìm số hoặc tên chương..."
                className="bg-[#090d16] border border-slate-800 focus:border-blue-500 text-xs text-white rounded-lg py-1.5 pl-3 pr-8 w-48 sm:w-56 focus:outline-none"
              />
              <Search className="w-3.5 h-3.5 text-slate-500 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            <button
              onClick={() => setIsAscending(!isAscending)}
              className="px-3 py-1.5 rounded-lg bg-[#090d16] border border-slate-800 hover:border-blue-500/40 text-xs text-slate-300 hover:text-white flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <ArrowDownUp className="w-3.5 h-3.5" />
              {isAscending ? 'Cũ nhất trước' : 'Mới nhất trước'}
            </button>
          </div>
        </div>

        {/* Range pagination buttons */}
        {!searchChapter && totalChunks > 1 && (
          <div className="flex items-center gap-1.5 py-4 overflow-x-auto text-xs border-b border-slate-800/60 scrollbar-none">
            <span className="text-slate-400 text-[11px] mr-1 flex-shrink-0">
              Khoảng chương:
            </span>
            {Array.from({ length: totalChunks }, (_, i) => {
              const start = i * CHUNK_SIZE + 1;
              const end = Math.min((i + 1) * CHUNK_SIZE, novel.chapters.length);
              return (
                <button
                  key={i}
                  onClick={() => setSelectedRange(i)}
                  className={`px-3 py-1 rounded-md text-xs font-medium transition-all whitespace-nowrap cursor-pointer ${
                    selectedRange === i
                      ? 'bg-blue-600 text-white font-bold shadow'
                      : 'bg-[#090d16] text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
                  }`}
                >
                  {start} - {end}
                </button>
              );
            })}
          </div>
        )}

        {/* Chapter List Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 pt-5 max-h-[640px] overflow-y-auto pr-1">
          {filteredChapters.map((chapter) => {
            const isCurrentRead = savedProgress?.chapterNumber === chapter.number;
            const isAlreadyRead = savedProgress && chapter.number < savedProgress.chapterNumber;
            const isUnlocked =
              !chapter.isVip ||
              isFullBookUnlocked ||
              unlockedChapterIds.includes(chapter.id);

            return (
              <div
                key={chapter.id}
                onClick={() => onSelectChapter(novel, chapter)}
                className={`group p-3 rounded-xl border transition-all flex items-center justify-between gap-3 cursor-pointer ${
                  isCurrentRead
                    ? 'bg-pink-100 dark:bg-blue-950/40 border-pink-500 dark:border-blue-500/80 shadow-md shadow-pink-500/10'
                    : isAlreadyRead
                    ? 'bg-slate-50 dark:bg-[#090d16]/70 border-[#ebdcd5] dark:border-slate-800/60 hover:border-pink-300 dark:hover:border-slate-700 opacity-85'
                    : 'bg-white dark:bg-[#090d16] border-[#ebdcd5] dark:border-slate-800/80 hover:border-pink-400 dark:hover:border-blue-500/50 hover:bg-pink-50/50 dark:hover:bg-[#131b2e]'
                }`}
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-pink-600 dark:text-sky-400 group-hover:text-pink-700 dark:group-hover:text-sky-300">
                      Chương {chapter.number}
                    </span>
                    {chapter.isVip && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded flex items-center gap-0.5 font-bold ${
                        isUnlocked
                          ? 'bg-emerald-100 dark:bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-500/30'
                          : 'bg-rose-100 dark:bg-rose-500/20 text-rose-800 dark:text-rose-300 border border-rose-300 dark:border-rose-500/30'
                      }`}>
                        {isUnlocked ? <Unlock className="w-2.5 h-2.5" /> : <Lock className="w-2.5 h-2.5" />}
                        {isUnlocked ? 'Đã mở' : `VIP • ${chapter.priceXu} Xu`}
                      </span>
                    )}
                    {isCurrentRead && (
                      <span className="bg-pink-600 dark:bg-blue-600 text-white text-[10px] font-extrabold px-1.5 py-0.2 rounded">
                        Đang đọc
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-700 dark:text-slate-300 group-hover:text-pink-600 dark:group-hover:text-white truncate mt-1">
                    {chapter.title.replace(/^Chương \d+:\s*/, '')}
                  </div>
                </div>

                <div className="text-slate-500 group-hover:text-sky-400 text-xs">
                  {isAlreadyRead ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-slate-500" />
                  ) : (
                    <span className="opacity-0 group-hover:opacity-100 transition-opacity">
                      Đọc &rarr;
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Mục Bình Luận Cho Truyện */}
      <CommentsSection novelId={novel.id} user={user} />

      {/* Modal Xác Nhận Xóa Vĩnh Viễn Truyện */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0e1424] border border-rose-500/50 rounded-2xl p-6 shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center border border-rose-500/40 mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="text-base font-bold text-white">
                Xác Nhận Xóa Vĩnh Viễn Truyện?
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Bạn có chắc chắn muốn xóa tác phẩm <strong className="text-rose-400">"{novel.title}"</strong> không?
              </p>
              <div className="p-3 bg-rose-950/40 border border-rose-500/30 rounded-xl text-[11px] text-rose-300 text-left">
                ⚠️ <strong>Cảnh báo:</strong> Thao tác này sẽ xóa vĩnh viễn toàn bộ chương của tác phẩm khỏi Firestore và ứng dụng. Không thể khôi phục sau khi xóa.
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                Hủy Bỏ
              </button>
              <button
                onClick={() => {
                  if (onDeleteNovel) {
                    onDeleteNovel(novel.id);
                  }
                  setShowDeleteConfirm(false);
                  onBack();
                }}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-lg shadow-rose-600/30 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                Xóa Vĩnh Viễn
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
