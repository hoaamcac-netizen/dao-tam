import React from 'react';

interface DaoTamLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

export const DaoTamLogo: React.FC<DaoTamLogoProps> = ({
  className = '',
  size = 'md',
  showText = true,
}) => {
  const iconDimensions = {
    sm: 'w-10 h-10',
    md: 'w-14 h-14 sm:w-16 sm:h-16',
    lg: 'w-18 h-18 sm:w-20 sm:h-20',
    xl: 'w-24 h-24 sm:w-28 sm:h-28',
  }[size];

  const titleSizes = {
    sm: 'text-lg sm:text-xl',
    md: 'text-2xl sm:text-3xl',
    lg: 'text-3xl sm:text-4xl',
    xl: 'text-4xl sm:text-5xl',
  }[size];

  const subSizes = {
    sm: 'text-[9px] sm:text-[10px]',
    md: 'text-[11px] sm:text-[12px]',
    lg: 'text-xs sm:text-sm',
    xl: 'text-sm sm:text-base',
  }[size];

  return (
    <div className={`flex items-center gap-3 sm:gap-4 group select-none cursor-pointer ${className}`}>
      {/* Biểu tượng Thánh Ấn Đạo Tâm - Kích Thước Lớn, Gradient Sắc Nét, Bóng Đổ Phát Sáng & Phóng To Mượt Mà */}
      <div 
        className={`relative ${iconDimensions} flex-shrink-0 transition-transform duration-300 ease-out group-hover:scale-110 active:scale-95`}
      >
        {/* Lớp Hào Quang Tỏa Sáng Phát Quang Đa Tầng (Multi-layered Radiant Glow) */}
        <div className="absolute -inset-1.5 rounded-3xl bg-gradient-to-tr from-sky-400 via-indigo-500 via-pink-500 to-amber-400 opacity-85 blur-lg group-hover:opacity-100 group-hover:blur-xl transition-all duration-300 animate-pulse" />

        {/* Lớp Viền Đổ Bóng Đậm Nét (Drop-shadow Luminous Aura) */}
        <div className="absolute -inset-0.5 rounded-2xl bg-gradient-to-r from-cyan-400 via-blue-500 to-rose-500 opacity-90 blur-sm group-hover:blur-md transition-all duration-300" />
        
        {/* Khung Hộp Huy Hiệu Trung Tâm Viền Bạc Trắng Tinh Khiết & Bóng Đổ Neon */}
        <div className="relative w-full h-full rounded-2xl bg-gradient-to-b from-[#0f172a] via-[#090d16] to-[#020617] border-2 border-white ring-2 ring-sky-400/80 shadow-[0_0_25px_rgba(56,189,248,0.7)] group-hover:shadow-[0_0_35px_rgba(244,114,182,0.85)] p-2 flex items-center justify-center overflow-hidden transition-all duration-300">
          
          {/* Tia Sáng Lướt Qua (Shimmer Sheen Effect khi hover) */}
          <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/30 to-transparent pointer-events-none" />

          <svg
            viewBox="0 0 100 100"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full filter drop-shadow-[0_0_12px_rgba(56,189,248,0.95)] group-hover:drop-shadow-[0_0_16px_rgba(244,114,182,1)] transition-all duration-300"
          >
            {/* Vòng Bát Quái / Thái Cực Vũ Trụ Xoay Nhẹ (Outer Celestial Ring) */}
            <circle
              cx="50"
              cy="50"
              r="45"
              stroke="url(#dao_gold_sky_v2)"
              strokeWidth="2.8"
              strokeDasharray="7 3"
              className="animate-[spin_24s_linear_infinite]"
            />

            {/* Vòng Phụ Tương Hỗ Chống Xoay (Inner Counter-rotating Circle) */}
            <circle
              cx="50"
              cy="50"
              r="38"
              stroke="url(#dao_cyan_royal_v2)"
              strokeWidth="1.8"
              strokeDasharray="4 2"
              className="animate-[spin_18s_linear_infinite_reverse]"
            />

            {/* Trận Đồ Tam Giác Thánh Quang Đan Xen (Sacred Double Hexagram) */}
            <polygon
              points="50,13 83,71 17,71"
              stroke="url(#dao_sky_cyan_v2)"
              strokeWidth="1.8"
              strokeOpacity="0.85"
            />
            <polygon
              points="50,87 17,29 83,29"
              stroke="url(#dao_pink_purple_v2)"
              strokeWidth="1.8"
              strokeOpacity="0.85"
            />

            {/* Thanh Kiếm Khai Tâm Trượng Nghĩa (Daoist Sword of Wisdom) */}
            <path
              d="M50 14 L55 38 L57 64 L50 86 L43 64 L45 38 Z"
              fill="url(#dao_sword_blade_v2)"
              filter="drop-shadow(0 0 6px #38bdf8)"
            />
            
            {/* Trái Tim Đạo Tâm Bất Diệt (Spiritual Sacred Heart Flame) */}
            <path
              d="M50 33 C40 21 27 32 31 46 C34 59 50 71 50 71 C50 71 66 59 69 46 C73 32 60 21 50 33 Z"
              fill="url(#dao_heart_flame_v2)"
              stroke="#ffffff"
              strokeWidth="1.5"
              filter="drop-shadow(0 0 5px rgba(236,72,153,0.8))"
            />

            {/* Ngôi Sao Kim Cương Tinh Vân Trung Tâm (Center Diamond Sparkle) */}
            <circle cx="50" cy="46" r="4.5" fill="#ffffff" />
            <circle cx="50" cy="46" r="9" fill="#38bdf8" fillOpacity="0.45" />
            <polygon points="50,37 53,46 50,55 47,46" fill="#ffffff" />
            <polygon points="41,46 50,49 59,46 50,43" fill="#ffffff" />

            {/* Bảng Dải Màu Sắc Nét (Ultra-Vivid Color Gradients) */}
            <defs>
              <linearGradient id="dao_gold_sky_v2" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#00f0ff" />
                <stop offset="35%" stopColor="#6366f1" />
                <stop offset="70%" stopColor="#ec4899" />
                <stop offset="100%" stopColor="#fbbf24" />
              </linearGradient>
              <linearGradient id="dao_cyan_royal_v2" x1="100" y1="0" x2="0" y2="100" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#38bdf8" />
                <stop offset="100%" stopColor="#a855f7" />
              </linearGradient>
              <linearGradient id="dao_sky_cyan_v2" x1="17" y1="13" x2="83" y2="71" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#00f0ff" />
                <stop offset="100%" stopColor="#2563eb" />
              </linearGradient>
              <linearGradient id="dao_pink_purple_v2" x1="17" y1="87" x2="83" y2="29" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#f43f5e" />
                <stop offset="100%" stopColor="#8b5cf6" />
              </linearGradient>
              <linearGradient id="dao_sword_blade_v2" x1="50" y1="14" x2="50" y2="86" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="30%" stopColor="#cffafe" />
                <stop offset="70%" stopColor="#38bdf8" />
                <stop offset="100%" stopColor="#1d4ed8" />
              </linearGradient>
              <linearGradient id="dao_heart_flame_v2" x1="31" y1="21" x2="69" y2="71" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#f472b6" />
                <stop offset="40%" stopColor="#ec4899" />
                <stop offset="100%" stopColor="#4338ca" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>

      {/* Typography Nhãn Hiệu Đạo Tâm - Sắc Nét, Lộng Lẫy & Nổi Bật Trên Mọi Nền */}
      {showText && (
        <div className="flex flex-col justify-center">
          <div className="flex items-center">
            <span
              className={`font-black tracking-widest ${titleSizes} font-serif leading-tight
                bg-gradient-to-r from-sky-400 via-indigo-300 to-pink-400 
                light:from-blue-700 light:via-indigo-800 light:to-pink-600
                bg-clip-text text-transparent
                drop-shadow-[0_2px_12px_rgba(56,189,248,0.7)]
                light:drop-shadow-[0_1px_4px_rgba(0,0,0,0.15)]
                transition-all duration-300 group-hover:brightness-125 group-hover:scale-102`}
            >
              ĐẠO TÂM
            </span>
          </div>
          
          <div className="flex items-center gap-1.5 mt-0.5 sm:mt-1">
            <span
              className={`font-extrabold tracking-widest uppercase ${subSizes} leading-none
                text-sky-300/90 light:text-slate-700 flex items-center gap-1 drop-shadow-sm`}
            >
              <span className="text-amber-400 animate-pulse">✦</span>
              <span>Nền Tảng Đọc Truyện &amp; Audio</span>
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
