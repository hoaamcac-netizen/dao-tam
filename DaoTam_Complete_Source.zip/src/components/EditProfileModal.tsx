import React, { useState, useRef } from 'react';
import { UserProfile } from '../types';
import { 
  X, 
  User, 
  Camera, 
  Upload, 
  Check, 
  Sparkles, 
  Link as LinkIcon, 
  Image as ImageIcon,
  ShieldCheck,
  Building2,
  Phone,
  Globe,
  AlertCircle
} from 'lucide-react';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onSaveProfile: (
    name: string, 
    avatarUrl: string,
    extra?: {
      bio?: string;
      facebookUrl?: string;
      phoneNumber?: string;
      bankInfo?: {
        bankName: string;
        accountNumber: string;
        accountHolder: string;
      };
    }
  ) => void;
}

const COMMON_BANKS = [
  'MB Bank (Ngân Hàng Quân Đội)',
  'Vietcombank',
  'Techcombank',
  'BIDV',
  'VietinBank',
  'ACB',
  'TPBank',
  'VPBank',
  'Sacombank',
  'Agribank',
  'Khác',
];

export const PRESET_AVATARS = [
  {
    category: 'Kiếm Hiệp & Tiên Hiệp',
    avatars: [
      { name: 'Di Lăng Lão Tổ', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80' },
      { name: 'Bạch Y Đạo Nhân', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80' },
      { name: 'Hắc Miêu Gia Gia', url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80' },
      { name: 'Tiên Tôn Tuyết Lạc', url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=300&q=80' },
    ],
  },
  {
    category: 'Hiện Đại & Cute',
    avatars: [
      { name: 'Thanh Trúc', url: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=300&q=80' },
      { name: 'Tiểu Mật Đào', url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80' },
      { name: 'Thiếu Niên Thư Sinh', url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80' },
      { name: 'Hồ Ly Tiểu Thư', url: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=300&q=80' },
    ],
  },
  {
    category: 'Cổ Trang & Huyền Huyễn',
    avatars: [
      { name: 'Ngọc Diện Lang Quân', url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80' },
      { name: 'Mộng Đàm Các Chủ', url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80' },
      { name: 'Cầm Sư Phong Nhã', url: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=300&q=80' },
      { name: 'Tiểu Yến Tử', url: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80' },
    ],
  },
];

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  isOpen,
  onClose,
  user,
  onSaveProfile,
}) => {
  const isCreator = user.role === 'author' || user.role === 'admin';

  const [displayName, setDisplayName] = useState(user.displayName);
  const [avatarUrl, setAvatarUrl] = useState(user.avatarUrl);
  const [bio, setBio] = useState(user.bio || '');
  const [facebookUrl, setFacebookUrl] = useState(user.facebookUrl || '');
  const [phoneNumber, setPhoneNumber] = useState(user.phoneNumber || '');
  const [bankName, setBankName] = useState(user.bankInfo?.bankName || 'MB Bank (Ngân Hàng Quân Đội)');
  const [accountNumber, setAccountNumber] = useState(user.bankInfo?.accountNumber || '');
  const [accountHolder, setAccountHolder] = useState(user.bankInfo?.accountHolder || '');

  const [urlInput, setUrlInput] = useState('');
  const [showUrlField, setShowUrlField] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Vui lòng chọn tệp hình ảnh hợp lệ (PNG, JPG, WEBP, GIF).');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('Kích thước ảnh tối đa là 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setAvatarUrl(event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleApplyUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;
    setAvatarUrl(urlInput.trim());
    setUrlInput('');
    setShowUrlField(false);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    const trimmedName = displayName.trim();
    if (!trimmedName) {
      setValidationError('Vui lòng nhập tên biệt danh hoặc bút danh.');
      return;
    }

    // Yêu cầu bắt buộc đối với mục đại diện cá nhân của Tác giả & Editor:
    // Facebook/Fanpage, SĐT, Tài khoản ngân hàng để nhận tiền
    if (isCreator) {
      if (!facebookUrl.trim()) {
        setValidationError('Mục đại diện cá nhân bắt buộc: Tác giả/Editor phải bổ sung link Facebook cá nhân hoặc Fanpage.');
        return;
      }
      if (!phoneNumber.trim()) {
        setValidationError('Mục đại diện cá nhân bắt buộc: Tác giả/Editor phải bổ sung Số điện thoại (SĐT) liên hệ.');
        return;
      }
      if (!bankName.trim()) {
        setValidationError('Mục đại diện cá nhân bắt buộc: Vui lòng chọn Tên ngân hàng nhận tiền nhuận bút.');
        return;
      }
      if (!accountNumber.trim()) {
        setValidationError('Mục đại diện cá nhân bắt buộc: Vui lòng nhập Số tài khoản ngân hàng (STK).');
        return;
      }
      if (!accountHolder.trim()) {
        setValidationError('Mục đại diện cá nhân bắt buộc: Vui lòng nhập Họ tên chủ tài khoản ngân hàng.');
        return;
      }
    }

    onSaveProfile(trimmedName, avatarUrl, {
      bio: bio.trim(),
      facebookUrl: facebookUrl.trim(),
      phoneNumber: phoneNumber.trim(),
      bankInfo: {
        bankName: bankName.trim(),
        accountNumber: accountNumber.trim(),
        accountHolder: accountHolder.trim().toUpperCase(),
      },
    });

    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
      onClose();
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 text-slate-200">
      <div className="w-full max-w-xl bg-[#090d16] border border-blue-500/40 rounded-2xl p-6 shadow-2xl relative max-h-[92vh] flex flex-col animate-in zoom-in-95 duration-200">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title */}
        <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
          <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-sky-400">
            <Camera className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-serif text-lg font-bold text-white flex items-center gap-2">
              Hồ Sơ Cá Nhân &amp; Đại Diện Tác Giả
              {isCreator && (
                <span className="text-[10px] bg-indigo-600/30 text-indigo-300 font-bold px-2 py-0.5 rounded-full border border-indigo-500/40">
                  ✍️ Tác Giả / Editor
                </span>
              )}
            </h2>
            <p className="text-xs text-slate-400">
              {isCreator 
                ? 'Bắt buộc cập nhật Facebook/Fanpage, SĐT và STK ngân hàng để nhận nhuận bút VIP (tối thiểu 100 Xu rút)' 
                : 'Tùy chỉnh biệt danh độc giả, avatar và thông tin cá nhân'}
            </p>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="flex-1 overflow-y-auto py-4 space-y-5 pr-1">
          
          {validationError && (
            <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
              <span>{validationError}</span>
            </div>
          )}

          {/* Avatar Preview & Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-4 p-4 rounded-xl bg-[#0e1424] border border-slate-800">
            <div className="relative group flex-shrink-0">
              <img
                src={avatarUrl}
                alt="Avatar Preview"
                className="w-20 h-20 rounded-full object-cover border-3 border-sky-400 shadow-lg shadow-sky-500/20"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute inset-0 bg-black/60 rounded-full flex flex-col items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                title="Tải ảnh mới"
              >
                <Camera className="w-5 h-5 text-sky-300" />
                <span className="text-[10px] mt-0.5 font-bold">Đổi ảnh</span>
              </button>
            </div>

            <div className="flex-1 space-y-2 text-center sm:text-left">
              <div className="font-bold text-sm text-white">Ảnh Đại Diện Hiện Tại</div>
              <p className="text-xs text-slate-400">
                Tải ảnh từ máy tính / điện thoại hoặc chọn nhanh bộ sưu tập bên dưới
              </p>

              <div className="flex items-center justify-center sm:justify-start gap-2 pt-1 flex-wrap">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept="image/*"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow transition-all hover:scale-102"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Tải ảnh từ máy</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowUrlField(!showUrlField)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-300 text-xs font-medium flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <LinkIcon className="w-3.5 h-3.5" />
                  <span>Dán link URL</span>
                </button>
              </div>
            </div>
          </div>

          {/* Dán link URL nếu mở */}
          {showUrlField && (
            <div className="p-3 rounded-xl bg-black/40 border border-slate-700 space-y-2">
              <label className="text-xs font-semibold text-slate-300 block">
                Dán đường dẫn ảnh trực tiếp (Image URL):
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="url"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  placeholder="https://example.com/avatar.jpg"
                  className="flex-1 bg-black border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-sky-500"
                />
                <button
                  type="button"
                  onClick={handleApplyUrl}
                  className="px-3 py-1.5 rounded-lg bg-sky-600 text-white font-bold text-xs cursor-pointer hover:bg-sky-500"
                >
                  Áp dụng
                </button>
              </div>
            </div>
          )}

          {/* Display Name Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
              <span>{isCreator ? 'Bút Danh Tác Giả / Editor *:' : 'Biệt Danh Độc Giả *:'}</span>
              <span className="text-[11px] text-slate-500 font-normal">
                {displayName.length}/40 ký tự
              </span>
            </label>
            <div className="relative">
              <input
                type="text"
                maxLength={40}
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Nhập tên biệt danh của bạn..."
                className="w-full bg-[#0e1424] border border-slate-700 focus:border-sky-500 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none transition-all shadow-inner pl-10"
                required
              />
              <User className="w-4 h-4 text-sky-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          {/* Tiểu sử / Bio */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
              <span>Tiểu sử / Lời giới thiệu cá nhân:</span>
              <span className="text-[11px] text-slate-500 font-normal">
                {bio.length}/300 ký tự
              </span>
            </label>
            <textarea
              rows={3}
              maxLength={300}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Chia sẻ đôi dòng về bản thân, sở thích đọc truyện, fanpage..."
              className="w-full bg-[#0e1424] border border-slate-700 focus:border-sky-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none transition-all shadow-inner resize-none"
            />
          </div>

          {/* MỤC BẮT BUỘC ĐẠI DIỆN CÁ NHÂN TÁC GIẢ & EDITOR */}
          <div className={`p-4 rounded-xl border space-y-3.5 ${
            isCreator 
              ? 'bg-[#0f1424] border-indigo-500/40 shadow-md' 
              : 'bg-[#0e1424] border-slate-800'
          }`}>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-indigo-400" />
                <h4 className="font-bold text-xs text-white">
                  Mục Đại Diện Cá Nhân &amp; Tài Khoản Nhận Nhuận Bút
                  {isCreator && <span className="text-rose-400 ml-1">*(Bắt buộc)</span>}
                </h4>
              </div>
              <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                Rút tối thiểu: 100 Xu
              </span>
            </div>

            {isCreator && (
              <div className="p-2.5 rounded-lg bg-indigo-950/40 border border-indigo-500/30 text-[11px] text-indigo-300 leading-relaxed">
                💡 <strong>Quy định đại diện tác giả/editor:</strong> Để đảm bảo tính minh bạch bản quyền và chi trả doanh thu nhuận bút, các tác giả/editor bắt buộc phải bổ sung <strong>Facebook hoặc Fanpage</strong>, <strong>Số điện thoại</strong> và <strong>Tài khoản ngân hàng</strong>. Hạn mức rút tối thiểu là <strong>100 Xu</strong>.
              </div>
            )}

            {/* Facebook / Fanpage */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center justify-between">
                <span>Link Facebook cá nhân hoặc Fanpage {isCreator && <span className="text-rose-400">*</span>}:</span>
                <span className="text-[10px] text-slate-400">Xác thực đại diện</span>
              </label>
              <div className="relative">
                <input
                  type="url"
                  value={facebookUrl}
                  onChange={(e) => setFacebookUrl(e.target.value)}
                  placeholder="https://facebook.com/trang.ca.nhan hoặc https://fb.com/fanpage"
                  className="w-full bg-black/60 border border-slate-700 focus:border-indigo-400 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none pl-9"
                  required={isCreator}
                />
                <Globe className="w-4 h-4 text-indigo-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            {/* Số điện thoại */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center justify-between">
                <span>Số điện thoại (SĐT) liên hệ {isCreator && <span className="text-rose-400">*</span>}:</span>
                <span className="text-[10px] text-slate-400">Hỗ trợ đối soát &amp; bảo mật</span>
              </label>
              <div className="relative">
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="0912345678"
                  className="w-full bg-black/60 border border-slate-700 focus:border-indigo-400 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none pl-9"
                  required={isCreator}
                />
                <Phone className="w-4 h-4 text-indigo-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            {/* Ngân hàng nhận tiền */}
            <div className="pt-2 border-t border-slate-800 space-y-2.5">
              <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                <Building2 className="w-3.5 h-3.5" />
                <span>Tài Khoản Ngân Hàng Nhận Tiền (Tối thiểu 100 Xu):</span>
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Tên ngân hàng {isCreator && '*'}:</label>
                <select
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/60 border border-slate-700 text-xs text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
                  required={isCreator}
                >
                  <option value="">-- Chọn ngân hàng --</option>
                  {COMMON_BANKS.map((b) => (
                    <option key={b} value={b}>{b}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Số tài khoản (STK) {isCreator && '*'}:</label>
                  <input
                    type="text"
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    placeholder="VD: 0381000123456"
                    className="w-full px-3 py-2 rounded-xl bg-black/60 border border-slate-700 text-xs font-mono font-bold text-white focus:outline-none focus:border-emerald-500 placeholder:text-slate-600"
                    required={isCreator}
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Tên chủ tài khoản {isCreator && '*'}:</label>
                  <input
                    type="text"
                    value={accountHolder}
                    onChange={(e) => setAccountHolder(e.target.value.toUpperCase())}
                    placeholder="NGUYEN VAN A"
                    className="w-full px-3 py-2 rounded-xl bg-black/60 border border-slate-700 text-xs font-bold uppercase text-white focus:outline-none focus:border-emerald-500 placeholder:text-slate-600"
                    required={isCreator}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Preset Avatars Selection */}
          <div className="space-y-3 pt-1">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                <span>Hoặc Chọn Từ Bộ Sưu Tập Avatar Có Sẵn:</span>
              </label>
            </div>

            <div className="space-y-3">
              {PRESET_AVATARS.map((grp) => (
                <div key={grp.category} className="space-y-1.5">
                  <div className="text-[11px] font-semibold text-slate-400 px-1">
                    {grp.category}
                  </div>
                  <div className="grid grid-cols-4 gap-2.5">
                    {grp.avatars.map((item) => {
                      const isSelected = avatarUrl === item.url;
                      return (
                        <button
                          key={item.url}
                          type="button"
                          onClick={() => setAvatarUrl(item.url)}
                          className={`group relative p-1 rounded-xl border flex flex-col items-center gap-1 transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-blue-600/20 border-sky-400 shadow-md ring-2 ring-sky-400/50 scale-103'
                              : 'bg-[#0e1424] border-slate-800 hover:border-slate-700 hover:bg-[#131b2e]'
                          }`}
                        >
                          <img
                            src={item.url}
                            alt={item.name}
                            className="w-12 h-12 rounded-full object-cover border border-slate-700 group-hover:border-sky-400 transition-colors"
                          />
                          <span className="text-[10px] text-slate-300 truncate max-w-full text-center px-1">
                            {item.name}
                          </span>
                          {isSelected && (
                            <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-sky-500 text-white flex items-center justify-center">
                              <Check className="w-2.5 h-2.5 stroke-[3]" />
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Save Status / Button */}
          <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer transition-colors"
            >
              Đóng
            </button>

            <button
              type="submit"
              disabled={isSaved}
              className={`px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg cursor-pointer transition-all ${
                isSaved
                  ? 'bg-emerald-600 text-white'
                  : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-600/30 hover:scale-102'
              }`}
            >
              {isSaved ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Đã Lưu Thành Công!</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Lưu Hồ Sơ Đại Diện</span>
                </>
              )}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
