import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  RotateCw, 
  X, 
  Headphones, 
  Smartphone,
  Sparkles,
  FastForward
} from 'lucide-react';
import { Novel, Chapter } from '../types';
import { backgroundAudioManager } from '../utils/backgroundAudio';

interface AudioPlayerBarProps {
  currentNovel?: Novel | null;
  currentChapter?: Chapter | null;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onClose: () => void;
  selectedVoiceId?: string;
  onVoiceChange?: (voiceId: string) => void;
  autoNextChapter?: boolean;
  onToggleAutoNext?: () => void;
}

export const AudioPlayerBar: React.FC<AudioPlayerBarProps> = ({
  currentNovel,
  currentChapter,
  isPlaying,
  onTogglePlay,
  onClose,
  selectedVoiceId = 'vi-VN-HoaiMyNeural',
  onVoiceChange,
  autoNextChapter = true,
  onToggleAutoNext,
}) => {
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [currentTime, setCurrentTime] = useState<number>(245); // simulated 04:05
  const duration = 860; // simulated 14:20

  const novelTitle = currentNovel?.title || 'Đạo Quân Bất Gián';
  const chapterTitle = currentChapter?.title || 'Chương 1: Khởi đầu định mệnh';

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  useEffect(() => {
    if (isPlaying) {
      backgroundAudioManager.startBackgroundPlayback({
        title: `${novelTitle} - ${chapterTitle}`,
        artist: currentNovel?.author || 'Đạo Tâm Audio',
        coverImage: currentNovel?.coverImage,
        onPlay: onTogglePlay,
        onPause: onTogglePlay,
      });
    } else {
      backgroundAudioManager.pauseBackgroundPlayback();
    }

    return () => {
      backgroundAudioManager.pauseBackgroundPlayback();
    };
  }, [isPlaying, novelTitle, chapterTitle]);

  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 w-[95%] max-w-3xl bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-2xl p-3 sm:p-4 shadow-[0_10px_35px_-5px_rgba(0,0,0,0.12)] dark:shadow-2xl dark:shadow-black/90 z-50 flex items-center gap-3 sm:gap-4 animate-in slide-in-from-bottom duration-300">
      {/* Icon & Track Info */}
      <div className="flex items-center gap-3 min-w-0 flex-1 sm:max-w-xs">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 p-0.5 flex-shrink-0 shadow-md">
          <div className="w-full h-full bg-slate-900 rounded-[10px] flex items-center justify-center text-cyan-300">
            <Headphones className={`w-5 h-5 ${isPlaying ? 'animate-pulse text-white' : ''}`} />
          </div>
        </div>
        <div className="min-w-0">
          <div className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
            {chapterTitle}
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
            {novelTitle}
          </div>
        </div>
      </div>

      {/* Play Controls */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        <button
          onClick={() => setCurrentTime(Math.max(0, currentTime - 10))}
          className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          title="Lùi 10 giây"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        <button
          onClick={onTogglePlay}
          className="w-10 h-10 rounded-full bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center shadow-lg shadow-blue-600/30 hover:scale-105 active:scale-95 transition-all cursor-pointer"
          title={isPlaying ? 'Tạm dừng' : 'Phát'}
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5 fill-current" />}
        </button>

        <button
          onClick={() => setCurrentTime(Math.min(duration, currentTime + 10))}
          className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          title="Tua 10 giây"
        >
          <RotateCw className="w-4 h-4" />
        </button>
      </div>

      {/* Timeline Slider */}
      <div className="hidden md:flex items-center gap-2 flex-1">
        <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400 min-w-[36px]">
          {formatTime(currentTime)}
        </span>
        <input
          type="range"
          min="0"
          max={duration}
          value={currentTime}
          onChange={(e) => setCurrentTime(Number(e.target.value))}
          className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-600"
        />
        <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400 min-w-[36px]">
          {formatTime(duration)}
        </span>
      </div>

      {/* Voice Switcher (Hoài My & Nam Minh - Seamless Edge TTS) */}
      <div className="hidden sm:flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl shadow-xs">
        <button
          type="button"
          onClick={() => onVoiceChange && onVoiceChange('vi-VN-HoaiMyNeural')}
          className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer ${
            selectedVoiceId === 'vi-VN-HoaiMyNeural'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
          title="Giọng Nữ: Hoài My"
        >
          <span>👩</span> Hoài My
        </button>
        <button
          type="button"
          onClick={() => onVoiceChange && onVoiceChange('vi-VN-NamMinhNeural')}
          className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer ${
            selectedVoiceId === 'vi-VN-NamMinhNeural'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
          title="Giọng Nam: Nam Minh"
        >
          <span>👨</span> Nam Minh
        </button>
      </div>

        {/* Auto Next Chapter Toggle Button */}
        {onToggleAutoNext && (
          <button
            type="button"
            onClick={onToggleAutoNext}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              autoNextChapter
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
            title={autoNextChapter ? 'Tự động chuyển chương: Đang BẬT' : 'Tự động chuyển chương: Đang TẮT'}
          >
            <FastForward className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Tự chuyển chương</span>
          </button>
        )}

        {/* Speed Selector */}
      <div className="flex items-center gap-1.5">
        <select
          value={playbackSpeed}
          onChange={(e) => setPlaybackSpeed(Number(e.target.value))}
          className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium rounded-lg px-2 py-1 focus:outline-none cursor-pointer"
          title="Tốc độ phát"
        >
          <option value={0.8}>0.8x</option>
          <option value={1.0}>1.0x</option>
          <option value={1.25}>1.25x</option>
          <option value={1.5}>1.5x</option>
          <option value={2.0}>2.0x</option>
        </select>

        <span className="hidden lg:inline-flex items-center gap-1 text-[10px] text-cyan-600 dark:text-cyan-400 bg-cyan-50 dark:bg-slate-800 px-2 py-1 rounded-lg font-medium">
          <Smartphone className="w-3 h-3" />
          <span>Khóa màn hình vẫn nghe</span>
        </span>

        {/* Close Bar */}
        <button
          onClick={onClose}
          className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          title="Đóng trình phát audio"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
