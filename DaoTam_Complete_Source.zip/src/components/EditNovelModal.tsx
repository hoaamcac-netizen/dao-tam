import React, { useState, useRef, useMemo } from 'react';
import { Novel, Chapter, MainCategory, StoryRole, GenreItem } from '../types';
import { calculateChapterVip } from '../utils/rulesAndVoices';
import { 
  X, 
  Edit3, 
  Save, 
  Trash2, 
  Plus, 
  Upload, 
  Image as ImageIcon, 
  BookOpen, 
  Lock, 
  Unlock, 
  Coins, 
  CheckCircle2, 
  AlertTriangle, 
  Search, 
  CheckSquare, 
  Square, 
  ArrowLeft,
  FileText,
  PenTool,
  Scissors,
  Sparkles,
  Percent
} from 'lucide-react';
import { DaoTamLogo } from './DaoTamLogo';

interface EditNovelModalProps {
  isOpen: boolean;
  onClose: () => void;
  novel: Novel | null;
  genres: GenreItem[];
  onAddNewGenre?: (name: string) => void;
  onSaveNovel: (updatedNovel: Novel) => void;
}

export const EditNovelModal: React.FC<EditNovelModalProps> = ({
  isOpen,
  onClose,
  novel,
  genres,
  onAddNewGenre,
  onSaveNovel,
}) => {
  if (!isOpen || !novel) return null;

  const [activeTab, setActiveTab] = useState<'info' | 'chapters'>('info');

  // Form states for Novel Metadata
  const [title, setTitle] = useState(novel.title);
  const [author, setAuthor] = useState(novel.author);
  const [editor, setEditor] = useState(novel.editor || '');
  const [isAuthorRole, setIsAuthorRole] = useState(novel.publisherRoles?.includes('author') ?? true);
  const [isEditorRole, setIsEditorRole] = useState(novel.publisherRoles?.includes('editor') ?? !!novel.editor);
  const [isExclusive, setIsExclusive] = useState(!!novel.isExclusive);
  const [mainCategory, setMainCategory] = useState<MainCategory>(novel.mainCategory);
  const [status, setStatus] = useState<'Đang ra' | 'Hoàn thành'>(novel.status);
  const [coverImage, setCoverImage] = useState(novel.coverImage);
  const [description, setDescription] = useState(novel.description);
  const [selectedGenres, setSelectedGenres] = useState<string[]>(novel.categories || []);
  const [customGenreInput, setCustomGenreInput] = useState('');
  const [fullBookPriceXu, setFullBookPriceXu] = useState(novel.fullBookPriceXu || 120);
  const [fullBookDiscountPriceXu, setFullBookDiscountPriceXu] = useState(novel.fullBookDiscountPriceXu || 85);

  // Split Full Book Price evenly across VIP chapters state
  const [splitPriceInput, setSplitPriceInput] = useState<number>(novel.fullBookDiscountPriceXu || 50);
  const [batchPriceInput, setBatchPriceInput] = useState<string>('0.35');
  const [showBatchPriceModal, setShowBatchPriceModal] = useState(false);

  // File upload ref
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Chapters list state
  const [chapters, setChapters] = useState<Chapter[]>(() => [...novel.chapters]);
  const [chapterSearch, setChapterSearch] = useState('');
  const [selectedChapterIds, setSelectedChapterIds] = useState<string[]>([]);
  const [confirmBatchDelete, setConfirmBatchDelete] = useState(false);

  // Single Chapter Editing state
  const [editingChapter, setEditingChapter] = useState<Chapter | null>(null);
  const [isNewChapter, setIsNewChapter] = useState(false);

  // Success message state
  const [saveSuccessMsg, setSaveSuccessMsg] = useState('');

  // Handle Cover File Upload
  const handleCoverFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Vui lòng chọn tệp hình ảnh hợp lệ (PNG, JPG, WEBP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setCoverImage(event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  // Toggle Genre
  const handleToggleGenre = (genreName: string) => {
    if (selectedGenres.includes(genreName)) {
      if (selectedGenres.length > 1) {
        setSelectedGenres(selectedGenres.filter((g) => g !== genreName));
      }
    } else {
      setSelectedGenres([...selectedGenres, genreName]);
    }
  };

  const handleAddNewCustomGenre = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = customGenreInput.trim();
    if (!trimmed) return;
    if (onAddNewGenre) {
      onAddNewGenre(trimmed);
    }
    if (!selectedGenres.includes(trimmed)) {
      setSelectedGenres([...selectedGenres, trimmed]);
    }
    setCustomGenreInput('');
  };

  // Filtered Chapters
  const filteredChapters = useMemo(() => {
    if (!chapterSearch.trim()) return chapters;
    const q = chapterSearch.toLowerCase().trim();
    return chapters.filter(
      (c) => c.title.toLowerCase().includes(q) || c.number.toString().includes(q)
    );
  }, [chapters, chapterSearch]);

  // Batch Selection Handlers
  const handleToggleSelectAll = () => {
    if (selectedChapterIds.length === filteredChapters.length) {
      setSelectedChapterIds([]);
    } else {
      setSelectedChapterIds(filteredChapters.map((c) => c.id));
    }
  };

  const handleToggleSelectChapter = (id: string) => {
    if (selectedChapterIds.includes(id)) {
      setSelectedChapterIds(selectedChapterIds.filter((cid) => cid !== id));
    } else {
      setSelectedChapterIds([...selectedChapterIds, id]);
    }
  };

  // Batch Delete Execution
  const handleExecuteBatchDelete = () => {
    const remaining = chapters.filter((c) => !selectedChapterIds.includes(c.id));
    setChapters(remaining);
    setSelectedChapterIds([]);
    setConfirmBatchDelete(false);
  };

  // Chia đều giá trọn bộ cho các chương VIP (hỗ trợ xu lẻ như 0.01 hay 0.35)
  const handleSplitPriceAcrossVipChapters = () => {
    let vipChapters = chapters.filter((c) => c.isVip);

    // Nếu chưa có chương nào được đánh dấu VIP, hỏi bật VIP tự động theo quy chuẩn
    if (vipChapters.length === 0) {
      const shouldAutoVip = confirm(
        `Hiện chưa có chương nào được đánh dấu là VIP.\nBạn có muốn tự động bật VIP theo quy chuẩn (từ chương 51 nếu trên 200c, hoặc từ chương 31 nếu dưới 200c) và chia đều ${splitPriceInput} Xu không?`
      );
      if (!shouldAutoVip) return;

      const totalCount = chapters.length;
      const updatedWithVip = chapters.map((c) => {
        const { isVip } = calculateChapterVip(c.number, totalCount);
        return { ...c, isVip };
      });
      vipChapters = updatedWithVip.filter((c) => c.isVip);
      if (vipChapters.length === 0) {
        alert('Truyện chưa đủ số chương theo quy chuẩn để set VIP tự động.');
        return;
      }
      setChapters(updatedWithVip);
    }

    const pricePerChapter = parseFloat((splitPriceInput / vipChapters.length).toFixed(2));
    const effectivePrice = Math.max(0.01, pricePerChapter);

    setChapters((prev) =>
      prev.map((c) => (c.isVip ? { ...c, priceXu: effectivePrice } : c))
    );

    setSaveSuccessMsg(
      `Đã chia đều ${splitPriceInput} Xu cho ${vipChapters.length} chương VIP! Mỗi chương VIP là ${effectivePrice} Xu.`
    );
    setTimeout(() => setSaveSuccessMsg(''), 4500);
  };

  // Đặt giá Xu hàng loạt cho các chương đã chọn
  const handleApplyBatchPrice = () => {
    const parsed = parseFloat(batchPriceInput);
    if (isNaN(parsed) || parsed < 0) {
      alert('Vui lòng nhập số Xu hợp lệ (ví dụ: 0.01 hoặc 0.35).');
      return;
    }
    setChapters((prev) =>
      prev.map((c) =>
        selectedChapterIds.includes(c.id)
          ? { ...c, isVip: parsed > 0, priceXu: parsed }
          : c
      )
    );
    setShowBatchPriceModal(false);
    setSaveSuccessMsg(`Đã đặt giá ${parsed} Xu cho ${selectedChapterIds.length} chương đã chọn!`);
    setTimeout(() => setSaveSuccessMsg(''), 4000);
  };

  // Single Chapter Delete
  const handleDeleteSingleChapter = (chapterId: string) => {
    if (confirm('Bạn có chắc chắn muốn xóa chương này không?')) {
      setChapters((prev) => prev.filter((c) => c.id !== chapterId));
      if (selectedChapterIds.includes(chapterId)) {
        setSelectedChapterIds((prev) => prev.filter((id) => id !== chapterId));
      }
    }
  };

  // Open Chapter Editor for new chapter
  const handleAddNewChapter = () => {
    const nextNumber = chapters.length > 0 ? Math.max(...chapters.map((c) => c.number)) + 1 : 1;
    const { isVip, priceXu } = calculateChapterVip(nextNumber, novel.totalChapters);
    
    setEditingChapter({
      id: `${novel.id}-c${nextNumber}-${Date.now()}`,
      number: nextNumber,
      title: `Chương ${nextNumber}: Tiêu đề chương mới`,
      slug: `chuong-${nextNumber}`,
      content: '',
      wordCount: 0,
      publishedDate: new Date().toISOString().split('T')[0],
      isVip,
      priceXu,
    });
    setIsNewChapter(true);
  };

  // Save single chapter edit
  const handleSaveChapterEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingChapter) return;

    const wordCount = editingChapter.content.split(/\s+/).filter(Boolean).length;
    const updatedChapter: Chapter = {
      ...editingChapter,
      wordCount,
      title: editingChapter.title.trim() || `Chương ${editingChapter.number}`,
    };

    if (isNewChapter) {
      setChapters((prev) => [...prev, updatedChapter].sort((a, b) => a.number - b.number));
    } else {
      setChapters((prev) =>
        prev
          .map((c) => (c.id === updatedChapter.id ? updatedChapter : c))
          .sort((a, b) => a.number - b.number)
      );
    }

    setEditingChapter(null);
    setIsNewChapter(false);
  };

  // Save entire novel changes
  const handleSaveAllChanges = () => {
    if (!title.trim()) {
      alert('Vui lòng nhập tên truyện.');
      return;
    }

    const publisherRoles: StoryRole[] = [];
    if (isAuthorRole) publisherRoles.push('author');
    if (isEditorRole) publisherRoles.push('editor');

    const updatedNovel: Novel = {
      ...novel,
      title: title.trim(),
      author: author.trim() || 'Khuyết danh',
      editor: editor.trim() || undefined,
      publisherRoles,
      isExclusive,
      mainCategory,
      isOriginal: mainCategory === 'truyen-sang-tac',
      status,
      coverImage,
      description: description.trim(),
      categories: selectedGenres,
      totalChapters: Math.max(chapters.length, novel.totalChapters),
      fullBookPriceXu,
      fullBookDiscountPriceXu,
      chapters,
      updatedAt: Date.now(),
      lastUpdated: 'Vừa chỉnh sửa xong',
    };

    onSaveNovel(updatedNovel);
    setSaveSuccessMsg('Đã lưu thành công tất cả thay đổi của truyện và các chương!');
    setTimeout(() => {
      setSaveSuccessMsg('');
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-5 text-slate-200">
      <div className="w-full max-w-5xl bg-[#090d16] border border-blue-500/40 rounded-2xl shadow-2xl flex flex-col h-[92vh] overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Top Header */}
        <div className="px-6 py-4 bg-[#0e1424] border-b border-blue-500/20 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/40 text-sky-400 flex items-center justify-center flex-shrink-0">
              <Edit3 className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="font-serif text-lg font-bold text-white truncate">
                Chỉnh Sửa Truyện: {novel.title}
              </h2>
              <p className="text-xs text-sky-400">
                Sửa thông tin truyện, ảnh bìa, văn án, từng chương và xóa nhiều chương hàng loạt
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveAllChanges}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/30 flex items-center gap-1.5 transition-all cursor-pointer hover:scale-102"
            >
              <Save className="w-4 h-4" />
              <span>Lưu Thay Đổi</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Success Alert Banner */}
        {saveSuccessMsg && (
          <div className="px-6 py-2.5 bg-emerald-950/80 border-b border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            {saveSuccessMsg}
          </div>
        )}

        {/* Tabs Bar */}
        <div className="px-6 bg-[#0b0f19] border-b border-slate-800 flex items-center gap-4 text-xs font-bold flex-shrink-0">
          <button
            onClick={() => setActiveTab('info')}
            className={`py-3 border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'info'
                ? 'border-blue-500 text-sky-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>1. Thông Tin Chung &amp; Ảnh Bìa</span>
          </button>

          <button
            onClick={() => setActiveTab('chapters')}
            className={`py-3 border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'chapters'
                ? 'border-blue-500 text-sky-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>2. Quản Lý &amp; Sửa Từng Chương ({chapters.length} chương)</span>
          </button>
        </div>

        {/* Tab 1 Content: General Novel Info */}
        {activeTab === 'info' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[#07090e] text-xs">
            {/* Basic Info & Cover File Upload */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Cover Preview & Upload */}
              <div className="p-4 rounded-xl bg-[#0e1424] border border-slate-800 flex flex-col items-center justify-center text-center">
                <label className="block text-slate-300 font-bold mb-2 text-xs">
                  Ảnh Bìa Tác Phẩm:
                </label>
                
                <div className="relative group w-36 h-52 rounded-xl overflow-hidden border-2 border-blue-500/40 shadow-lg mb-3 bg-black">
                  <img src={coverImage} alt={title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 p-2">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="px-3 py-1.5 rounded-lg bg-blue-600 text-white text-[11px] font-bold cursor-pointer hover:bg-blue-500"
                    >
                      Đổi ảnh từ máy
                    </button>
                  </div>
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleCoverFileUpload}
                  className="hidden"
                />

                <div className="w-full space-y-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-2 rounded-lg bg-blue-950/60 hover:bg-blue-900/60 border border-blue-500/30 text-sky-300 font-semibold flex items-center justify-center gap-1.5 cursor-pointer text-xs"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Tải ảnh bìa mới từ máy</span>
                  </button>

                  <div>
                    <input
                      type="text"
                      value={coverImage}
                      onChange={(e) => setCoverImage(e.target.value)}
                      placeholder="Hoặc dán link ảnh bìa (URL)..."
                      className="w-full bg-[#090d16] border border-slate-700 rounded-lg p-2 text-[11px] text-slate-300 focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Metadata Inputs */}
              <div className="md:col-span-2 space-y-4">
                <div>
                  <label className="block text-slate-300 font-bold mb-1.5">Tên Tác Phẩm / Truyện *:</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full bg-[#0e1424] border border-slate-800 focus:border-blue-500 rounded-xl p-2.5 text-white text-sm font-semibold focus:outline-none"
                  />
                </div>

                {/* Role and Authorship */}
                <div className="p-3 bg-[#0e1424] rounded-xl border border-slate-800 space-y-2.5">
                  <label className="block text-slate-300 font-semibold">
                    Vai trò &amp; Cơ chế phát hành:
                  </label>
                  <div className="flex flex-wrap items-center gap-3">
                    <label className="flex items-center gap-2 cursor-pointer bg-[#090d16] px-3 py-1.5 rounded-lg border border-slate-700">
                      <input
                        type="checkbox"
                        checked={isAuthorRole}
                        onChange={(e) => setIsAuthorRole(e.target.checked)}
                        className="w-4 h-4 rounded text-blue-600 accent-blue-500"
                      />
                      <span className="font-bold text-white flex items-center gap-1">
                        <PenTool className="w-3.5 h-3.5 text-sky-400" /> Tác giả sáng tác
                      </span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer bg-[#090d16] px-3 py-1.5 rounded-lg border border-slate-700">
                      <input
                        type="checkbox"
                        checked={isEditorRole}
                        onChange={(e) => setIsEditorRole(e.target.checked)}
                        className="w-4 h-4 rounded text-indigo-600 accent-indigo-500"
                      />
                      <span className="font-bold text-white flex items-center gap-1">
                        <Scissors className="w-3.5 h-3.5 text-indigo-400" /> Editor / Bản Edit
                      </span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer bg-gradient-to-r from-amber-950/40 to-[#090d16] px-3 py-1.5 rounded-lg border border-amber-500/50">
                      <input
                        type="checkbox"
                        checked={isExclusive}
                        onChange={(e) => setIsExclusive(e.target.checked)}
                        className="w-4 h-4 rounded text-amber-500 accent-amber-500"
                      />
                      <span className="font-bold text-amber-300 flex items-center gap-1">
                        ⭐ Phát Hành Độc Quyền (95%)
                      </span>
                    </label>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1.5">Tác Giả Gốc *:</label>
                    <input
                      type="text"
                      required
                      value={author}
                      onChange={(e) => setAuthor(e.target.value)}
                      className="w-full bg-[#0e1424] border border-slate-800 focus:border-blue-500 rounded-xl p-2.5 text-white focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1.5">Tên Editor / Dịch Giả:</label>
                    <input
                      type="text"
                      value={editor}
                      onChange={(e) => setEditor(e.target.value)}
                      placeholder="Tên người edit hoặc dịch..."
                      className="w-full bg-[#0e1424] border border-slate-800 focus:border-blue-500 rounded-xl p-2.5 text-white focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1.5">Phân mục chính:</label>
                    <select
                      value={mainCategory}
                      onChange={(e) => setMainCategory(e.target.value as MainCategory)}
                      className="w-full bg-[#0e1424] border border-slate-800 focus:border-blue-500 rounded-xl p-2.5 text-white focus:outline-none"
                    >
                      <option value="dam-my">❤️ Đam Mỹ</option>
                      <option value="truyen-nam">⚔️ Truyện Nam</option>
                      <option value="truyen-nu">🌸 Truyện Nữ</option>
                      <option value="truyen-sang-tac">✍️ Truyện Sáng Tác</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1.5">Tình trạng:</label>
                    <select
                      value={status}
                      onChange={(e) => setStatus(e.target.value as any)}
                      className="w-full bg-[#0e1424] border border-slate-800 focus:border-blue-500 rounded-xl p-2.5 text-white focus:outline-none"
                    >
                      <option value="Đang ra">Đang ra</option>
                      <option value="Hoàn thành">Hoàn thành</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Description Textarea */}
            <div>
              <label className="block text-slate-300 font-bold mb-1.5">Văn Án / Giới Thiệu Tác Phẩm:</label>
              <textarea
                rows={5}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-[#0e1424] border border-slate-800 focus:border-blue-500 rounded-xl p-3 text-white leading-relaxed focus:outline-none"
              />
            </div>

            {/* Genres Selection */}
            <div className="p-4 rounded-xl bg-[#0e1424] border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-slate-200 font-bold flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-sky-400" />
                  Gắn Thể Loại:
                </label>
                <span className="text-[11px] text-sky-400 font-semibold">
                  Đã chọn {selectedGenres.length} thể loại
                </span>
              </div>

              <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto pr-1">
                {genres.map((g) => {
                  const isSelected = selectedGenres.includes(g.name);
                  return (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => handleToggleGenre(g.name)}
                      className={`text-xs px-2.5 py-1 rounded-full border transition-all cursor-pointer flex items-center gap-1 ${
                        isSelected
                          ? 'bg-blue-600 text-white font-bold border-sky-400 shadow-sm'
                          : 'bg-[#090d16] text-slate-300 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <span>{isSelected ? '✓' : '+'}</span>
                      <span>{g.name}</span>
                    </button>
                  );
                })}
              </div>

              <div className="pt-2 border-t border-slate-800 flex items-center gap-2">
                <input
                  type="text"
                  value={customGenreInput}
                  onChange={(e) => setCustomGenreInput(e.target.value)}
                  placeholder="Thêm thể loại mới..."
                  className="flex-1 bg-[#090d16] border border-slate-700 text-white text-xs rounded-lg px-3 py-1.5 focus:border-blue-500 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={handleAddNewCustomGenre}
                  className="px-3 py-1.5 rounded-lg bg-blue-600/30 hover:bg-blue-600/50 text-sky-300 font-bold text-xs flex items-center gap-1 border border-blue-500/40 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Thêm thể loại
                </button>
              </div>
            </div>

            {/* Pricing */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-xl bg-[#0e1424] border border-slate-800">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Giá trọn bộ niêm yết (Xu):</label>
                <input
                  type="number"
                  min="0"
                  value={fullBookPriceXu}
                  onChange={(e) => setFullBookPriceXu(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 focus:border-blue-500 rounded-lg p-2 text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Giá khuyến mãi combo trọn bộ (Xu):</label>
                <input
                  type="number"
                  min="0"
                  value={fullBookDiscountPriceXu}
                  onChange={(e) => setFullBookDiscountPriceXu(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 focus:border-blue-500 rounded-lg p-2 text-white focus:outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* Tab 2 Content: Chapter Management & Editor */}
        {activeTab === 'chapters' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-[#07090e] text-xs">
            {/* CÔNG CỤ CHIA ĐỀU GIÁ TRỌN BỘ CHO CÁC CHƯƠNG VIP */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-blue-950/70 via-indigo-950/50 to-blue-950/70 border border-blue-500/40 space-y-3 shadow-lg">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center flex-shrink-0">
                    <Coins className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-xs sm:text-sm flex items-center gap-1.5">
                      <span>Thiết Lập Giá Trọn Bộ &amp; Tự Động Chia Đều Cho Chương VIP</span>
                      <span className="text-[10px] bg-blue-600/30 text-sky-300 px-1.5 py-0.2 rounded border border-blue-500/40 font-normal">
                        Hỗ trợ Xu lẻ: 0,01 • 0,35...
                      </span>
                    </h4>
                    <p className="text-[11px] text-slate-300">
                      Nhập giá trọn bộ (hoặc số Xu mong muốn), hệ thống sẽ tự động tính toán và chia đều chính xác cho toàn bộ các chương VIP.
                    </p>
                  </div>
                </div>

                <div className="text-[11px] text-sky-300 font-semibold bg-[#090d16] px-3 py-1.5 rounded-lg border border-slate-800 flex items-center gap-2">
                  <span>VIP:</span>
                  <strong className="text-amber-400 font-mono text-xs">{chapters.filter((c) => c.isVip).length}</strong> / {chapters.length} chương
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-1 border-t border-blue-500/20">
                <div className="flex items-center gap-2">
                  <span className="text-slate-300 text-xs whitespace-nowrap">Giá trọn bộ cần chia:</span>
                  <div className="relative">
                    <input
                      type="number"
                      min="0.01"
                      step="any"
                      value={splitPriceInput}
                      onChange={(e) => setSplitPriceInput(parseFloat(e.target.value) || 0)}
                      placeholder="Ví dụ: 50, 85..."
                      className="w-24 bg-[#090d16] border border-amber-500/50 focus:border-amber-400 rounded-lg px-2.5 py-1.5 text-amber-300 font-bold text-xs text-center focus:outline-none"
                    />
                  </div>
                  <span className="text-amber-400 font-bold text-xs">Xu</span>
                </div>

                <button
                  type="button"
                  onClick={handleSplitPriceAcrossVipChapters}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-stone-950 font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20 cursor-pointer transition-all active:scale-98"
                >
                  <Percent className="w-4 h-4" />
                  <span>
                    ⚡ Chia Đều Giá Trọn Bộ Cho {chapters.filter((c) => c.isVip).length > 0 ? chapters.filter((c) => c.isVip).length : 'Tất Cả'} Chương VIP (~{chapters.filter((c) => c.isVip).length > 0 ? (splitPriceInput / chapters.filter((c) => c.isVip).length).toFixed(2) : (splitPriceInput / Math.max(1, chapters.length - 30)).toFixed(2)} Xu/chương)
                  </span>
                </button>
              </div>
            </div>

            {/* Toolbar: Search, Select All, Batch Actions, Add Chapter */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#090d16] p-4 rounded-xl border border-slate-800">
              <div className="flex items-center gap-2 flex-1 max-w-md relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={chapterSearch}
                  onChange={(e) => setChapterSearch(e.target.value)}
                  placeholder="Tìm theo số chương hoặc tiêu đề..."
                  className="w-full bg-[#0e1424] border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {/* Select All Button */}
                <button
                  type="button"
                  onClick={handleToggleSelectAll}
                  className="px-3 py-1.5 rounded-lg bg-[#0e1424] border border-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  {selectedChapterIds.length === filteredChapters.length && filteredChapters.length > 0 ? (
                    <CheckSquare className="w-4 h-4 text-sky-400" />
                  ) : (
                    <Square className="w-4 h-4 text-slate-500" />
                  )}
                  <span>{selectedChapterIds.length === filteredChapters.length ? 'Bỏ chọn' : 'Chọn tất cả'}</span>
                </button>

                {/* Batch Set Price for Selected Chapters */}
                {selectedChapterIds.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setShowBatchPriceModal(true)}
                    className="px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <Coins className="w-3.5 h-3.5" />
                    <span>Đặt giá Xu ({selectedChapterIds.length}c)</span>
                  </button>
                )}

                {/* Batch Delete Selected Chapters */}
                {selectedChapterIds.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setConfirmBatchDelete(true)}
                    className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-rose-600/30 cursor-pointer animate-pulse"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Xóa {selectedChapterIds.length} chương</span>
                  </button>
                )}

                {/* Add New Chapter Button */}
                <button
                  type="button"
                  onClick={handleAddNewChapter}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ Thêm Chương Mới</span>
                </button>
              </div>
            </div>

            {/* Chapters Table List */}
            <div className="space-y-2">
              {filteredChapters.length === 0 ? (
                <div className="p-8 text-center text-slate-500 bg-[#090d16] rounded-xl border border-slate-800">
                  Chưa có chương nào hoặc không tìm thấy chương phù hợp.
                </div>
              ) : (
                filteredChapters.map((ch) => {
                  const isChecked = selectedChapterIds.includes(ch.id);
                  return (
                    <div
                      key={ch.id}
                      className={`p-3 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                        isChecked
                          ? 'bg-blue-950/40 border-blue-500 shadow-sm'
                          : 'bg-[#090d16] border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <button
                          type="button"
                          onClick={() => handleToggleSelectChapter(ch.id)}
                          className="p-1 text-slate-400 hover:text-white cursor-pointer"
                        >
                          {isChecked ? (
                            <CheckSquare className="w-4 h-4 text-sky-400" />
                          ) : (
                            <Square className="w-4 h-4 text-slate-600" />
                          )}
                        </button>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-white text-xs truncate">
                              {ch.title}
                            </span>
                            {ch.isVip ? (
                              <span className="bg-amber-500/20 text-amber-300 font-bold px-2 py-0.5 rounded text-[10px] border border-amber-500/30 flex items-center gap-1">
                                <Lock className="w-2.5 h-2.5" /> VIP ({Number((typeof ch.priceXu === 'number' ? ch.priceXu : 5).toFixed(2))} Xu)
                              </span>
                            ) : (
                              <span className="bg-emerald-950 text-emerald-400 font-bold px-2 py-0.5 rounded text-[10px] border border-emerald-500/30">
                                Miễn Phí
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-3">
                            <span>Chương {ch.number}</span>
                            <span>• {ch.wordCount || ch.content.split(/\s+/).filter(Boolean).length} từ</span>
                            <span>• Ngày đăng: {ch.publishedDate || 'Mới'}</span>
                          </div>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingChapter({ ...ch });
                            setIsNewChapter(false);
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-blue-600/30 hover:bg-blue-600/50 text-sky-300 border border-blue-500/40 text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                          title="Sửa nội dung chương"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Sửa</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteSingleChapter(ch.id)}
                          className="p-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/40 cursor-pointer transition-colors"
                          title="Xóa chương này"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* Modal Xác Nhận Xóa Nhiều Chương Đã Chọn */}
        {confirmBatchDelete && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="w-full max-w-md bg-[#0e1424] border border-rose-500/50 rounded-2xl p-6 shadow-2xl space-y-4 animate-in zoom-in-95">
              <div className="w-12 h-12 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center border border-rose-500/40 mx-auto">
                <AlertTriangle className="w-6 h-6" />
              </div>

              <div className="text-center space-y-2">
                <h3 className="text-base font-bold text-white">
                  Xác Nhận Xóa {selectedChapterIds.length} Chương Đã Chọn?
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Bạn có chắc chắn muốn xóa vĩnh viễn <strong className="text-rose-400">{selectedChapterIds.length} chương</strong> khỏi truyện này không?
                </p>
                <div className="p-3 bg-rose-950/40 border border-rose-500/30 rounded-xl text-[11px] text-rose-300 text-left">
                  ⚠️ Thao tác này sẽ xóa toàn bộ nội dung của các chương được chọn. Độc giả sẽ không còn đọc được các chương này.
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setConfirmBatchDelete(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
                >
                  Hủy Bỏ
                </button>
                <button
                  type="button"
                  onClick={handleExecuteBatchDelete}
                  className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-lg shadow-rose-600/30 cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Trash2 className="w-4 h-4" />
                  Xóa Ngay
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal / Drawer Sửa Từng Chương (Chapter Editor) */}
        {editingChapter && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
            <div className="w-full max-w-3xl bg-[#090d16] border border-blue-500/40 rounded-2xl shadow-2xl flex flex-col h-[85vh] overflow-hidden animate-in zoom-in-95 text-slate-200">
              <div className="px-6 py-4 bg-[#0e1424] border-b border-blue-500/20 flex items-center justify-between">
                <h3 className="font-serif text-base font-bold text-white flex items-center gap-2">
                  <Edit3 className="w-4 h-4 text-sky-400" />
                  {isNewChapter ? 'Thêm Chương Mới' : `Sửa Chương ${editingChapter.number}`}
                </h3>

                <button
                  type="button"
                  onClick={() => setEditingChapter(null)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveChapterEdit} className="flex-1 overflow-y-auto p-6 space-y-4 bg-[#07090e] text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Số thứ tự chương:</label>
                    <input
                      type="number"
                      min="1"
                      required
                      value={editingChapter.number}
                      onChange={(e) =>
                        setEditingChapter({ ...editingChapter, number: Number(e.target.value) })
                      }
                      className="w-full bg-[#0e1424] border border-slate-800 focus:border-blue-500 rounded-xl p-2.5 text-white font-bold focus:outline-none"
                    />
                  </div>

                  <div className="sm:col-span-3">
                    <label className="block text-slate-300 font-semibold mb-1">Tiêu đề chương *:</label>
                    <input
                      type="text"
                      required
                      value={editingChapter.title}
                      onChange={(e) =>
                        setEditingChapter({ ...editingChapter, title: e.target.value })
                      }
                      placeholder="Ví dụ: Chương 1: Khởi đầu định mệnh..."
                      className="w-full bg-[#0e1424] border border-slate-800 focus:border-blue-500 rounded-xl p-2.5 text-white focus:outline-none"
                    />
                  </div>
                </div>

                {/* VIP Configuration with Decimal / Fractional Xu support */}
                <div className="p-3.5 rounded-xl bg-[#0e1424] border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={!!editingChapter.isVip}
                      onChange={(e) =>
                        setEditingChapter({
                          ...editingChapter,
                          isVip: e.target.checked,
                          priceXu: e.target.checked ? (editingChapter.priceXu ?? 5) : 0,
                        })
                      }
                      className="w-4 h-4 accent-amber-500 rounded"
                    />
                    <span className="font-bold text-white flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-amber-400" />
                      Đặt làm Chương VIP (Yêu cầu độc giả mở khóa bằng Xu)
                    </span>
                  </label>

                  {editingChapter.isVip && (
                    <div className="flex items-center gap-2 bg-[#090d16] px-3 py-1.5 rounded-xl border border-amber-500/30">
                      <span className="text-slate-300 font-semibold">Giá Xu:</span>
                      <input
                        type="number"
                        min="0.001"
                        step="any"
                        value={editingChapter.priceXu ?? 5}
                        onChange={(e) =>
                          setEditingChapter({ ...editingChapter, priceXu: parseFloat(e.target.value) || 0 })
                        }
                        placeholder="0.01 hay 0.35..."
                        className="w-24 bg-[#0e1424] border border-amber-500/50 text-amber-300 font-bold rounded-lg p-1.5 text-center focus:outline-none"
                      />
                      <span className="text-amber-400 font-bold">Xu</span>
                    </div>
                  )}
                </div>

                {/* Content Editor */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-slate-300 font-bold">Nội Dung Chi Tiết Của Chương:</label>
                    <span className="text-[11px] text-sky-400">
                      {editingChapter.content.split(/\s+/).filter(Boolean).length} từ
                    </span>
                  </div>
                  <textarea
                    rows={12}
                    required
                    value={editingChapter.content}
                    onChange={(e) =>
                      setEditingChapter({ ...editingChapter, content: e.target.value })
                    }
                    placeholder="Dán hoặc nhập toàn bộ nội dung văn bản của chương vào đây..."
                    className="w-full bg-[#0e1424] border border-slate-800 focus:border-blue-500 rounded-xl p-3 text-white leading-relaxed font-sans text-xs sm:text-sm focus:outline-none"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingChapter(null)}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
                  >
                    Hủy Bỏ
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md shadow-blue-600/30 cursor-pointer flex items-center gap-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>Lưu Chương Này</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal Đặt Giá Xu Hàng Loạt Cho Các Chương Đã Chọn */}
        {showBatchPriceModal && (
          <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="w-full max-w-md bg-[#0e1424] border border-amber-500/50 rounded-2xl p-6 shadow-2xl space-y-4 animate-in zoom-in-95 text-slate-200">
              <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/40 mx-auto">
                <Coins className="w-6 h-6" />
              </div>

              <div className="text-center space-y-2">
                <h3 className="text-base font-bold text-white">
                  Đặt Giá Xu Cho {selectedChapterIds.length} Chương Đã Chọn
                </h3>
                <p className="text-xs text-slate-300">
                  Nhập số Xu mong muốn. Hệ thống hỗ trợ cả số Xu lẻ như <strong className="text-amber-400">0,01</strong> hay <strong className="text-amber-400">0,35</strong> Xu.
                </p>
              </div>

              <div className="p-3 bg-[#090d16] border border-slate-800 rounded-xl space-y-2">
                <label className="block text-xs font-semibold text-slate-300">Số Xu cho mỗi chương:</label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={batchPriceInput}
                    onChange={(e) => setBatchPriceInput(e.target.value)}
                    placeholder="0.01 hay 0.35 hay 5..."
                    className="flex-1 bg-[#0e1424] border border-amber-500/50 rounded-lg p-2.5 text-white font-bold text-sm focus:outline-none"
                  />
                  <span className="font-bold text-amber-400 text-sm">Xu</span>
                </div>
                <div className="flex items-center gap-1.5 flex-wrap pt-1">
                  <span className="text-[11px] text-slate-400">Gợi ý nhanh:</span>
                  {['0.01', '0.05', '0.1', '0.35', '0.5', '1', '2', '5'].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setBatchPriceInput(val)}
                      className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-[10px] text-amber-300 font-medium cursor-pointer"
                    >
                      {val} Xu
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBatchPriceModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
                >
                  Hủy Bỏ
                </button>
                <button
                  type="button"
                  onClick={handleApplyBatchPrice}
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold shadow-lg shadow-amber-500/20 cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Áp Dụng Ngay
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
