import React from 'react';
import { Novel } from '../types';
import { Flame, Eye, Crown, BookOpen, Headphones } from 'lucide-react';

interface Top10HotSidebarProps {
  novels: Novel[];
  onSelectNovel: (novel: Novel) => void;
  onSelectCreator?: (creatorName: string) => void;
}

export const Top10HotSidebar: React.FC<Top10HotSidebarProps> = ({
  novels,
  onSelectNovel,
  onSelectCreator,
}) => {
  // Sắp xếp theo dailyViews hoặc views giảm dần
  const top10 = [...novels]
    .sort((a, b) => (b.dailyViews || b.views) - (a.dailyViews || a.views))
    .slice(0, 10);

  return (
    <aside className="w-full lg:w-80 flex-shrink-0 bg-white dark:bg-slate-800 rounded-2xl p-4 sm:p-5 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] dark:shadow-lg dark:shadow-black/40 h-fit sticky top-24 transition-colors">
      {/* Title */}
      <div className="flex items-center justify-between pb-3.5 mb-3.5 border-b border-slate-100 dark:border-slate-700/60">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-600/20">
            <Flame className="w-4 h-4 fill-white" />
          </div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 tracking-wide uppercase">
            Top 10 Hot Trong Ngày
          </h3>
        </div>
        <span className="text-[10px] text-blue-600 dark:text-cyan-400 bg-blue-50 dark:bg-slate-900 px-2 py-0.5 rounded-full font-semibold">
          Đọc nhiều nhất
        </span>
      </div>

      {/* List */}
      <div className="space-y-2">
        {top10.map((novel, index) => {
          const rank = index + 1;
          const isTop1 = rank === 1;
          const isTop2 = rank === 2;
          const isTop3 = rank === 3;

          return (
            <div
              key={novel.id}
              onClick={() => onSelectNovel(novel)}
              className="group p-2 rounded-xl bg-slate-50 dark:bg-slate-900/50 hover:bg-slate-100 dark:hover:bg-slate-700/50 transition-all flex items-center gap-3 cursor-pointer"
            >
              {/* Rank Badge */}
              <div
                className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs flex-shrink-0 ${
                  isTop1
                    ? 'bg-gradient-to-br from-amber-400 to-yellow-400 text-slate-950 shadow-xs'
                    : isTop2
                    ? 'bg-gradient-to-br from-slate-200 to-slate-400 text-slate-900'
                    : isTop3
                    ? 'bg-gradient-to-br from-cyan-500 to-blue-600 text-white'
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                {isTop1 ? <Crown className="w-3.5 h-3.5 fill-slate-950" /> : rank}
              </div>

              {/* Cover thumbnail */}
              <img
                src={novel.coverImage}
                alt={novel.title}
                className="w-10 h-13 rounded-md object-cover flex-shrink-0 shadow-xs group-hover:scale-105 transition-transform"
                loading="lazy"
              />

              {/* Title & Stats */}
              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-xs text-black !text-black group-hover:!text-blue-600 transition-colors line-clamp-1">
                  {novel.title}
                </h4>
                <div className="flex items-center gap-2 mt-1 text-[10px] text-black !text-black font-semibold">
                  <span 
                    onClick={(e) => {
                      if (onSelectCreator) {
                        e.stopPropagation();
                        onSelectCreator(novel.author);
                      }
                    }}
                    className="truncate hover:text-blue-600 hover:underline cursor-pointer max-w-[85px]"
                    title={`Xem trang tác giả ${novel.author}`}
                  >
                    {novel.author}
                  </span>
                  <span className="text-black font-bold">•</span>
                  <span className="flex items-center gap-0.5 text-blue-700 font-bold">
                    <Eye className="w-2.5 h-2.5" />
                    {novel.dailyViews ? (novel.dailyViews / 1000).toFixed(1) : (novel.views / 1000).toFixed(1)}k
                  </span>
                  {novel.hasAudio && (
                    <Headphones className="w-2.5 h-2.5 text-blue-700 ml-auto" />
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </aside>
  );
};
