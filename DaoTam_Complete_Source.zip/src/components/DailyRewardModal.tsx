import React, { useState, useEffect } from 'react';
import { Sparkles, CheckCircle2, Calendar, Trophy, X, LogIn, Clock, Lock, ShieldCheck } from 'lucide-react';
import { UserProfile } from '../types';

interface DailyRewardModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onClaim: () => void;
  onLogin: () => void;
}

const COOLDOWN_MS = 24 * 60 * 60 * 1000; // 24 hours

export const DailyRewardModal: React.FC<DailyRewardModalProps> = ({
  isOpen,
  onClose,
  user,
  onClaim,
  onLogin,
}) => {
  const [isClaiming, setIsClaiming] = useState(false);
  const [justClaimed, setJustClaimed] = useState(false);
  const [now, setNow] = useState(Date.now());

  // Update clock every second when modal is open
  useEffect(() => {
    if (!isOpen) return;
    setNow(Date.now());
    const interval = setInterval(() => {
      setNow(Date.now());
    }, 1000);
    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  const isAdmin = user.role === 'admin';
  const isGmailLoggedIn = Boolean(user.isLoggedIn && user.email && user.id !== 'guest');

  // Cooldown calculation
  const lastTime = user.lastDailyRewardTimestamp || 0;
  const elapsed = now - lastTime;
  const canClaim = isGmailLoggedIn && (!lastTime || elapsed >= COOLDOWN_MS) && !justClaimed;
  const remainingMs = canClaim ? 0 : Math.max(0, COOLDOWN_MS - elapsed);

  // Format remaining time into HH:MM:SS
  const formatRemainingTime = (ms: number) => {
    const totalSecs = Math.floor(ms / 1000);
    const hours = Math.floor(totalSecs / 3600);
    const minutes = Math.floor((totalSecs % 3600) / 60);
    const seconds = totalSecs % 60;
    return `${hours.toString().padStart(2, '0')} giờ ${minutes.toString().padStart(2, '0')} phút ${seconds.toString().padStart(2, '0')} giây`;
  };

  const handleClaimClick = () => {
    if (!canClaim || isClaiming) return;
    setIsClaiming(true);
    setTimeout(() => {
      onClaim();
      setIsClaiming(false);
      setJustClaimed(true);
    }, 400);
  };

  const todayStr = new Date().toLocaleDateString('vi-VN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-md bg-gradient-to-b from-[#161226] via-[#100e1c] to-[#0a0812] border-2 border-pink-500/40 rounded-3xl p-6 sm:p-7 shadow-2xl shadow-pink-900/40 text-center overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Glow ambient background effect */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-64 h-64 bg-pink-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 right-0 w-48 h-48 bg-amber-500/15 rounded-full blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header Icon */}
        <div className="relative inline-flex items-center justify-center mb-4">
          <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-pink-600 to-rose-400 p-1 shadow-lg shadow-pink-600/50 animate-bounce duration-1000">
            <div className="w-full h-full rounded-full bg-[#120d1f] flex items-center justify-center text-4xl">
              🌸
            </div>
          </div>
          <div className="absolute -bottom-1 -right-1 bg-amber-400 text-stone-950 font-black text-[11px] px-2 py-0.5 rounded-full shadow-md border border-amber-300">
            +5 HOA
          </div>
        </div>

        {/* Title & Date */}
        <h2 className="font-serif text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-pink-300 via-rose-200 to-amber-200">
          Điểm Danh Nhận Hoa
        </h2>
        <div className="flex items-center justify-center gap-1.5 text-xs text-pink-300/80 mt-1 mb-4 font-medium">
          <Calendar className="w-3.5 h-3.5" />
          <span className="capitalize">{todayStr}</span>
        </div>

        {/* Flower Balance Badge */}
        <div className="bg-[#1a142c] border border-pink-500/30 rounded-2xl p-4 mb-4 text-left flex items-center justify-between">
          <div>
            <div className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Túi Hoa Của Bạn</div>
            <div className="text-xl font-black text-pink-300 flex items-center gap-1.5 mt-0.5">
              <span>🌸</span>
              <span>{isAdmin ? 'Vô Hạn (∞)' : (user.flowerBalance ?? 0)}</span>
              <span className="text-xs text-slate-400 font-normal">hoa</span>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[11px] px-2.5 py-1 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30 font-bold inline-flex items-center gap-1">
              <Trophy className="w-3 h-3 text-amber-400" />
              Đề cử truyện hay
            </span>
          </div>
        </div>

        {/* CASE 1: USER IS NOT LOGGED IN WITH GMAIL */}
        {!isGmailLoggedIn ? (
          <div className="space-y-4">
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 text-left space-y-2">
              <div className="flex items-center gap-2 text-amber-300 font-bold text-xs">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                Yêu cầu đăng nhập tài khoản Gmail:
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Độc giả cần <strong>đăng nhập bằng Gmail</strong> thì mới bắt đầu điểm danh nhận được 5 hoa mỗi ngày. Sau khi điểm danh, hệ thống sẽ lưu vào tài khoản và đếm lùi 24h để điểm danh lần tiếp theo.
              </p>
            </div>

            <button
              onClick={() => {
                onClose();
                onLogin();
              }}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-sky-600 hover:from-blue-500 hover:to-sky-500 text-white font-black text-xs sm:text-sm uppercase tracking-wide flex items-center justify-center gap-2 shadow-xl shadow-blue-600/40 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
            >
              <LogIn className="w-4 h-4 text-white" />
              <span>Đăng Nhập Gmail Để Bắt Đầu Điểm Danh</span>
            </button>
          </div>
        ) : (
          /* CASE 2: LOGGED IN WITH GMAIL */
          <div className="space-y-4">
            {/* Explanatory description */}
            <div className="text-xs text-slate-300/90 leading-relaxed space-y-1.5 text-left bg-black/40 rounded-xl p-3.5 border border-slate-800">
              <p className="flex items-start gap-2">
                <span className="text-pink-400 text-sm">✦</span>
                <span>Tài khoản: <strong>{user.email}</strong></span>
              </p>
              <p className="flex items-start gap-2">
                <span className="text-pink-400 text-sm">✦</span>
                <span>Mỗi lần điểm danh nhận <strong>5 hoa 🌸</strong>. Sau khi nhận, cần đợi tròn <strong>24 giờ hôm sau</strong> mới được nhận tiếp.</span>
              </p>
            </div>

            {/* ACTION / COUNTDOWN */}
            {canClaim ? (
              <button
                onClick={handleClaimClick}
                disabled={isClaiming}
                className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-pink-600 via-rose-500 to-amber-500 hover:from-pink-500 hover:to-amber-400 text-white font-black text-sm uppercase tracking-wide flex items-center justify-center gap-2 shadow-xl shadow-pink-600/40 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
              >
                <Sparkles className="w-4 h-4 animate-spin text-amber-200" />
                <span>{isClaiming ? 'Đang Nhận Hoa...' : '🌸 Điểm Danh Nhận 5 Hoa Ngay'}</span>
              </button>
            ) : (
              <div className="space-y-3">
                <div className="w-full py-3 px-4 rounded-2xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-inner">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Bạn đã điểm danh nhận hoa thành công!</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-center space-y-1">
                  <div className="text-[11px] text-slate-400 flex items-center justify-center gap-1.5 font-medium">
                    <Clock className="w-3.5 h-3.5 text-pink-400 animate-pulse" />
                    <span>Lượt điểm danh tiếp theo sau 24h:</span>
                  </div>
                  <div className="font-mono text-sm sm:text-base font-extrabold text-amber-300">
                    {formatRemainingTime(remainingMs)}
                  </div>
                </div>

                <button
                  onClick={onClose}
                  className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold text-xs cursor-pointer transition-colors"
                >
                  Đóng
                </button>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
