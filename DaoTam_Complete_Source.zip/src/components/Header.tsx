import React, { useState } from 'react';
import { 
  Search, 
  Sun, 
  Moon, 
  Coins, 
  ShieldCheck, 
  Sparkles, 
  CheckCircle2, 
  Clock, 
  Plus, 
  BookPlus, 
  BookOpen, 
  Edit3 
} from 'lucide-react';
import { UserProfile, MainCategory, UserRole } from '../types';
import { DaoTamLogo } from './DaoTamLogo';
import { UserDropdown } from './UserDropdown';

interface HeaderProps {
  currentTab: 'home' | 'completed' | 'latest';
  setCurrentTab: (tab: 'home' | 'completed' | 'latest') => void;
  selectedMainCategory: 'all' | MainCategory;
  setSelectedMainCategory: (cat: 'all' | MainCategory) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  theme: 'dark' | 'light';
  setTheme: (theme: 'dark' | 'light') => void;
  onOpenAccount: () => void;
  onOpenXmlModal: () => void;
  onOpenTopUp: () => void;
  onOpenAdmin: () => void;
  onOpenArchitecture: () => void;
  onOpenSubmitNovel: () => void;
  onOpenVipPolicy?: () => void;
  onToggleRole: () => void;
  onSelectRole?: (role: UserRole) => void;
  user: UserProfile;
  pendingCount: number;
  onHomeClick: () => void;
  onOpenDailyReward?: () => void;
  hasClaimedToday?: boolean;
  onOpenAuthorShowcase?: () => void;
  onOpenRegisterCreator?: () => void;
  onOpenEditProfile?: () => void;
  onOpenProfile?: () => void;
  onOpenInterestedNovels?: () => void;
  onOpenFollowingCreators?: () => void;
  onOpenMyNovels?: () => void;
  onOpenReadingHistory?: () => void;
  onOpenBookmarks?: () => void;
  onOpenStats?: () => void;
  onOpenInfo?: () => void;
  onOpenChangePassword?: () => void;
  onLogout?: () => void;
  onLogin?: () => void;
  onOpenLogin?: () => void;
  onOpenRegister?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  selectedMainCategory,
  setSelectedMainCategory,
  searchQuery,
  setSearchQuery,
  theme,
  setTheme,
  onOpenAccount,
  onOpenTopUp,
  onOpenAdmin,
  user,
  pendingCount,
  onHomeClick,
  onOpenDailyReward,
  hasClaimedToday = false,
  onOpenAuthorShowcase,
  onOpenRegisterCreator,
  onOpenSubmitNovel,
  onOpenEditProfile,
  onOpenProfile,
  onOpenInterestedNovels,
  onOpenFollowingCreators,
  onOpenMyNovels,
  onOpenReadingHistory,
  onOpenBookmarks,
  onOpenStats,
  onOpenInfo,
  onOpenChangePassword,
  onLogout,
  onLogin,
  onOpenLogin,
  onOpenRegister,
}) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const isAdmin = user.role === 'admin';
  const isAuthor = user.role === 'author';

  return (
    <header className="sticky top-0 z-40 backdrop-blur-md bg-white/95 dark:bg-slate-900/95 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] dark:shadow-md dark:shadow-black/50 transition-colors">
      {/* Top Banner Bar: Role & Category Tabs */}
      <div className="bg-slate-100/80 dark:bg-slate-950/60 px-4 sm:px-6 py-1.5 text-xs">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          {/* Main Categories Selection */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto scrollbar-none">
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 mr-1 hidden md:inline">Phân mục:</span>
            
            <button
              onClick={() => setSelectedMainCategory('all')}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                selectedMainCategory === 'all'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-600'
              }`}
            >
              Tất cả
            </button>

            <button
              onClick={() => setSelectedMainCategory('truyen-nam')}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                selectedMainCategory === 'truyen-nam'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-600'
              }`}
            >
              <span>⚔️ Truyện Nam</span>
            </button>

            <button
              onClick={() => setSelectedMainCategory('dam-my')}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                selectedMainCategory === 'dam-my'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-600'
              }`}
            >
              <span>❤️ Đam Mỹ</span>
            </button>

            <button
              onClick={() => setSelectedMainCategory('truyen-nu')}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                selectedMainCategory === 'truyen-nu'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-600'
              }`}
            >
              <span>🌸 Truyện Nữ</span>
            </button>

            <button
              onClick={() => setSelectedMainCategory('truyen-sang-tac')}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                selectedMainCategory === 'truyen-sang-tac'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-600'
              }`}
            >
              <span>✍️ Truyện Sáng Tác</span>
            </button>
          </div>

          {/* Right Top Area: Admin Badge */}
          <div className="flex items-center gap-2">
            {isAdmin && (
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-600/10 text-blue-600 dark:text-cyan-400 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>👑 Quản Trị Viên</span>
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3">
        {/* Brand Logo: ĐẠO TÂM */}
        <div 
          onClick={onHomeClick}
          className="cursor-pointer"
        >
          <DaoTamLogo size="md" />
        </div>

        {/* Navigation items (Trang chủ, Truyện mới, Hoàn thành) */}
        <nav className="hidden xl:flex items-center gap-1">
          <button
            onClick={() => { setCurrentTab('home'); onHomeClick(); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
              currentTab === 'home'
                ? 'text-white bg-blue-600 shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            Trang chủ
          </button>
          <button
            onClick={() => setCurrentTab('latest')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
              currentTab === 'latest'
                ? 'text-white bg-blue-600 shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-white'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            Truyện mới
          </button>
          <button
            onClick={() => setCurrentTab('completed')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
              currentTab === 'completed'
                ? 'text-white bg-blue-600 shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-white'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            Hoàn thành
          </button>
        </nav>

        {/* Search Bar (Flat, borderless with soft focus) */}
        <div className="flex-1 max-w-xs relative hidden lg:block">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Tìm tên truyện, tác giả..."
            className="w-full bg-slate-100 dark:bg-slate-800 rounded-full py-1.5 pl-3.5 pr-8 text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 transition-all shadow-inner"
          />
          <Search className="w-3.5 h-3.5 text-blue-600 dark:text-cyan-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>

        {/* Action Controls (Ẩn xu, hoa, và nút đăng ký làm tác giả theo yêu cầu) */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Theme Mode Toggle (Flat & Modern Moon/Sun) */}
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-cyan-400 transition-all cursor-pointer shadow-2xs"
            title={theme === 'dark' ? 'Chuyển sang Giao diện Sáng' : 'Chuyển sang Giao diện Tối'}
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-slate-700" />
            )}
          </button>

          {/* Chưa đăng nhập: Hiện nút "Đăng nhập" và "Đăng ký" chuẩn hình 1 */}
          {(!user.isLoggedIn || user.id === 'guest') ? (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onOpenLogin || onLogin}
                className="px-3.5 py-1.5 rounded-lg bg-blue-500 hover:bg-blue-600 active:bg-blue-700 text-white font-medium text-xs sm:text-sm shadow-xs transition cursor-pointer"
              >
                Đăng nhập
              </button>
              <button
                type="button"
                onClick={onOpenRegister || onOpenAccount}
                className="px-3.5 py-1.5 rounded-lg bg-blue-500 hover:bg-blue-600 active:bg-blue-700 text-white font-medium text-xs sm:text-sm shadow-xs transition cursor-pointer"
              >
                Đăng ký
              </button>
            </div>
          ) : (
            /* Đã đăng nhập: Hiện Avatar Dropdown (kèm nút Admin nếu là quản trị viên) */
            <div className="flex items-center gap-2">
              {isAdmin && (
                <button
                  onClick={onOpenAdmin}
                  className="relative px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-blue-600 hover:text-white text-slate-700 dark:text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                  title="Quản trị hệ thống"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-blue-600 dark:text-cyan-400" />
                  <span className="hidden sm:inline">Admin {pendingCount > 0 ? `(${pendingCount})` : ''}</span>
                  {pendingCount > 0 && (
                    <span className="w-4 h-4 rounded-full bg-rose-500 text-white font-extrabold text-[9px] flex items-center justify-center animate-pulse">
                      {pendingCount}
                    </span>
                  )}
                </button>
              )}

              {/* User Dropdown Menu (Avatar trigger + dropdown với 11 mục chính xác) */}
              <UserDropdown
                user={user}
                isOpen={isDropdownOpen}
                onToggle={() => setIsDropdownOpen(!isDropdownOpen)}
                onClose={() => setIsDropdownOpen(false)}
                onOpenProfile={onOpenProfile || onOpenAccount}
                onOpenInterestedNovels={onOpenInterestedNovels || onOpenAccount}
                onOpenFollowingCreators={onOpenFollowingCreators || onOpenAccount}
                onOpenMyNovels={onOpenMyNovels || onOpenAuthorShowcase || onOpenAccount}
                onOpenSubmitNovel={onOpenSubmitNovel}
                onOpenReadingHistory={onOpenReadingHistory || onOpenAccount}
                onOpenBookmarks={onOpenBookmarks || onOpenAccount}
                onOpenStats={onOpenStats || onOpenAccount}
                onOpenInfo={onOpenInfo || onOpenAccount}
                onOpenChangePassword={onOpenChangePassword || onOpenEditProfile || onOpenAccount}
                onLogout={onLogout || onOpenAccount}
                onLogin={onLogin || onOpenAccount}
              />
            </div>
          )}

        </div>
      </div>
    </header>
  );
};
