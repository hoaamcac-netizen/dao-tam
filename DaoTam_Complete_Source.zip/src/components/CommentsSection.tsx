import React, { useState } from 'react';
import { Comment, UserProfile } from '../types';
import { MessageSquare, Heart, Send, Sparkles, User, CornerDownRight } from 'lucide-react';

interface CommentsSectionProps {
  novelId: string;
  chapterNumber?: number;
  user: UserProfile;
}

const INITIAL_COMMENTS: Record<string, Comment[]> = {
  'xuyen-nhanh-nam-chinh-hac-hoa': [
    {
      id: 'cm-1',
      novelId: 'xuyen-nhanh-nam-chinh-hac-hoa',
      chapterNumber: 4,
      userName: 'Mộng Đàm Các Chủ',
      userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
      content: 'Truyện cuốn xỉu luôn mn ơi! Giọng đọc Ngọc Huyền nghe êm như rót mật vào tai, đoạn Phó Cảnh Thâm hắc hóa nghe nổi cả da gà. Đã nạp Xu mua hẳn trọn bộ ủng hộ dịch giả!',
      createdAt: Date.now() - 3600 * 1000 * 2,
      likes: 24,
    },
    {
      id: 'cm-2',
      novelId: 'xuyen-nhanh-nam-chinh-hac-hoa',
      chapterNumber: 1,
      userName: 'Thanh Trúc',
      userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80',
      content: 'Chữ to rõ ràng, có tô màu theo câu lúc nghe audio tiện thật sự, vừa nằm vừa nhắm mắt nghe không bị lạc dòng.',
      createdAt: Date.now() - 3600 * 1000 * 5,
      likes: 18,
    },
    {
      id: 'cm-3',
      novelId: 'xuyen-nhanh-nam-chinh-hac-hoa',
      chapterNumber: 31,
      userName: 'Hắc Miêu Gia Gia',
      userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
      content: 'Ủng hộ cơ chế VIP từ chương 31 rất hợp lý cho truyện dưới 200 chương, thuật toán trừ số Xu chương lẻ lúc mua combo đỉnh chóp luôn, không bị mất tiền oan!',
      createdAt: Date.now() - 3600 * 1000 * 9,
      likes: 31,
    },
  ],
};

export const CommentsSection: React.FC<CommentsSectionProps> = ({
  novelId,
  chapterNumber,
  user,
}) => {
  const [commentList, setCommentList] = useState<Comment[]>(() => {
    const saved = localStorage.getItem(`dao_tam_comments_${novelId}`) || localStorage.getItem(`dmc_comments_${novelId}`);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_COMMENTS[novelId] || [
      {
        id: 'cm-default-1',
        novelId,
        userName: 'Tiểu Yến Tử',
        userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
        content: 'Truyện hay xuất sắc! Giọng đọc Nam Minh trầm ấm rất hợp không khí của tác phẩm.',
        createdAt: Date.now() - 3600000,
        likes: 12,
      },
    ];
  });

  const [newContent, setNewContent] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContent.trim()) return;

    const newComment: Comment = {
      id: `cm-${Date.now()}`,
      novelId,
      chapterNumber,
      userName: user.displayName || 'Độc giả yêu truyện',
      userAvatar: user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
      content: newContent.trim(),
      createdAt: Date.now(),
      likes: 0,
    };

    const updated = [newComment, ...commentList];
    setCommentList(updated);
    localStorage.setItem(`dao_tam_comments_${novelId}`, JSON.stringify(updated));
    setNewContent('');
  };

  const handleLike = (commentId: string) => {
    setCommentList((prev) =>
      prev.map((c) => {
        if (c.id === commentId) {
          const isLiked = c.isLiked;
          return {
            ...c,
            likes: isLiked ? c.likes - 1 : c.likes + 1,
            isLiked: !isLiked,
          };
        }
        return c;
      })
    );
  };

  return (
    <section className="bg-[#15161d] border border-neutral-800 rounded-2xl p-6 shadow-xl mt-8">
      {/* Title */}
      <div className="flex items-center justify-between pb-4 mb-5 border-b border-neutral-800">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <MessageSquare className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-serif text-lg font-bold text-amber-300">
              Bình Luận &amp; Cảm Nhận Độc Giả
            </h3>
            <p className="text-xs text-neutral-400">
              {commentList.length} lượt đàm luận từ độc giả Đạo Tâm
            </p>
          </div>
        </div>
      </div>

      {/* Post comment input form */}
      <form onSubmit={handleSubmit} className="mb-6">
        <div className="flex gap-3">
          <img
            src={user.avatarUrl}
            alt={user.displayName}
            className="w-10 h-10 rounded-full object-cover border border-amber-400 flex-shrink-0"
          />
          <div className="flex-1">
            <textarea
              value={newContent}
              onChange={(e) => setNewContent(e.target.value)}
              placeholder={`Viết bình luận của bạn${chapterNumber ? ` về Chương ${chapterNumber}` : ''}...`}
              rows={3}
              className="w-full bg-[#1b1c26] border border-neutral-800 focus:border-amber-500 rounded-xl p-3 text-xs sm:text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none transition-colors"
            />
            <div className="flex justify-between items-center mt-2">
              <span className="text-[11px] text-neutral-500">
                Lịch sự, tôn trọng tác giả và dịch giả
              </span>
              <button
                type="submit"
                disabled={!newContent.trim()}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-stone-950 font-bold text-xs flex items-center gap-1.5 shadow-md transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                Gửi bình luận
              </button>
            </div>
          </div>
        </div>
      </form>

      {/* Comment list */}
      <div className="space-y-4">
        {commentList.map((c) => {
          const timeAgo = formatTimeAgo(c.createdAt);

          return (
            <div
              key={c.id}
              className="p-4 rounded-xl bg-[#181922] border border-neutral-800/80 flex gap-3.5"
            >
              <img
                src={c.userAvatar}
                alt={c.userName}
                className="w-9 h-9 rounded-full object-cover border border-neutral-700 flex-shrink-0"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs sm:text-sm text-amber-300">
                      {c.userName}
                    </span>
                    {c.chapterNumber && (
                      <span className="bg-amber-500/15 text-amber-400 text-[10px] px-1.5 py-0.2 rounded font-medium">
                        Chương {c.chapterNumber}
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] text-neutral-500">{timeAgo}</span>
                </div>

                <p className="text-xs sm:text-sm text-neutral-200 mt-2 leading-relaxed">
                  {c.content}
                </p>

                <div className="mt-2.5 flex items-center gap-4 text-xs text-neutral-400">
                  <button
                    onClick={() => handleLike(c.id)}
                    className={`flex items-center gap-1 transition-colors cursor-pointer ${
                      c.isLiked ? 'text-rose-400 font-bold' : 'hover:text-rose-400'
                    }`}
                  >
                    <Heart className={`w-3.5 h-3.5 ${c.isLiked ? 'fill-rose-400' : ''}`} />
                    <span>{c.likes}</span>
                  </button>
                  <button className="flex items-center gap-1 hover:text-amber-400 transition-colors cursor-pointer">
                    <CornerDownRight className="w-3.5 h-3.5" />
                    <span>Trả lời</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};

function formatTimeAgo(timestamp: number) {
  const diff = Date.now() - timestamp;
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return 'Vừa xong';
  if (minutes < 60) return `${minutes} phút trước`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} giờ trước`;
  const days = Math.floor(hours / 24);
  return `${days} ngày trước`;
}
