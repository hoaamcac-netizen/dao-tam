import React, { useState } from 'react';
import { Novel, Chapter, UserProfile } from '../types';
import { 
  X, 
  Lock, 
  Coins, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  ShoppingBag, 
  Tag, 
  ArrowRight,
  ShieldCheck,
  Scale
} from 'lucide-react';
import { DaoTamLogo } from './DaoTamLogo';

interface VipPurchaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  novel: Novel;
  chapter: Chapter;
  user: UserProfile;
  onConfirmPurchase: (type: 'chapter' | 'full_book', price: number) => void;
  onOpenTopUp: () => void;
}

export const VipPurchaseModal: React.FC<VipPurchaseModalProps> = ({
  isOpen,
  onClose,
  novel,
  chapter,
  user,
  onConfirmPurchase,
  onOpenTopUp,
}) => {
  const [purchaseType, setPurchaseType] = useState<'chapter' | 'full_book'>('chapter');

  if (!isOpen) return null;

  // Single chapter price (supports decimal like 0.01 or 0.35)
  const chapterPrice = typeof chapter.priceXu === 'number' ? chapter.priceXu : 5;

  // Full book base price & discount price
  const comboBasePrice = novel.fullBookPriceXu || 120;
  const comboPromoPrice = novel.fullBookDiscountPriceXu || 85;

  // Smart Pricing Algorithm: Calculate already spent Xu on individual chapters for this novel
  const unlockedChaptersForNovel = user.unlockedChapters[novel.id] || [];
  const alreadyPurchasedCount = unlockedChaptersForNovel.length;
  const alreadyPaidXu = unlockedChaptersForNovel.reduce((sum, chId) => {
    const ch = novel.chapters.find((c) => c.id === chId);
    const p = ch && typeof ch.priceXu === 'number' ? ch.priceXu : 5;
    return sum + p;
  }, 0);

  // Final Price for Full Book = Promo Price MINUS already paid Xu
  const fullBookFinalPrice = Math.max(0, parseFloat((comboPromoPrice - alreadyPaidXu).toFixed(2)));

  const selectedPrice = purchaseType === 'chapter' ? chapterPrice : fullBookFinalPrice;
  const hasEnoughBalance = user.xuBalance >= selectedPrice;

  const handlePurchase = () => {
    if (!hasEnoughBalance) {
      onOpenTopUp();
      return;
    }
    onConfirmPurchase(purchaseType, selectedPrice);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
      <div className="w-full max-w-lg bg-[#090d16] border border-blue-500/40 rounded-2xl shadow-2xl p-6 relative overflow-hidden animate-in zoom-in-95 duration-200 text-slate-200">
        {/* Top Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-sky-400">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-lg font-bold text-white">
                Mở Khóa Nội Dung VIP
              </h3>
              <p className="text-xs text-sky-400">
                Hệ Thống Bản Quyền Đạo Tâm
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Novel & Chapter Info Card */}
        <div className="my-4 p-3.5 rounded-xl bg-[#0e1424] border border-slate-800 flex items-center gap-3">
          <img
            src={novel.coverImage}
            alt={novel.title}
            className="w-12 h-16 rounded-md object-cover flex-shrink-0 border border-slate-800"
          />
          <div className="min-w-0 flex-1">
            <h4 className="font-bold text-sm text-white truncate">
              {novel.title}
            </h4>
            <div className="text-xs text-sky-300 font-semibold mt-0.5">
              Chương {chapter.number}: {chapter.title.replace(/^Chương \d+:\s*/, '')}
            </div>
            <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-2">
              <span>{chapter.wordCount || 3200} từ</span>
              <span>•</span>
              <span className="text-emerald-400">Âm thanh Audio TTS chuẩn</span>
            </div>
          </div>
        </div>

        {/* Purchase Options Selector */}
        <div className="space-y-3">
          {/* Option 1: Mua lẻ chương này */}
          <div
            onClick={() => setPurchaseType('chapter')}
            className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
              purchaseType === 'chapter'
                ? 'bg-blue-950/50 border-blue-500 shadow-md ring-1 ring-sky-400'
                : 'bg-[#0e1424] border-slate-800 hover:border-slate-700'
            }`}
          >
            <div>
              <div className="font-bold text-xs sm:text-sm text-white flex items-center gap-2">
                <span>Chỉ Mua Chương {chapter.number}</span>
                <span className="bg-slate-800 text-slate-300 text-[10px] px-1.5 py-0.2 rounded font-normal">
                  Chương lẻ
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Mở khóa vĩnh viễn nội dung chữ &amp; Audio TTS của chương này.
              </p>
            </div>
            <div className="text-right">
              <div className="font-extrabold text-sm text-sky-300 flex items-center gap-1 justify-end">
                <Coins className="w-3.5 h-3.5 text-sky-400" />
                {Number(chapterPrice.toFixed(2))} Xu
              </div>
            </div>
          </div>

          {/* Option 2: Mua trọn bộ (Smart Pricing with auto-deduction) */}
          <div
            onClick={() => setPurchaseType('full_book')}
            className={`p-3.5 rounded-xl border transition-all cursor-pointer relative overflow-hidden ${
              purchaseType === 'full_book'
                ? 'bg-blue-950/50 border-blue-500 shadow-md ring-1 ring-sky-400'
                : 'bg-[#0e1424] border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="absolute top-0 right-0 bg-blue-600 text-white font-extrabold text-[9px] px-2 py-0.5 rounded-bl-lg uppercase tracking-wider">
              Khuyên dùng • Tiết kiệm nhất
            </div>

            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="font-bold text-xs sm:text-sm text-white flex items-center gap-2">
                  <span>Mua Trọn Bộ Cả Truyện</span>
                  <span className="bg-emerald-500/20 text-emerald-400 text-[10px] font-bold px-1.5 py-0.2 rounded border border-emerald-500/30">
                    Combo VIP
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Mở khóa tất cả {novel.totalChapters} chương hiện tại &amp; các chương mới trong tương lai.
                </p>

                {/* Smart Pricing Deductions Breakdown */}
                <div className="mt-2.5 p-2.5 rounded-lg bg-[#07090e] border border-slate-800 text-[11px] space-y-1">
                  <div className="flex justify-between text-slate-400">
                    <span>Giá trọn bộ ưu đãi:</span>
                    <span className="line-through text-slate-500">{comboBasePrice} Xu &rarr; {comboPromoPrice} Xu</span>
                  </div>
                  {alreadyPaidXu > 0 ? (
                    <div className="flex justify-between text-emerald-400 font-medium">
                      <span>Đã trừ {alreadyPurchasedCount} chương bạn từng mua:</span>
                      <span>- {alreadyPaidXu} Xu</span>
                    </div>
                  ) : (
                    <div className="text-slate-500 italic text-[10px]">
                      (Chưa mua chương lẻ nào trước đó)
                    </div>
                  )}
                  <div className="flex justify-between text-sky-200 font-bold pt-1 border-t border-slate-800">
                    <span>Thực tế chỉ cần thanh toán:</span>
                    <span className="text-sky-300 text-xs">{fullBookFinalPrice} Xu</span>
                  </div>
                </div>
              </div>

              <div className="text-right pt-4 flex-shrink-0">
                <div className="font-extrabold text-base text-sky-300 flex items-center gap-1 justify-end">
                  <Coins className="w-4 h-4 text-sky-400" />
                  {Number(fullBookFinalPrice.toFixed(2))} Xu
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-5 pt-4 border-t border-slate-800">
          {hasEnoughBalance ? (
            <button
              onClick={handlePurchase}
              className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-xl shadow-blue-600/30 flex items-center justify-center gap-2 transition-all hover:scale-101 cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4" />
              Thanh Toán Ngay ({Number(selectedPrice.toFixed(2))} Xu)
            </button>
          ) : (
            <div className="space-y-2">
              <div className="text-center text-xs text-rose-400 font-semibold flex items-center justify-center gap-1.5">
                <AlertCircle className="w-4 h-4" />
                Số dư Xu không đủ (Cần {Number(selectedPrice.toFixed(2))} Xu, hiện có {Number(user.xuBalance.toFixed(2))} Xu)
              </div>
              <button
                onClick={() => {
                  onClose();
                  onOpenTopUp();
                }}
                className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-xl shadow-blue-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Coins className="w-4 h-4" />
                Nạp Thêm Xu Ngay
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
