import React from 'react';
import { Novel, ReadingProgress } from '../types';
import { Eye, EyeOff, BookOpen, Flame, Headphones, Trophy } from 'lucide-react';

interface NovelCardProps {
  novel: Novel;
  progress?: ReadingProgress;
  onSelect: (novel: Novel) => void;
  onResumeReading?: (novel: Novel, progress: ReadingProgress) => void;
  onSelectCreator?: (creatorName: string) => void;
}

export const NovelCard: React.FC<NovelCardProps> = ({
  novel,
  progress,
  onSelect,
  onResumeReading,
  onSelectCreator,
}) => {
  return (
    <div 
      onClick={() => onSelect(novel)}
      className="group relative bg-white dark:bg-slate-800 rounded-xl overflow-hidden shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] dark:shadow-lg dark:shadow-black/40 hover:shadow-xl hover:shadow-blue-600/10 dark:hover:shadow-black/60 transition-all duration-300 flex flex-col cursor-pointer transform hover:-translate-y-1"
    >
      {/* Thumbnail with overlay badges */}
      <div className="relative aspect-[2/3] w-full overflow-hidden bg-slate-900">
        <img
          src={novel.coverImage}
          alt={novel.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 shadow-md"
          loading="lazy"
        />

        {/* Top Badges (Rounded-full, semi-transparent bg-black/60, light text, compact 10px) */}
        <div className="absolute top-2 left-2 flex items-center gap-1 z-10 flex-wrap">
          {novel.isHidden && (
            <span className="bg-black/60 backdrop-blur-xs text-purple-300 text-[10px] font-medium px-2 py-0.5 rounded-full shadow-sm flex items-center gap-0.5">
              <EyeOff className="w-2.5 h-2.5" /> ĐÃ ẨN
            </span>
          )}
          {(novel.mainCategory === 'truyen-sang-tac' || novel.isOriginal) && (
            <span className="bg-black/60 backdrop-blur-xs text-cyan-300 text-[10px] font-medium px-2 py-0.5 rounded-full shadow-sm flex items-center gap-0.5">
              SÁNG TÁC
            </span>
          )}
          {novel.status === 'Hoàn thành' && (
            <span className="bg-black/60 backdrop-blur-xs text-emerald-300 text-[10px] font-medium px-2 py-0.5 rounded-full shadow-sm">
              FULL
            </span>
          )}
          {novel.hasAudio && (
            <span className="bg-blue-600/80 backdrop-blur-xs text-white text-[10px] font-medium px-2 py-0.5 rounded-full shadow-sm flex items-center gap-0.5">
              <Headphones className="w-2.5 h-2.5 text-cyan-200" /> AUDIO
            </span>
          )}
        </div>

        {novel.isHot && (
          <div className="absolute top-2 right-2 z-10">
            <span className="bg-rose-600/80 backdrop-blur-xs text-white text-[10px] font-medium px-2 py-0.5 rounded-full flex items-center gap-0.5 shadow-sm">
              <Flame className="w-2.5 h-2.5 text-amber-300" /> HOT
            </span>
          </div>
        )}

        {/* Bottom Overlay with Chapter & Views */}
        <div className="absolute inset-x-0 bottom-0 pt-8 pb-2 px-2.5 bg-gradient-to-t from-black/90 via-black/50 to-transparent flex items-center justify-between text-[11px] text-white">
          <span className="flex items-center gap-1 font-medium bg-black/60 px-2 py-0.5 rounded-full backdrop-blur-xs text-slate-200">
            <BookOpen className="w-3 h-3 text-cyan-400" />
            {novel.totalChapters} c
          </span>
          <span className="flex items-center gap-1 font-medium text-cyan-300 bg-black/60 px-2 py-0.5 rounded-full backdrop-blur-xs">
            <Eye className="w-3 h-3 text-cyan-400" />
            {(novel.views / 1000).toFixed(1)}k
          </span>
        </div>

        {/* Reading progress ribbon if user has read */}
        {progress && (
          <div className="absolute top-0 inset-x-0 bg-blue-600 text-white font-medium text-[10px] py-0.5 text-center shadow-sm z-20">
            Đang đọc: C{progress.chapterNumber} ({progress.scrollPercentage}%)
          </div>
        )}
      </div>

      {/* Novel Info (White background with solid black high-contrast text) */}
      <div className="p-3 flex-1 flex flex-col justify-between bg-white">
        <div>
          <h3 className="font-bold text-sm text-black !text-black group-hover:!text-blue-600 transition-colors line-clamp-2 leading-snug">
            {novel.title}
          </h3>
          <div className="text-[11.5px] text-black !text-black font-semibold mt-1.5 line-clamp-1">
            {novel.editor ? (
              <span className="flex items-center gap-1.5 truncate">
                <span 
                  onClick={(e) => {
                    if (onSelectCreator) {
                      e.stopPropagation();
                      onSelectCreator(novel.author);
                    }
                  }}
                  className="truncate hover:text-blue-600 hover:underline cursor-pointer"
                  title={`Xem trang cá nhân của tác giả ${novel.author}`}
                >
                  Tg: <strong className="text-black !text-black font-bold">{novel.author}</strong>
                </span>
                <span className="text-black font-bold">•</span>
                <span 
                  onClick={(e) => {
                    if (onSelectCreator && novel.editor) {
                      e.stopPropagation();
                      onSelectCreator(novel.editor);
                    }
                  }}
                  className="text-blue-700 !text-blue-700 font-bold truncate hover:underline cursor-pointer"
                  title={`Xem trang cá nhân của editor ${novel.editor}`}
                >
                  Edit: {novel.editor}
                </span>
              </span>
            ) : (
              <span 
                onClick={(e) => {
                  if (onSelectCreator) {
                    e.stopPropagation();
                    onSelectCreator(novel.author);
                  }
                }}
                className="hover:text-blue-600 hover:underline cursor-pointer"
                title={`Xem trang cá nhân của tác giả ${novel.author}`}
              >
                Tác giả: <strong className="text-black !text-black font-bold">{novel.author}</strong>
              </span>
            )}
          </div>
        </div>

        <div className="mt-2.5 pt-2 border-t border-slate-200 flex items-center justify-between text-[11px] text-black">
          <div className="flex items-center gap-1.5 truncate">
            <span className="text-blue-700 !text-blue-700 font-bold truncate">
              {novel.categories[0]}
            </span>
            {typeof novel.flowerCount === 'number' && novel.flowerCount > 0 && (
              <span className="text-[10px] text-blue-900 font-bold bg-blue-100 px-2 py-0.5 rounded-full flex items-center gap-0.5 flex-shrink-0">
                <Trophy className="w-2.5 h-2.5 text-amber-500" /> {novel.flowerCount >= 1000 ? `${(novel.flowerCount / 1000).toFixed(1)}k` : novel.flowerCount}
              </span>
            )}
          </div>
          {progress ? (
            <button
              onClick={(e) => {
                e.stopPropagation();
                if (onResumeReading) onResumeReading(novel, progress);
                else onSelect(novel);
              }}
              className="text-[10px] text-blue-700 hover:text-blue-900 font-bold flex items-center gap-0.5 cursor-pointer"
            >
              <span>Đọc tiếp</span> &rarr;
            </button>
          ) : (
            <span className="text-[10px] text-black !text-black font-semibold">
              {novel.lastUpdated}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
