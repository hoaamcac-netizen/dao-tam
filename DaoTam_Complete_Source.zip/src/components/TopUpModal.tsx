import React, { useState } from 'react';
import { UserProfile, TopUpRequest } from '../types';
import { 
  X, 
  Coins, 
  QrCode, 
  CreditCard, 
  CheckCircle2, 
  Copy, 
  Check, 
  AlertCircle,
  Clock,
  Smartphone,
  ShieldCheck
} from 'lucide-react';
import { DaoTamLogo } from './DaoTamLogo';

interface TopUpModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onSubmitTopUp: (request: Omit<TopUpRequest, 'id' | 'createdAt' | 'status'>) => void;
}

const TOPUP_PACKAGES = [
  { vnd: 10000, xu: 10 },
  { vnd: 20000, xu: 20 },
  { vnd: 50000, xu: 50 },
  { vnd: 100000, xu: 100 },
  { vnd: 200000, xu: 200 },
  { vnd: 500000, xu: 500 },
];

export const TopUpModal: React.FC<TopUpModalProps> = ({
  isOpen,
  onClose,
  user,
  onSubmitTopUp,
}) => {
  const [paymentMethod, setPaymentMethod] = useState<'vietqr' | 'momo' | 'card'>('vietqr');
  const [selectedPkgIndex, setSelectedPkgIndex] = useState(2); // 50.000đ = 50 Xu
  const [customAmount, setCustomAmount] = useState<number | ''>('');
  const [transferCode] = useState(() => `DT${Math.floor(100000 + Math.random() * 900000)}`);
  
  // Copy feedback
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedAccount, setCopiedAccount] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Thẻ cào state
  const [telco, setTelco] = useState<'viettel' | 'vinaphone' | 'mobifone'>('viettel');
  const [cardSerial, setCardSerial] = useState('');
  const [cardPin, setCardPin] = useState('');
  const [cardAmount, setCardAmount] = useState(50000);

  if (!isOpen) return null;

  // 1.000 đồng = 1 Xu
  const currentVnd = typeof customAmount === 'number' && customAmount > 0 
    ? customAmount 
    : TOPUP_PACKAGES[selectedPkgIndex].vnd;
  const currentXu = Math.floor(currentVnd / 1000);

  const bankName = 'MB Bank (Ngân Hàng TMCP Quân Đội)';
  const accountNumber = '0703765892';
  const accountHolder = 'PHAM KIM CHI';
  const qrImageSrc = '/assets/aistudio/m__QA_df6eb6ad.jpg';

  // Dynamic VietQR code URL
  const dynamicQrUrl = `https://api.vietqr.io/image/970422-${accountNumber}-compact2.jpg?amount=${currentVnd}&addInfo=${encodeURIComponent(transferCode)}&accountName=${encodeURIComponent(accountHolder)}`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(transferCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyAccount = () => {
    navigator.clipboard.writeText(accountNumber);
    setCopiedAccount(true);
    setTimeout(() => setCopiedAccount(false), 2000);
  };

  // Submit manual request for Admin review
  const handleSubmitBanking = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitTopUp({
      userId: user.id || 'guest',
      userEmail: user.email || 'docgia@daotam.vn',
      userName: user.displayName || 'Độc giả',
      amountVnd: currentVnd,
      xuAmount: currentXu,
      transferCode,
      bankName: paymentMethod === 'momo' ? 'Ví MoMo (SĐT: 0703765892)' : bankName,
      accountNumber,
    });
    setIsSubmitted(true);
  };

  // Thẻ cào submit
  const handleCardSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cardSerial.trim() || !cardPin.trim()) {
      alert('Vui lòng nhập đầy đủ Số Seri và Mã Thẻ PIN!');
      return;
    }
    const xu = Math.floor(cardAmount / 1000);
    onSubmitTopUp({
      userId: user.id || 'guest',
      userEmail: user.email || 'docgia@daotam.vn',
      userName: user.displayName || 'Độc giả',
      amountVnd: cardAmount,
      xuAmount: xu,
      transferCode: `CARD-${telco.toUpperCase()}-${cardPin.trim().slice(-4)}`,
      bankName: `Thẻ cào ${telco.toUpperCase()} (Seri: ${cardSerial.trim()} - PIN: ${cardPin.trim()})`,
      accountNumber: cardSerial.trim(),
    });
    setIsSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 text-slate-200">
      <div className="w-full max-w-xl bg-[#090d16] border border-blue-500/40 rounded-2xl shadow-2xl p-6 relative max-h-[90vh] overflow-y-auto animate-in zoom-in-95 duration-200">
        
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {isSubmitted ? (
          /* Request Submitted Screen */
          <div className="text-center py-8">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-500 text-emerald-400 flex items-center justify-center mx-auto mb-4 animate-bounce">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="font-serif text-xl font-bold text-white mb-2">
              Đã Gửi Yêu Cầu Nạp Tiền Tới Admin!
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto mb-3 leading-relaxed">
              Yêu cầu nạp tiền của bạn đã được chuyển vào hàng đợi đối soát của Ban Quản Trị. 
            </p>
            <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs max-w-md mx-auto mb-6 text-left space-y-1">
              <div className="font-bold flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                Quy trình cộng Xu chính xác &amp; bảo mật:
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                Độc giả mặc định có <strong>0 Xu</strong>. Sau khi Admin kiểm tra giao dịch chuyển khoản hoặc thẩm định thẻ cào thành công, hệ thống sẽ phê duyệt và số dư Xu sẽ được cộng chính xác vào tài khoản của bạn.
              </p>
            </div>
            <button
              onClick={() => {
                setIsSubmitted(false);
                onClose();
              }}
              className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer shadow-lg shadow-blue-600/30"
            >
              Đã Hiểu &amp; Quay Lại Đọc Truyện
            </button>
          </div>
        ) : (
          <div className="space-y-5">
            {/* Header */}
            <div className="flex items-center gap-3">
              <DaoTamLogo size="sm" />
              <div>
                <h3 className="font-serif text-lg font-bold text-white flex items-center gap-2">
                  <Coins className="w-5 h-5 text-amber-400" />
                  Nạp Xu Đọc Truyện
                </h3>
                <p className="text-xs text-slate-400">
                  Tỷ lệ quy đổi: <strong>1.000 VNĐ = 1 Xu</strong> • Xu được cộng sau khi Admin duyệt
                </p>
              </div>
            </div>

            {/* Current user balance banner */}
            <div className="p-3 rounded-xl bg-[#0e1424] border border-blue-500/20 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-slate-300">
                <Coins className="w-4 h-4 text-amber-400" />
                <span>Số dư hiện tại của bạn:</span>
              </div>
              <div className="font-mono font-bold text-amber-400 text-sm">
                {user.xuBalance} Xu
              </div>
            </div>

            {/* Notice banner */}
            <div className="p-2.5 rounded-xl bg-sky-950/40 border border-sky-500/30 text-[11px] text-sky-200 flex items-center gap-2">
              <Clock className="w-4 h-4 text-sky-400 flex-shrink-0" />
              <span>
                Sau khi thanh toán, bấm nút xác nhận bên dưới. Admin sẽ kiểm tra và bấm duyệt để cộng Xu vào ví cho bạn.
              </span>
            </div>

            {/* Payment Method Selector */}
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setPaymentMethod('vietqr')}
                className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  paymentMethod === 'vietqr'
                    ? 'bg-blue-600 text-white border-blue-500 shadow-md shadow-blue-600/30 font-bold'
                    : 'bg-[#0e1424] text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>VietQR (MB Bank)</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('momo')}
                className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  paymentMethod === 'momo'
                    ? 'bg-pink-600 text-white border-pink-500 shadow-md shadow-pink-600/30 font-bold'
                    : 'bg-[#0e1424] text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Ví MoMo</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('card')}
                className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  paymentMethod === 'card'
                    ? 'bg-amber-600 text-white border-amber-500 shadow-md shadow-amber-600/30 font-bold'
                    : 'bg-[#0e1424] text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>Thẻ Cào</span>
              </button>
            </div>

            {/* TAB: VIETQR / MOMO */}
            {(paymentMethod === 'vietqr' || paymentMethod === 'momo') && (
              <div className="space-y-4">
                {/* Choose packages */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-2">
                    Chọn gói nạp Xu:
                  </label>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                    {TOPUP_PACKAGES.map((pkg, idx) => (
                      <button
                        key={pkg.vnd}
                        type="button"
                        onClick={() => {
                          setSelectedPkgIndex(idx);
                          setCustomAmount('');
                        }}
                        className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                          selectedPkgIndex === idx && customAmount === ''
                            ? 'bg-blue-600/20 border-blue-500 ring-2 ring-blue-500/30'
                            : 'bg-[#0e1424] border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="text-base font-extrabold text-white">
                          {pkg.xu} Xu
                        </div>
                        <div className="text-[11px] text-emerald-400 font-semibold mt-0.5">
                          {pkg.vnd.toLocaleString('vi-VN')} đ
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* QR Code & Banking Info Card */}
                <div className="p-4 rounded-xl bg-[#0e1424] border border-slate-800 flex flex-col sm:flex-row items-center gap-4">
                  <div className="relative group flex-shrink-0">
                    <img
                      src={paymentMethod === 'momo' ? qrImageSrc : dynamicQrUrl}
                      alt="VietQR MBBank"
                      className="w-32 h-32 rounded-xl object-contain bg-white p-1 border-2 border-sky-400 shadow-md"
                    />
                    <div className="text-[10px] text-center text-slate-400 mt-1 font-mono">
                      Quét chuyển khoản
                    </div>
                  </div>

                  <div className="flex-1 min-w-0 space-y-2 text-xs">
                    <div className="flex justify-between items-center pb-1 border-b border-slate-800">
                      <span className="text-slate-400">Ngân hàng:</span>
                      <strong className="text-white">{paymentMethod === 'momo' ? 'Ví MoMo' : bankName}</strong>
                    </div>

                    <div className="flex justify-between items-center pb-1 border-b border-slate-800">
                      <span className="text-slate-400">Số tài khoản / SĐT:</span>
                      <div className="flex items-center gap-1.5">
                        <strong className="text-emerald-400 font-mono text-sm">{accountNumber}</strong>
                        <button
                          onClick={handleCopyAccount}
                          className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                          title="Sao chép STK"
                        >
                          {copiedAccount ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-slate-400" />}
                        </button>
                      </div>
                    </div>

                    <div className="flex justify-between items-center pb-1 border-b border-slate-800">
                      <span className="text-slate-400">Chủ tài khoản:</span>
                      <strong className="text-white uppercase">{accountHolder}</strong>
                    </div>

                    <div className="flex justify-between items-center pb-1 border-b border-slate-800">
                      <span className="text-slate-400">Nội dung chuyển khoản (bắt buộc):</span>
                      <div className="flex items-center gap-1.5">
                        <strong className="text-sky-300 font-mono text-xs">{transferCode}</strong>
                        <button
                          onClick={handleCopyCode}
                          className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                          title="Sao chép cú pháp"
                        >
                          {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-slate-400" />}
                        </button>
                      </div>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Số tiền:</span>
                      <strong className="text-pink-400 font-bold">{currentVnd.toLocaleString('vi-VN')} VNĐ ({currentXu} Xu)</strong>
                    </div>
                  </div>
                </div>

                {/* Submit button for Admin Review */}
                <button
                  type="button"
                  onClick={handleSubmitBanking}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 cursor-pointer transition-all hover:scale-[1.01]"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  <span>Xác Nhận Đã Chuyển Khoản &amp; Gửi Cho Admin Duyệt Nạp {currentXu} Xu</span>
                </button>
              </div>
            )}

            {/* TAB: THẺ CÀO ĐIỆN THOẠI */}
            {paymentMethod === 'card' && (
              <form onSubmit={handleCardSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Chọn nhà mạng:
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['viettel', 'vinaphone', 'mobifone'] as const).map((t) => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => setTelco(t)}
                        className={`p-2 rounded-xl border text-xs font-bold uppercase transition-all cursor-pointer ${
                          telco === t
                            ? 'bg-amber-600/20 border-amber-500 text-amber-300 ring-2 ring-amber-500/30'
                            : 'bg-[#0e1424] border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Mệnh giá thẻ cào:
                  </label>
                  <select
                    value={cardAmount}
                    onChange={(e) => setCardAmount(Number(e.target.value))}
                    className="w-full p-2.5 rounded-xl bg-[#0e1424] border border-slate-700 text-xs font-semibold text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value={10000}>10.000 đ = 10 Xu</option>
                    <option value={20000}>20.000 đ = 20 Xu</option>
                    <option value={50000}>50.000 đ = 50 Xu</option>
                    <option value={100000}>100.000 đ = 100 Xu</option>
                    <option value={200000}>200.000 đ = 200 Xu</option>
                    <option value={500000}>500.000 đ = 500 Xu</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Số Seri thẻ:
                  </label>
                  <input
                    type="text"
                    placeholder="Nhập dãy số seri trên thẻ..."
                    value={cardSerial}
                    onChange={(e) => setCardSerial(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-[#0e1424] border border-slate-700 text-xs font-mono text-white focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Mã thẻ (Mã cào dưới lớp tráng bạc):
                  </label>
                  <input
                    type="text"
                    placeholder="Nhập mã thẻ PIN bí mật..."
                    value={cardPin}
                    onChange={(e) => setCardPin(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-[#0e1424] border border-slate-700 text-xs font-mono text-white focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-600/30 cursor-pointer transition-all hover:scale-[1.01]"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  <span>Gửi Thẻ Cào &amp; Chờ Admin Thẩm Định Duyệt {Math.floor(cardAmount / 1000)} Xu</span>
                </button>
              </form>
            )}

          </div>
        )}

      </div>
    </div>
  );
};
