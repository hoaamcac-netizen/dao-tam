import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { AudioChunk, chunkChapterContent, seamlessAudioCache } from '../utils/audioChunker';
import { normalizeEdgeVoiceId } from '../utils/rulesAndVoices';

export interface UseSeamlessTTSOptions {
  content: string;
  initialVoiceId?: string;
  initialPlaybackRate?: number;
  onChunkChange?: (index: number, chunk: AudioChunk) => void;
  onComplete?: () => void;
  onError?: (err: Error) => void;
}

export interface UseSeamlessTTSReturn {
  chunks: AudioChunk[];
  currentChunkIndex: number;
  currentChunk: AudioChunk | null;
  isPlaying: boolean;
  isLoading: boolean;
  playbackRate: number;
  voiceId: string;
  progress: number;
  bufferedIndices: number[];
  error: string | null;
  play: (startIndex?: number) => Promise<void>;
  pause: () => void;
  resume: () => Promise<void>;
  togglePlay: () => void;
  stop: () => void;
  seekToChunk: (index: number) => Promise<void>;
  skipNext: () => Promise<void>;
  skipPrev: () => Promise<void>;
  setVoiceId: (voice: string) => void;
  setPlaybackRate: (rate: number) => void;
}

/**
 * Custom Hook: useSeamlessTTS
 * Quản lý phát âm thanh Microsoft Edge TTS không độ trễ, không gián đoạn:
 * - Chia nhỏ chương thành các đoạn câu 100 - 200 ký tự (Karaoke Mode sync)
 * - Hàng đợi âm thanh (Audio Queue): Phát câu hiện tại, đồng thời fetch ngầm câu n+1 và n+2
 * - Nối câu tức thì qua sự kiện onEnded bằng Blob URL đã được nạp sẵn vào RAM
 */
export function useSeamlessTTS({
  content,
  initialVoiceId = 'vi-VN-HoaiMyNeural',
  initialPlaybackRate = 1.0,
  onChunkChange,
  onComplete,
  onError,
}: UseSeamlessTTSOptions): UseSeamlessTTSReturn {
  const [voiceId, setVoiceIdState] = useState<string>(() => normalizeEdgeVoiceId(initialVoiceId));
  const [playbackRate, setPlaybackRateState] = useState<number>(initialPlaybackRate);
  const [currentChunkIndex, setCurrentChunkIndex] = useState<number>(-1);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [bufferedIndices, setBufferedIndices] = useState<number[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Tham chiếu đối tượng HTMLAudioElement chính
  const audioElementRef = useRef<HTMLAudioElement | null>(null);
  
  // Cờ kiểm soát vòng lặp phát để ngăn race-condition khi dừng hoặc tua nhanh
  const isPlaybackActiveRef = useRef<boolean>(false);
  const currentIndexRef = useRef<number>(-1);
  const voiceIdRef = useRef<string>(voiceId);
  const playbackRateRef = useRef<number>(playbackRate);

  // Đồng bộ refs với state
  useEffect(() => {
    voiceIdRef.current = voiceId;
  }, [voiceId]);

  useEffect(() => {
    playbackRateRef.current = playbackRate;
    if (audioElementRef.current) {
      audioElementRef.current.playbackRate = playbackRate;
    }
  }, [playbackRate]);

  useEffect(() => {
    currentIndexRef.current = currentChunkIndex;
  }, [currentChunkIndex]);

  // 1. Chia nhỏ nội dung chương bằng thuật toán Regex tối ưu (100 - 200 ký tự)
  const chunks = useMemo(() => {
    return chunkChapterContent(content, 100, 190);
  }, [content]);

  // Khởi tạo thẻ audio HTML5 duy nhất cho vòng đời hook
  useEffect(() => {
    const audio = new Audio();
    audio.preload = 'auto';
    audioElementRef.current = audio;

    return () => {
      audio.pause();
      audio.src = '';
      audioElementRef.current = null;
      seamlessAudioCache.clear();
    };
  }, []);

  // Xóa bộ đệm và reset khi nội dung chương thay đổi
  useEffect(() => {
    stop();
    seamlessAudioCache.clear();
    setBufferedIndices([]);
  }, [content]);

  /**
   * Tải trước ngầm (Pre-fetch) một câu vào RAM
   */
  const prefetchChunk = useCallback(async (index: number, activeVoice: string) => {
    if (index < 0 || index >= chunks.length) return;
    const chunk = chunks[index];
    try {
      await seamlessAudioCache.fetchAndCache(activeVoice, chunk.text);
      setBufferedIndices((prev) => (prev.includes(index) ? prev : [...prev, index]));
    } catch (err) {
      console.warn(`[SeamlessTTS] Lỗi prefetch câu #${index}:`, err);
    }
  }, [chunks]);

  /**
   * Bộ điều phối Hàng đợi (Queue Manager):
   * Trong lúc câu `currentIndex` đang phát, lập tức fetch ngầm câu tiếp theo và câu kế tiếp
   * (Lookahead window = 2 câu: i+1 và i+2)
   */
  const prefetchLookahead = useCallback((currentIndex: number, activeVoice: string) => {
    prefetchChunk(currentIndex + 1, activeVoice);
    prefetchChunk(currentIndex + 2, activeVoice);
  }, [prefetchChunk]);

  /**
   * Hàm cốt lõi: Phát một chunk cụ thể
   */
  const playChunk = useCallback(async (index: number) => {
    if (index < 0 || index >= chunks.length) {
      // Đã đọc xong toàn bộ chương
      setIsPlaying(false);
      setIsLoading(false);
      isPlaybackActiveRef.current = false;
      setCurrentChunkIndex(-1);
      if (onComplete) onComplete();
      return;
    }

    const audio = audioElementRef.current;
    if (!audio) return;

    const chunk = chunks[index];
    const currentVoice = voiceIdRef.current;
    currentIndexRef.current = index;
    setCurrentChunkIndex(index);
    if (onChunkChange) onChunkChange(index, chunk);

    // Kiểm tra xem audio của câu này đã có sẵn trong Cache RAM chưa
    const cachedUrl = seamlessAudioCache.get(currentVoice, chunk.text);

    try {
      let audioUrl = cachedUrl;
      if (!audioUrl) {
        setIsLoading(true);
        audioUrl = await seamlessAudioCache.fetchAndCache(currentVoice, chunk.text);
        setBufferedIndices((prev) => (prev.includes(index) ? prev : [...prev, index]));
      }

      // Nếu trong lúc chờ tải người dùng đã bấm Pause hoặc đổi câu khác, hủy bỏ phát
      if (!isPlaybackActiveRef.current || currentIndexRef.current !== index) {
        setIsLoading(false);
        return;
      }

      setIsLoading(false);
      setError(null);

      // Gắn URL âm thanh và thiết lập các sự kiện HTML5 Audio
      audio.src = audioUrl;
      audio.playbackRate = playbackRateRef.current;

      // NẠP ĐỆM NGẦM: Ngay khi câu hiện tại chuẩn bị phát, tải sẵn câu kế tiếp (i+1 và i+2)
      prefetchLookahead(index, currentVoice);

      // SỰ KIỆN onEnded: NỐI CÂU TỨC THÌ (Zero-latency transition)
      audio.onended = () => {
        if (!isPlaybackActiveRef.current) return;
        // Chuyển ngay sang câu kế tiếp không gián đoạn
        playChunk(index + 1);
      };

      audio.onerror = (e) => {
        console.warn(`[SeamlessTTS] Audio playback error on chunk #${index}:`, e);
        if (isPlaybackActiveRef.current) {
          // Tự động bỏ qua câu lỗi để luồng nghe không bị nghẽn
          setTimeout(() => {
            if (isPlaybackActiveRef.current) playChunk(index + 1);
          }, 250);
        }
      };

      await audio.play();
      setIsPlaying(true);
    } catch (err: any) {
      console.warn(`[SeamlessTTS] Không thể phát chunk #${index}:`, err);
      setIsLoading(false);
      if (onError) onError(err);
      setError(err?.message || 'Đang tự động chuyển tiếp câu...');
      // Tự động hồi phục và tiếp tục phát câu tiếp theo thay vì dừng đơ
      if (isPlaybackActiveRef.current) {
        setTimeout(() => {
          if (isPlaybackActiveRef.current) playChunk(index + 1);
        }, 300);
      }
    }
  }, [chunks, onChunkChange, onComplete, onError, prefetchLookahead]);

  /**
   * Bắt đầu phát (từ câu chỉ định hoặc câu hiện tại / câu 0)
   */
  const play = useCallback(async (startIndex?: number) => {
    isPlaybackActiveRef.current = true;
    const targetIndex = startIndex !== undefined 
      ? startIndex 
      : (currentChunkIndex >= 0 ? currentChunkIndex : 0);
    
    await playChunk(targetIndex);
  }, [currentChunkIndex, playChunk]);

  /**
   * Tạm dừng phát
   */
  const pause = useCallback(() => {
    isPlaybackActiveRef.current = false;
    setIsPlaying(false);
    setIsLoading(false);
    if (audioElementRef.current) {
      audioElementRef.current.pause();
    }
  }, []);

  /**
   * Tiếp tục phát câu hiện tại
   */
  const resume = useCallback(async () => {
    if (currentChunkIndex < 0) {
      await play(0);
      return;
    }
    const audio = audioElementRef.current;
    if (audio && audio.src && !audio.ended) {
      isPlaybackActiveRef.current = true;
      try {
        await audio.play();
        setIsPlaying(true);
      } catch {
        await playChunk(currentChunkIndex);
      }
    } else {
      await play(currentChunkIndex);
    }
  }, [currentChunkIndex, play, playChunk]);

  /**
   * Đảo trạng thái phát / tạm dừng
   */
  const togglePlay = useCallback(() => {
    if (isPlaying) {
      pause();
    } else {
      resume();
    }
  }, [isPlaying, pause, resume]);

  /**
   * Dừng hẳn và reset
   */
  const stop = useCallback(() => {
    isPlaybackActiveRef.current = false;
    setIsPlaying(false);
    setIsLoading(false);
    setCurrentChunkIndex(-1);
    currentIndexRef.current = -1;
    if (audioElementRef.current) {
      audioElementRef.current.pause();
      audioElementRef.current.currentTime = 0;
      audioElementRef.current.onended = null;
      audioElementRef.current.onerror = null;
    }
  }, []);

  /**
   * Nhảy trực tiếp tới một câu bất kỳ (Karaoke interactive click)
   */
  const seekToChunk = useCallback(async (index: number) => {
    if (index < 0 || index >= chunks.length) return;
    isPlaybackActiveRef.current = true;
    await playChunk(index);
  }, [chunks.length, playChunk]);

  /**
   * Chuyển sang câu tiếp theo
   */
  const skipNext = useCallback(async () => {
    const nextIdx = currentChunkIndex + 1;
    if (nextIdx < chunks.length) {
      await seekToChunk(nextIdx);
    }
  }, [currentChunkIndex, chunks.length, seekToChunk]);

  /**
   * Lùi về câu trước đó
   */
  const skipPrev = useCallback(async () => {
    const prevIdx = Math.max(0, currentChunkIndex - 1);
    await seekToChunk(prevIdx);
  }, [currentChunkIndex, seekToChunk]);

  /**
   * Thay đổi giọng đọc (Hoài My / Nam Minh)
   */
  const setVoiceId = useCallback((newVoice: string) => {
    const normalized = normalizeEdgeVoiceId(newVoice);
    setVoiceIdState(normalized);
    voiceIdRef.current = normalized;
    if (isPlaybackActiveRef.current && currentIndexRef.current >= 0) {
      // Tiếp tục phát câu hiện tại với giọng mới
      playChunk(currentIndexRef.current);
    }
  }, [playChunk]);

  /**
   * Thay đổi tốc độ đọc
   */
  const setPlaybackRate = useCallback((rate: number) => {
    setPlaybackRateState(rate);
    playbackRateRef.current = rate;
    if (audioElementRef.current) {
      audioElementRef.current.playbackRate = rate;
    }
  }, []);

  // Tính phần trăm tiến độ đọc (0 - 100%)
  const progress = useMemo(() => {
    if (chunks.length === 0 || currentChunkIndex < 0) return 0;
    return Math.round(((currentChunkIndex + 1) / chunks.length) * 100);
  }, [chunks.length, currentChunkIndex]);

  const currentChunk = currentChunkIndex >= 0 && currentChunkIndex < chunks.length 
    ? chunks[currentChunkIndex] 
    : null;

  return {
    chunks,
    currentChunkIndex,
    currentChunk,
    isPlaying,
    isLoading,
    playbackRate,
    voiceId,
    progress,
    bufferedIndices,
    error,
    play,
    pause,
    resume,
    togglePlay,
    stop,
    seekToChunk,
    skipNext,
    skipPrev,
    setVoiceId,
    setPlaybackRate,
  };
}
