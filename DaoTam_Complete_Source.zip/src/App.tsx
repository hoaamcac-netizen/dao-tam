import React, { useState, useEffect, useMemo } from 'react';
import { SAMPLE_NOVELS } from './data/novels';
import { 
  Novel, 
  Chapter, 
  ReaderSettings, 
  ReadingProgress, 
  UserProfile, 
  TopUpRequest, 
  MainCategory, 
  NovelSubmission,
  SubmissionChapterDraft,
  GenreItem,
  UserRole,
  WithdrawalRequest,
  NovelReport
} from './types';
import { getStoredGenres, saveGenres, createGenreItem } from './data/genres';
import { Header } from './components/Header';
import { NovelCard } from './components/NovelCard';
import { NovelDetail } from './components/NovelDetail';
import { ChapterReader } from './components/ChapterReader';
import { AudioPlayerBar } from './components/AudioPlayerBar';
import { AccountModal } from './components/AccountModal';
import { TopUpModal } from './components/TopUpModal';
import { VipPurchaseModal } from './components/VipPurchaseModal';
import { AdminDashboardModal } from './components/AdminDashboardModal';
import { ArchitectureGuideModal } from './components/ArchitectureGuideModal';
import { SubmitNovelModal } from './components/SubmitNovelModal';
import { Top10HotSidebar } from './components/Top10HotSidebar';
import { HotGenresSection } from './components/HotGenresSection';
import { calculateChapterVip } from './utils/rulesAndVoices';
import { DaoTamLogo } from './components/DaoTamLogo';
import { VipPolicyModal } from './components/VipPolicyModal';
import { EditNovelModal } from './components/EditNovelModal';
import { DailyRewardModal } from './components/DailyRewardModal';
import { NominateNovelModal } from './components/NominateNovelModal';
import { TopNominatedSection } from './components/TopNominatedSection';
import { AuthorDashboardModal } from './components/AuthorDashboardModal';
import { EditProfileModal } from './components/EditProfileModal';
import { RegisterCreatorModal } from './components/RegisterCreatorModal';
import { ReportNovelModal } from './components/ReportNovelModal';
import { CreatorProfile, CreatorProfileData } from './components/CreatorProfile';
import { DonateModal } from './components/DonateModal';
import { AuthModal } from './components/AuthModal';
import { unlockVipItemOnServer } from './services/vipSecurityService';
import { 
  loginWithGoogle, 
  logoutUser, 
  syncUserProfile, 
  updateUserState, 
  fetchNovelsFromFirestore, 
  saveNovelToFirestore, 
  seedNovelsIfEmpty, 
  deleteNovelFromFirestore, 
  toggleHideNovelInFirestore,
  createTopUpRequestInFirestore,
  fetchTopUpRequestsFromFirestore,
  updateTopUpRequestStatusInFirestore,
  submitNovelSubmissionToFirestore,
  fetchNovelSubmissionsFromFirestore,
  updateNovelSubmissionStatusInFirestore,
  submitApplicationToFirestore,
  fetchCreatorApplicationsFromFirestore,
  createWithdrawalRequestInFirestore,
  fetchWithdrawalRequestsFromFirestore,
  updateWithdrawalRequestStatusInFirestore,
  submitNovelReportToFirestore,
  fetchNovelReportsFromFirestore,
  updateNovelReportStatusInFirestore,
  followCreatorInFirestore,
  fetchUserProfileById,
  fetchCreatorByDisplayName
} from './firebase/services';
import { auth, checkIsAdmin } from './firebase/config';
import { onAuthStateChanged } from 'firebase/auth';
import { 
  FileCode2, 
  Sparkles, 
  BookOpen, 
  CheckCircle2, 
  Clock, 
  Bookmark, 
  Flame, 
  Coins, 
  ShieldCheck, 
  Layers, 
  BookPlus, 
  UserCheck 
} from 'lucide-react';
import { AuthProvider, useAuth, GUEST_USER } from './contexts/AuthContext';
import { AudioProvider, useAudio } from './contexts/AudioContext';

function DaoTamApp() {
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('dao_tam_theme') as 'dark' | 'light') || 'dark';
  });
  const [currentTab, setCurrentTab] = useState<'home' | 'completed' | 'latest'>('home');
  const [selectedMainCategory, setSelectedMainCategory] = useState<'all' | MainCategory>('all');
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedNovel, setSelectedNovel] = useState<Novel | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<Chapter | null>(null);

  // Dynamic Hot Genres State (Persistent & extensible)
  const [genres, setGenres] = useState<GenreItem[]>(() => getStoredGenres());

  // Dynamic Novels State (Supports batch chapter publishing & submissions)
  const [novels, setNovels] = useState<Novel[]>(() => {
    const saved = localStorage.getItem('dao_tam_novels');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return SAMPLE_NOVELS;
  });

  // Novel Submissions Queue: Khởi tạo rỗng, đồng bộ Firestore thực
  const [novelSubmissions, setNovelSubmissions] = useState<NovelSubmission[]>([]);

  // Modals state
  const [isXmlModalOpen, setIsXmlModalOpen] = useState(false);
  const [isAccountModalOpen, setIsAccountModalOpen] = useState(false);
  const [isTopUpOpen, setIsTopUpOpen] = useState(false);
  const [isVipPurchaseOpen, setIsVipPurchaseOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isArchitectureOpen, setIsArchitectureOpen] = useState(false);
  const [isSubmitNovelOpen, setIsSubmitNovelOpen] = useState(false);
  const [isAudioBarOpen, setIsAudioBarOpen] = useState(false);
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [isVipPolicyOpen, setIsVipPolicyOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');

  // Edit Novel Modal State (Admin)
  const [editingNovel, setEditingNovel] = useState<Novel | null>(null);
  const [isEditNovelOpen, setIsEditNovelOpen] = useState(false);

  // Daily Reward (5 flowers) & Story Nomination Modals
  const [isDailyRewardOpen, setIsDailyRewardOpen] = useState(false);
  const [isNominateOpen, setIsNominateOpen] = useState(false);
  const [nominatingNovel, setNominatingNovel] = useState<Novel | null>(null);

  // Novel Report Violations: Khởi tạo rỗng, đồng bộ Firestore thực
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [reportingNovel, setReportingNovel] = useState<Novel | null>(null);
  const [novelReports, setNovelReports] = useState<NovelReport[]>([]);

  // Dedicated Reader Profile Editor & Creator Registration Modals
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [isRegisterCreatorOpen, setIsRegisterCreatorOpen] = useState(false);

  // Author & Editor Multi-Novel Studio & 4 Stat Cards Showcase (Image 2)
  const [isAuthorShowcaseOpen, setIsAuthorShowcaseOpen] = useState(false);
  const [showcaseAuthorName, setShowcaseAuthorName] = useState<string>('');
  const [showcaseRole, setShowcaseRole] = useState<'author' | 'editor'>('author');

  const handleOpenAuthorShowcase = (name?: string, role: 'author' | 'editor' = 'author') => {
    if (name) {
      setShowcaseAuthorName(name);
      setShowcaseRole(role);
    }
    setIsAuthorShowcaseOpen(true);
  };

  // Dedicated Creator / Author Public Profile State (áp dụng chung Tác giả, Editor và Admin)
  const [selectedCreator, setSelectedCreator] = useState<CreatorProfileData | null>(null);
  const [donatingCreator, setDonatingCreator] = useState<CreatorProfileData | null>(null);
  const [isDonateOpen, setIsDonateOpen] = useState(false);

  // Điều hướng mở Trang Cá Nhân Người Sáng Tác
  const handleSelectCreator = async (creatorNameOrId: string, directCreatorId?: string) => {
    const cleanName = creatorNameOrId.trim();
    if (!cleanName) return;

    // Tìm trong danh sách truyện hiện tại
    const relatedNovel = novels.find((n) => 
      n.author?.toLowerCase().trim() === cleanName.toLowerCase() ||
      n.editor?.toLowerCase().trim() === cleanName.toLowerCase() ||
      (directCreatorId && n.submittedBy?.userId === directCreatorId) ||
      (n.submittedBy && n.submittedBy.userId === cleanName)
    );

    let fetchedUser: UserProfile | null = null;
    const targetUserId = directCreatorId || (relatedNovel?.submittedBy?.userId);
    if (targetUserId) {
      fetchedUser = await fetchUserProfileById(targetUserId);
    }
    if (!fetchedUser) {
      fetchedUser = await fetchCreatorByDisplayName(cleanName);
    }

    const creatorData: CreatorProfileData = {
      id: fetchedUser?.id || targetUserId || `creator-${cleanName}`,
      name: fetchedUser?.displayName || cleanName,
      avatarUrl: fetchedUser?.avatarUrl || (cleanName === user.displayName ? user.avatarUrl : (relatedNovel?.coverImage || undefined)),
      bio: fetchedUser?.bio || (cleanName === user.displayName && user.bio ? user.bio : `Tác giả / Editor tại Đạo Tâm. Cảm ơn quý độc giả đã yêu mến và ủng hộ các tác phẩm!`),
      role: fetchedUser?.role || (relatedNovel?.editor?.toLowerCase() === cleanName.toLowerCase() ? 'editor' : 'author'),
      followers: fetchedUser?.followers || [],
      email: fetchedUser?.email || '',
    };

    setSelectedCreator(creatorData);
    setSelectedNovel(null);
    setSelectedChapter(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Theo dõi / Hủy theo dõi Creator
  const handleFollowCreator = async (creatorKey: string, shouldFollow: boolean) => {
    if (!user.isLoggedIn || user.id === 'guest') {
      setIsAccountModalOpen(true);
      return;
    }

    const currentFollowing = user.followingCreators || [];
    const nextFollowing = shouldFollow
      ? [...new Set([...currentFollowing, creatorKey])]
      : currentFollowing.filter((id) => id !== creatorKey);

    setUser((prev) => ({
      ...prev,
      followingCreators: nextFollowing,
    }));

    if (selectedCreator) {
      const currentFollowers = selectedCreator.followers || [];
      const nextFollowers = shouldFollow
        ? [...new Set([...currentFollowers, user.id])]
        : currentFollowers.filter((id) => id !== user.id);
      setSelectedCreator((prev) => (prev ? { ...prev, followers: nextFollowers } : null));
    }

    try {
      await followCreatorInFirestore(user.id, creatorKey, shouldFollow);
    } catch (err) {
      console.warn('Lỗi đồng bộ Firestore theo dõi tác giả:', err);
    }
  };

  // Xử lý gửi tặng Xu / Donate cho tác giả
  const handleDonateXu = async (creator: CreatorProfileData, amountXu: number, donateMsg: string): Promise<boolean> => {
    if (!user.isLoggedIn || user.id === 'guest') {
      setIsAccountModalOpen(true);
      return false;
    }
    if (user.xuBalance < amountXu) {
      setIsTopUpOpen(true);
      return false;
    }

    const nextXu = Math.max(0, user.xuBalance - amountXu);
    setUser((prev) => ({
      ...prev,
      xuBalance: nextXu,
      notifications: [
        {
          id: `donate-${Date.now()}`,
          title: `🎁 Đã Ủng Hộ ${amountXu} Xu`,
          message: `Bạn vừa gửi tặng ${amountXu} Xu cho tác giả ${creator.name}. Lời nhắn: "${donateMsg}"`,
          type: 'payout',
          createdAt: Date.now(),
          isRead: false,
        },
        ...(prev.notifications || []),
      ],
    }));

    try {
      await updateUserState(user.id, { xuBalance: nextXu });
      if (creator.id && !creator.id.startsWith('creator-')) {
        const creatorUser = await fetchUserProfileById(creator.id);
        if (creatorUser) {
          const updatedEarned = (creatorUser.authorEarnedXu || 0) + amountXu;
          await updateUserState(creator.id, { authorEarnedXu: updatedEarned });
        }
      }
      return true;
    } catch (err) {
      console.error('Lỗi lưu giao dịch donate lên Firestore:', err);
      return true;
    }
  };

  // Đăng xuất tài khoản
  const handleLogout = async () => {
    try {
      await logoutUser();
      setUser(GUEST_USER);
      setSelectedCreator(null);
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  // Purchasing targets
  const [purchasingTarget, setPurchasingTarget] = useState<{ novel: Novel; chapter: Chapter } | null>(null);

  // Top-Up Requests Queue: Khởi tạo rỗng, đồng bộ Firestore thực
  const [topUpRequests, setTopUpRequests] = useState<TopUpRequest[]>([]);

  // User Profile từ AuthContext (Đồng bộ Firebase thời gian thực, không cache ảo LocalStorage)
  const { user, setUser } = useAuth();

  // Author Withdrawal Requests: Khởi tạo rỗng, đồng bộ Firestore thực
  const [withdrawalRequests, setWithdrawalRequests] = useState<WithdrawalRequest[]>([]);

  // Payout revenue share settings (configured by Admin)
  // Quy chuẩn: Tác giả sáng tác 95%, Editor đăng độc quyền 90%, Editor không độc quyền 70%
  const [royaltyConfig, setRoyaltyConfig] = useState({
    authorRate: 95,
    editorRate: 70,
    exclusiveRate: 90,
  });

  // Reader Settings with Vietnamese voice and 100% Vietnamese font
  const [readerSettings, setReaderSettings] = useState<ReaderSettings>({
    fontSize: 19,
    lineHeight: 1.85,
    fontFamily: 'vietnam', // Be Vietnam Pro (100% Vietnamese glyph support)
    theme: 'dark',
    autoScroll: false,
    autoNextChapter: true, // Tự động chuyển chương khi nghe hết
    voiceSpeed: 1.0,
    selectedVoiceId: 'vi-VN-HoaiMyNeural', // Hoài My (Edge Neural)
    autoHighlight: true,
    audioEngine: 'native', // Mặc định siêu tốc 0s trễ, mượt mà tức thì
  });

  // Khi tài khoản đăng nhập có quyền Admin, tự động khởi tạo dữ liệu mẫu nếu Firestore rỗng
  useEffect(() => {
    if (user.role === 'admin') {
      seedNovelsIfEmpty(SAMPLE_NOVELS)
        .then(() => fetchNovelsFromFirestore())
        .then((remoteNovels) => {
          if (remoteNovels && remoteNovels.length > 0) {
            setNovels(remoteNovels);
          }
        })
        .catch((seedErr) => {
          console.warn('Admin initial seed warning:', seedErr);
        });
    }
  }, [user.role]);

  // Đồng bộ thay đổi user state trực tiếp lên Firestore (KHÔNG lưu cache ảo vào localStorage)
  useEffect(() => {
    if (user.isLoggedIn && user.id && user.id !== 'guest') {
      updateUserState(user.id, {
        xuBalance: user.xuBalance,
        flowerBalance: user.flowerBalance,
        lastDailyRewardDate: user.lastDailyRewardDate,
        lastDailyRewardTimestamp: user.lastDailyRewardTimestamp,
        unlockedChapters: user.unlockedChapters,
        unlockedFullBooks: user.unlockedFullBooks,
        readingHistory: user.readingHistory,
        displayName: user.displayName,
        avatarUrl: user.avatarUrl,
      }).catch((err) => console.warn('Could not sync user state to Firestore:', err));
    }
  }, [user]);

  // Fetch live novels from Firestore on startup
  useEffect(() => {
    let isMounted = true;
    async function loadNovels() {
      try {
        const remoteNovels = await fetchNovelsFromFirestore();
        if (remoteNovels && remoteNovels.length > 0 && isMounted) {
          setNovels(remoteNovels);
        }
      } catch (err) {
        console.warn('Firestore novels load warning:', err);
      }
    }
    loadNovels();
    return () => {
      isMounted = false;
    };
  }, []);

  // ==========================================================================
  // PHÂN QUYỀN TRUY XUẤT DỮ LIỆU NGHIÊM NGẶT (ROLE-BASED FETCHING)
  // ==========================================================================
  useEffect(() => {
    let isMounted = true;

    // 1. NẾU user.role === 'admin': Tải toàn bộ danh sách quản trị hệ thống từ Firestore
    if (user.role === 'admin') {
      const loadAdminData = async () => {
        try {
          const [topups, subs, withdrawals, reports] = await Promise.all([
            fetchTopUpRequestsFromFirestore(),
            fetchNovelSubmissionsFromFirestore(),
            fetchWithdrawalRequestsFromFirestore(),
            fetchNovelReportsFromFirestore(),
          ]);
          if (isMounted) {
            setTopUpRequests(topups);
            setNovelSubmissions(subs);
            setWithdrawalRequests(withdrawals);
            setNovelReports(reports);
          }
        } catch (err) {
          console.warn('Lỗi tải dữ liệu Quản trị viên từ Firestore:', err);
        }
      };
      loadAdminData();
    }
    // 2. NẾU user.role === 'author': CHỈ fetch các bản thảo và lệnh rút tiền CỦA CHÍNH TÁC GIẢ ĐÓ
    else if (user.role === 'author' && user.id && user.id !== 'guest') {
      const loadAuthorData = async () => {
        try {
          const [authorSubs, authorWithdrawals] = await Promise.all([
            fetchNovelSubmissionsFromFirestore(user.id),
            fetchWithdrawalRequestsFromFirestore(user.id),
          ]);
          if (isMounted) {
            setNovelSubmissions(authorSubs);
            setWithdrawalRequests(authorWithdrawals);
            // Đảm bảo dữ liệu quản trị Admin hoàn toàn rỗng đối với Tác giả
            setTopUpRequests([]);
            setNovelReports([]);
          }
        } catch (err) {
          console.warn('Lỗi tải dữ liệu Tác giả từ Firestore:', err);
        }
      };
      loadAuthorData();
    }
    // 3. Độc giả thường (reader): Tuyệt đối KHÔNG kích hoạt các hàm fetch dữ liệu nhạy cảm này
    else {
      setTopUpRequests([]);
      setNovelSubmissions([]);
      setWithdrawalRequests([]);
      setNovelReports([]);
    }

    return () => {
      isMounted = false;
    };
  }, [user.role, user.id]);

  useEffect(() => {
    localStorage.setItem('dao_tam_novels', JSON.stringify(novels));
  }, [novels]);

  // Persist dynamic genres
  useEffect(() => {
    saveGenres(genres);
  }, [genres]);

  // Handle adding custom genre on the fly
  const handleAddNewGenre = (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    const existing = genres.find((g) => g.name.toLowerCase() === trimmed.toLowerCase());
    if (existing) {
      setSelectedGenre(existing.name);
      return;
    }
    const newGenre = createGenreItem(trimmed);
    const updated = [newGenre, ...genres];
    setGenres(updated);
    saveGenres(updated);
    setSelectedGenre(newGenre.name);
  };

  // Sync theme
  useEffect(() => {
    localStorage.setItem('dao_tam_theme', theme);
    if (theme === 'light') {
      document.documentElement.classList.add('light');
      document.documentElement.classList.remove('dark');
    } else {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    }
  }, [theme]);

  // DAILY REWARD (5 FLOWERS) - Chỉ dành cho độc giả đăng nhập Gmail, sau 24h hôm sau mới nhận tiếp
  const REWARD_COOLDOWN_MS = 24 * 60 * 60 * 1000;
  const isGmailLoggedIn = Boolean(user.isLoggedIn && user.email && user.id !== 'guest');
  const lastRewardTime = user.lastDailyRewardTimestamp || 0;
  const canClaimDailyReward = isGmailLoggedIn && (!lastRewardTime || Date.now() - lastRewardTime >= REWARD_COOLDOWN_MS);

  // Chỉ tự động bật popup mời điểm danh KHI đã đăng nhập Gmail và đã đủ 24h
  useEffect(() => {
    if (isGmailLoggedIn && canClaimDailyReward) {
      const promptedKey = `daotam_reward_prompted_${user.id}_${Math.floor(Date.now() / (3600000 * 12))}`;
      const hasPrompted = sessionStorage.getItem(promptedKey);
      if (!hasPrompted) {
        const timer = setTimeout(() => {
          setIsDailyRewardOpen(true);
          sessionStorage.setItem(promptedKey, 'true');
        }, 1000);
        return () => clearTimeout(timer);
      }
    }
  }, [isGmailLoggedIn, canClaimDailyReward, user.id]);

  // Xử lý điểm danh nhận 5 hoa
  const handleClaimDailyFlowers = () => {
    if (!isGmailLoggedIn) {
      alert('Vui lòng đăng nhập tài khoản Gmail để điểm danh nhận hoa!');
      return;
    }
    const now = Date.now();
    if (user.lastDailyRewardTimestamp && now - user.lastDailyRewardTimestamp < REWARD_COOLDOWN_MS) {
      alert('Bạn vừa mới điểm danh! Vui lòng quay lại sau 24 giờ kể từ lần trước.');
      return;
    }

    setUser((prev) => {
      const updated: UserProfile = {
        ...prev,
        flowerBalance: (prev.flowerBalance || 0) + 5,
        lastDailyRewardTimestamp: now,
        lastDailyRewardDate: new Date(now).toISOString(),
      };
      if (prev.isLoggedIn && prev.id && prev.id !== 'guest') {
        updateUserState(prev.id, {
          flowerBalance: updated.flowerBalance,
          lastDailyRewardTimestamp: now,
          lastDailyRewardDate: updated.lastDailyRewardDate,
        }).catch(() => {});
      }
      return updated;
    });
  };

  // Handle nominating flowers to a novel (Admin has unlimited flowers)
  const handleNominateNovel = (novelId: string, flowerAmount: number) => {
    const isAdmin = user.role === 'admin';

    // Deduct flowers if not admin
    if (!isAdmin) {
      if ((user.flowerBalance || 0) < flowerAmount) return;
      setUser((prev) => {
        const updated: UserProfile = {
          ...prev,
          flowerBalance: Math.max(0, (prev.flowerBalance || 0) - flowerAmount),
        };
        if (prev.isLoggedIn && prev.id && prev.id !== 'guest') {
          updateUserState(prev.id, { flowerBalance: updated.flowerBalance }).catch(() => {});
        }
        return updated;
      });
    }

    // Add flowers to the novel
    setNovels((prev) => {
      const updatedNovels = prev.map((n) => {
        if (n.id === novelId) {
          const updated = {
            ...n,
            flowerCount: (n.flowerCount || 0) + flowerAmount,
          };
          saveNovelToFirestore(updated).catch((err) =>
            console.warn('Could not sync flower count to Firestore:', err)
          );
          return updated;
        }
        return n;
      });
      localStorage.setItem('dao_tam_novels', JSON.stringify(updatedNovels));
      return updatedNovels;
    });

    // Update selected novel if viewing
    if (selectedNovel && selectedNovel.id === novelId) {
      setSelectedNovel((prev) =>
        prev ? { ...prev, flowerCount: (prev.flowerCount || 0) + flowerAmount } : null
      );
    }
  };

  // Toggle Role between 3 roles: admin -> author -> reader -> admin
  const handleToggleRole = () => {
    setUser((prev) => {
      const nextRole: UserRole = prev.role === 'admin' ? 'author' : prev.role === 'author' ? 'reader' : 'admin';
      return {
        ...prev,
        role: nextRole,
      };
    });
  };

  const handleSelectRole = (role: UserRole) => {
    setUser((prev) => ({
      ...prev,
      role,
    }));
  };

  // Profile update handler (avatar, display name, bio, and mandatory creator info: facebook, phone, bank info)
  const handleUpdateProfile = (
    name: string, 
    avatarUrl: string,
    extra?: {
      bio?: string;
      facebookUrl?: string;
      phoneNumber?: string;
      bankInfo?: {
        bankName: string;
        accountNumber: string;
        accountHolder: string;
      };
    }
  ) => {
    setUser((prev) => {
      const updatedUser: UserProfile = {
        ...prev,
        displayName: name,
        avatarUrl,
        bio: extra?.bio !== undefined ? extra.bio : prev.bio,
        facebookUrl: extra?.facebookUrl !== undefined ? extra.facebookUrl : prev.facebookUrl,
        phoneNumber: extra?.phoneNumber !== undefined ? extra.phoneNumber : prev.phoneNumber,
        bankInfo: extra?.bankInfo !== undefined ? extra.bankInfo : prev.bankInfo,
      };

      if (prev.isLoggedIn && prev.id && prev.id !== 'guest') {
        updateUserState(prev.id, {
          displayName: name,
          avatarUrl,
          bio: updatedUser.bio,
          facebookUrl: updatedUser.facebookUrl,
          phoneNumber: updatedUser.phoneNumber,
          bankInfo: updatedUser.bankInfo,
        }).catch((err) => console.warn('Could not sync user profile to Firestore:', err));
      }

      return updatedUser;
    });

    // Cập nhật ngay lập tức giao diện Trang cá nhân (hình 4)
    setSelectedCreator((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        name,
        avatarUrl,
        bio: extra?.bio !== undefined ? extra.bio : prev.bio,
      };
    });
  };

  // Reading Progress auto-save
  const handleSaveProgress = (progress: ReadingProgress) => {
    setUser((prev) => {
      const filtered = prev.readingHistory.filter((item) => item.novelId !== progress.novelId);
      return {
        ...prev,
        readingHistory: [progress, ...filtered],
      };
    });
  };

  const handleToggleBookmark = (novelId: string) => {
    setUser((prev) => {
      const exists = prev.bookmarks.includes(novelId);
      return {
        ...prev,
        bookmarks: exists
          ? prev.bookmarks.filter((id) => id !== novelId)
          : [...prev.bookmarks, novelId],
      };
    });
  };

  // Top-Up Request Handler: Lưu thẳng vào collection topup_requests
  const handleSubmitTopUp = async (reqData: Omit<TopUpRequest, 'id' | 'createdAt' | 'status'>) => {
    try {
      const created = await createTopUpRequestInFirestore(reqData);
      if (created) {
        setTopUpRequests((prev) => [created, ...prev.filter((r) => r.id !== created.id)]);
      }
    } catch (err) {
      console.error('Lỗi gửi yêu cầu nạp tiền lên Firestore:', err);
      alert('Không thể gửi yêu cầu nạp tiền lên máy chủ. Vui lòng thử lại!');
    }
  };

  // Admin Approval Handler: Duyệt trên Firestore và cộng Xu chính thức vào tài khoản
  const handleApproveTopUp = async (requestId: string) => {
    const req = topUpRequests.find((r) => r.id === requestId);
    if (!req) return;

    try {
      await updateTopUpRequestStatusInFirestore(requestId, 'approved');
      setTopUpRequests((prev) =>
        prev.map((r) => (r.id === requestId ? { ...r, status: 'approved', approvedAt: Date.now() } : r))
      );

      // Cập nhật số dư người nạp nếu chính là tài khoản đang đăng nhập
      if (user.id === req.userId) {
        const nextXu = user.xuBalance + req.xuAmount;
        setUser((u) => {
          const updatedUser: UserProfile = {
            ...u,
            xuBalance: nextXu,
            purchases: [
              {
                id: `topup-${Date.now()}`,
                novelId: 'system-topup',
                novelTitle: `Nạp Xu (Admin Duyệt - ${req.transferCode})`,
                type: 'full_book',
                pricePaid: req.xuAmount,
                purchasedAt: Date.now(),
              },
              ...u.purchases,
            ],
            notifications: [
              {
                id: `notif-${Date.now()}`,
                title: '✅ Nạp Xu Đã Được Phê Duyệt',
                message: `Yêu cầu nạp ${req.amountVnd.toLocaleString('vi-VN')}đ (${req.xuAmount} Xu) đã được Admin xác nhận. Số dư ví hiện tại là ${nextXu} Xu.`,
                type: 'topup',
                createdAt: Date.now(),
                isRead: false,
              },
              ...(u.notifications || []),
            ],
          };
          updateUserState(u.id, { xuBalance: nextXu }).catch(() => {});
          return updatedUser;
        });
      }
    } catch (err) {
      console.error('Lỗi duyệt nạp tiền trên Firestore:', err);
    }
  };

  const handleRejectTopUp = async (requestId: string) => {
    try {
      await updateTopUpRequestStatusInFirestore(requestId, 'rejected');
      setTopUpRequests((prev) =>
        prev.map((r) => (r.id === requestId ? { ...r, status: 'rejected' } : r))
      );
    } catch (err) {
      console.error('Lỗi từ chối nạp tiền trên Firestore:', err);
    }
  };

  // Author creates a withdrawal request: Lưu thẳng vào collection withdrawal_requests
  const handleCreateWithdrawal = async (data: {
    amountXu: number;
    amountVnd: number;
    bankName: string;
    accountNumber: string;
    accountHolder: string;
    note?: string;
  }) => {
    const currentEarned = user.authorEarnedXu || 0;
    const remaining = Math.max(0, currentEarned - data.amountXu);

    try {
      const created = await createWithdrawalRequestInFirestore({
        authorId: user.id || 'usr-author',
        authorName: user.displayName || 'Tác giả',
        authorEmail: user.email || '',
        amountXu: data.amountXu,
        amountVnd: data.amountVnd,
        remainingXu: remaining,
        bankName: data.bankName,
        accountNumber: data.accountNumber,
        accountHolder: data.accountHolder,
        note: data.note,
      });

      if (created) {
        setWithdrawalRequests((prev) => [created, ...prev.filter((w) => w.id !== created.id)]);
      }

      setUser((prev) => {
        const updated: UserProfile = {
          ...prev,
          authorEarnedXu: remaining,
          bankInfo: {
            bankName: data.bankName,
            accountNumber: data.accountNumber,
            accountHolder: data.accountHolder,
          },
          notifications: [
            {
              id: `notif-${Date.now()}`,
              title: '⏳ Đã Gửi Yêu Cầu Rút Tiền',
              message: `Yêu cầu rút ${data.amountXu} xu (${data.amountVnd.toLocaleString('vi-VN')}đ) về STK ${data.bankName} - ${data.accountNumber} (${data.accountHolder}) đã được lưu trên máy chủ và gửi tới Ban Quản Trị. Số dư xu còn lại: ${remaining} xu.`,
              type: 'payout',
              createdAt: Date.now(),
              isRead: false,
            },
            ...(prev.notifications || []),
          ],
        };
        if (prev.isLoggedIn && prev.id && prev.id !== 'guest') {
          updateUserState(prev.id, {
            authorEarnedXu: remaining,
            bankInfo: updated.bankInfo,
          }).catch(() => {});
        }
        return updated;
      });
    } catch (err) {
      console.error('Lỗi tạo yêu cầu rút tiền:', err);
      alert('Không thể gửi yêu cầu rút tiền lên máy chủ. Vui lòng thử lại!');
    }
  };

  // Admin approves withdrawal payout and records in Firestore
  const handleApproveWithdrawal = async (requestId: string) => {
    const req = withdrawalRequests.find((r) => r.id === requestId);
    if (!req) return;

    try {
      await updateWithdrawalRequestStatusInFirestore(requestId, 'approved');
      setWithdrawalRequests((prev) =>
        prev.map((r) => (r.id === requestId ? { ...r, status: 'approved', approvedAt: Date.now() } : r))
      );

      if (req.authorId === user.id) {
        setUser((prev) => ({
          ...prev,
          notifications: [
            {
              id: `notif-${Date.now()}`,
              title: '✅ Nhuận Bút Đã Được Thanh Toán Thành Công!',
              message: `Admin đã đối soát và chuyển khoản ${req.amountVnd.toLocaleString('vi-VN')}đ (${req.amountXu} xu) về tài khoản ${req.bankName} - ${req.accountNumber} (${req.accountHolder}). Vui lòng kiểm tra biến động số dư ngân hàng!`,
              type: 'payout',
              createdAt: Date.now(),
              isRead: false,
            },
            ...(prev.notifications || []),
          ],
        }));
      }
    } catch (err) {
      console.error('Lỗi duyệt rút tiền:', err);
    }
  };

  // Admin rejects withdrawal payout and refunds Xu in Firestore
  const handleRejectWithdrawal = async (requestId: string, reason?: string) => {
    const req = withdrawalRequests.find((r) => r.id === requestId);
    if (!req) return;

    try {
      await updateWithdrawalRequestStatusInFirestore(requestId, 'rejected', reason);
      setWithdrawalRequests((prev) =>
        prev.map((r) => (r.id === requestId ? { ...r, status: 'rejected', rejectionReason: reason } : r))
      );

      if (req.authorId === user.id) {
        const refundedEarned = (user.authorEarnedXu || 0) + req.amountXu;
        setUser((prev) => ({
          ...prev,
          authorEarnedXu: refundedEarned,
          notifications: [
            {
              id: `notif-${Date.now()}`,
              title: '❌ Yêu Cầu Rút Nhuận Bút Bị Từ Chối',
              message: `Yêu cầu rút ${req.amountXu} xu bị từ chối.${reason ? ` Lý do: ${reason}` : ''} Toàn bộ ${req.amountXu} xu đã được hoàn trả lại vào ví của bạn.`,
              type: 'payout',
              createdAt: Date.now(),
              isRead: false,
            },
            ...(prev.notifications || []),
          ],
        }));
        updateUserState(user.id, { authorEarnedXu: refundedEarned }).catch(() => {});
      }
    } catch (err) {
      console.error('Lỗi từ chối rút tiền:', err);
    }
  };

  // Author chapter editor & scheduler save handler
  const handleSaveChapterFromAuthor = (novelId: string, chapterData: {
    title: string;
    number: number;
    content: string;
    isVip: boolean;
    priceXu: number;
    scheduledPublishAt?: number;
    status: 'draft' | 'pending' | 'published';
  }) => {
    const newChapter: Chapter = {
      id: `${novelId}-c${chapterData.number}-${Date.now()}`,
      number: chapterData.number,
      title: chapterData.title,
      slug: `chuong-${chapterData.number}`,
      wordCount: chapterData.content.split(/\s+/).filter(Boolean).length,
      publishedDate: new Date().toISOString().split('T')[0],
      isVip: chapterData.isVip,
      priceXu: chapterData.isVip ? chapterData.priceXu : 0,
      content: chapterData.content,
      scheduledPublishAt: chapterData.scheduledPublishAt,
    };

    setNovels((prev) => {
      const updated = prev.map((n) => {
        if (n.id === novelId) {
          const exists = n.chapters.some((c) => c.number === chapterData.number);
          const chapters = exists
            ? n.chapters.map((c) => (c.number === chapterData.number ? { ...c, ...newChapter } : c))
            : [...n.chapters, newChapter].sort((a, b) => a.number - b.number);
          return {
            ...n,
            chapters,
            totalChapters: Math.max(n.totalChapters, chapters.length),
            updatedAt: Date.now(),
            lastUpdated: 'Vừa xong',
          };
        }
        return n;
      });
      localStorage.setItem('dao_tam_novels', JSON.stringify(updated));
      const target = updated.find((n) => n.id === novelId);
      if (target) {
        saveNovelToFirestore(target).catch((err) => console.warn('Could not sync novel to Firestore:', err));
      }
      return updated;
    });

    setUser((prev) => ({
      ...prev,
      notifications: [
        {
          id: `notif-${Date.now()}`,
          title: '📝 Đã Lưu Chương Truyện Mới',
          message: `Chương ${chapterData.number}: "${chapterData.title}" (${chapterData.isVip ? `VIP ${chapterData.priceXu} Xu` : 'Miễn phí'}${chapterData.scheduledPublishAt ? ' • Có hẹn giờ' : ''}) đã được lưu thành công!`,
          type: 'system',
          createdAt: Date.now(),
          isRead: false,
        },
        ...(prev.notifications || []),
      ],
    }));
  };

  // Batch chapter publishing handler
  const handleAddBatchChapters = (novelId: string, newChapters: Chapter[]) => {
    setNovels((prev) =>
      prev.map((n) => {
        if (n.id === novelId) {
          const updatedChapters = [...n.chapters, ...newChapters];
          const newTotal = Math.max(n.totalChapters, updatedChapters.length);
          return {
            ...n,
            chapters: updatedChapters,
            totalChapters: newTotal,
            updatedAt: Date.now(),
            lastUpdated: 'Vừa xong',
          };
        }
        return n;
      })
    );
  };

  // Novel Submission from reader/author handler: Ghi thẳng lên Firestore collection "novel_submissions"
  // và nếu là đơn đăng ký Editor/Tác giả thì ghi thẳng lên "creator_applications"
  const handleSubmitNovelForApproval = async (subData: any) => {
    const submissionPayload = {
      ...subData,
      submittedBy: {
        userId: user.id || 'usr-guest',
        userName: user.displayName || 'Tác giả',
        userEmail: user.email || '',
      },
    };

    try {
      const createdSub = await submitNovelSubmissionToFirestore(submissionPayload);

      // Khi user gửi form đăng ký Editor/Tác giả, gọi hàm ghi thẳng dữ liệu lên collection creator_applications
      if (subData.isCreatorApplication) {
        await submitApplicationToFirestore({
          userId: user.id || 'usr-guest',
          userName: user.displayName || subData.author || 'Tác giả',
          userEmail: user.email || '',
          roleType: subData.publisherRoles?.includes('both') ? 'both' : (subData.publisherRoles?.[0] || 'author'),
          penName: subData.author || user.displayName,
          bankInfo: subData.bankInfo || {
            bankName: '',
            accountNumber: '',
            accountHolder: '',
          },
          sampleNovel: {
            title: subData.title,
            mainCategory: subData.mainCategory,
            categories: subData.categories,
            description: subData.description,
            coverImage: subData.coverImage,
            chapters: subData.chapters,
          },
        });
      }

      if (createdSub) {
        setNovelSubmissions((prev) => [createdSub, ...prev.filter((s) => s.id !== createdSub.id)]);
      }
    } catch (err) {
      console.error('Lỗi gửi bản thảo / đơn đăng ký lên Firestore:', err);
      alert('Không thể lưu bản thảo lên máy chủ. Vui lòng kiểm tra kết nối mạng!');
    }
  };

  // Direct Publish novel by Admin handler: Ghi thẳng vào collection novels
  const handleDirectPublishNovel = async (newNovel: Novel) => {
    setNovels((prev) => [newNovel, ...prev]);
    try {
      await saveNovelToFirestore(newNovel);
    } catch (err) {
      console.warn('Could not save novel to Firestore:', err);
    }
  };

  // Admin approves a novel submission -> converts to a live Novel and updates Firestore
  const handleApproveNovelSubmission = async (submissionId: string) => {
    const sub = novelSubmissions.find((s) => s.id === submissionId);
    if (!sub) return;

    try {
      await updateNovelSubmissionStatusInFirestore(submissionId, 'approved');
      setNovelSubmissions((prev) =>
        prev.map((s) => (s.id === submissionId ? { ...s, status: 'approved' } : s))
      );

      const slug = sub.title
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^\w\s-]/g, '')
        .replace(/\s+/g, '-');

      const novelId = `novel-${Date.now()}`;
      const totalChapters = (sub as any).totalExpectedChapters || 150;

      const draftChaptersList: SubmissionChapterDraft[] = sub.chapters && sub.chapters.length > 0
        ? sub.chapters
        : [
            {
              number: 1,
              title: (sub as any).firstChapterTitle || 'Chương 1',
              content: (sub as any).firstChapterContent || 'Nội dung chương 1...',
              wordCount: 100,
            },
          ];

      const approvedChapters: Chapter[] = draftChaptersList.map((dc) => {
        const { isVip, priceXu } = calculateChapterVip(dc.number, totalChapters);
        return {
          id: `${novelId}-c${dc.number}`,
          number: dc.number,
          title: dc.title,
          slug: `chuong-${dc.number}`,
          wordCount: dc.wordCount || dc.content.split(/\s+/).filter(Boolean).length,
          publishedDate: new Date().toISOString().split('T')[0],
          isVip,
          priceXu,
          content: dc.content,
        };
      });

      const approvedNovel: Novel = {
        id: novelId,
        title: sub.title,
        slug: `${slug}-${novelId}`,
        author: sub.author,
        editor: sub.editor,
        publisherRoles: sub.publisherRoles,
        isExclusive: sub.isExclusive,
        royaltyRate: sub.royaltyRate,
        coverImage: sub.coverImage,
        mainCategory: sub.mainCategory,
        isOriginal: sub.mainCategory === 'truyen-sang-tac',
        status: 'Đang ra',
        publishStatus: 'published',
        isHot: true,
        totalChapters,
        views: 150,
        dailyViews: 150,
        rating: 5.0,
        categories: sub.categories,
        description: sub.description,
        translator: sub.editor || sub.submittedBy.userName,
        updatedAt: Date.now(),
        lastUpdated: 'Vừa duyệt xong',
        hasAudio: true,
        fullBookPriceXu: 120,
        fullBookDiscountPriceXu: 85,
        chapters: approvedChapters,
      };

      setNovels((prev) => [approvedNovel, ...prev]);
      await saveNovelToFirestore(approvedNovel);

      // Nâng cấp role người nộp nếu chính là tài khoản hiện tại
      if (sub.submittedBy?.userId === user.id) {
        setUser((prev) => {
          const nextRole = prev.role === 'admin' ? 'admin' : 'author';
          const updated: UserProfile = {
            ...prev,
            role: nextRole,
            bankInfo: sub.bankInfo || prev.bankInfo,
            notifications: [
              {
                id: `notif-${Date.now()}`,
                title: '🎉 Chúc Mừng! Bạn Đã Trở Thành Tác Giả / Editor!',
                message: `Tác phẩm "${sub.title}" và hồ sơ của bạn đã được Admin DUYỆT thành công. Bạn đã được thăng hạng thành Tác Giả/Editor, mở khóa Bàn Làm Việc Tác Giả, quản lý truyện, thêm chương VIP và bắt đầu nhận Xu nhuận bút khi độc giả mở khóa chương!`,
                type: 'system',
                createdAt: Date.now(),
                isRead: false,
              },
              ...(prev.notifications || []),
            ],
          };
          if (prev.isLoggedIn && prev.id && prev.id !== 'guest') {
            updateUserState(prev.id, {
              role: nextRole,
              bankInfo: updated.bankInfo,
            }).catch(() => {});
          }
          return updated;
        });
      }
    } catch (err) {
      console.error('Lỗi duyệt bản thảo:', err);
    }
  };

  const handleRejectNovelSubmission = async (submissionId: string, reason?: string) => {
    try {
      await updateNovelSubmissionStatusInFirestore(submissionId, 'rejected', reason);
      setNovelSubmissions((prev) =>
        prev.map((s) => (s.id === submissionId ? { ...s, status: 'rejected', rejectionReason: reason } : s))
      );
    } catch (err) {
      console.error('Lỗi từ chối bản thảo:', err);
    }
  };

  // Ẩn hoặc Hiện truyện (Dành cho Quản Trị Viên)
  const handleToggleHideNovel = async (novelId: string) => {
    let nextHiddenState = false;
    setNovels((prev) =>
      prev.map((n) => {
        if (n.id === novelId) {
          nextHiddenState = !n.isHidden;
          return {
            ...n,
            isHidden: nextHiddenState,
            publishStatus: nextHiddenState ? 'hidden' : 'published',
            updatedAt: Date.now(),
          };
        }
        return n;
      })
    );

    if (selectedNovel && selectedNovel.id === novelId) {
      setSelectedNovel((prev) =>
        prev
          ? {
              ...prev,
              isHidden: !prev.isHidden,
              publishStatus: !prev.isHidden ? 'hidden' : 'published',
            }
          : null
      );
    }

    try {
      await toggleHideNovelInFirestore(novelId, nextHiddenState);
    } catch (err) {
      console.warn('Could not toggle hide novel in Firestore:', err);
    }
  };

  // Xóa vĩnh viễn truyện khỏi hệ thống (Dành cho Quản Trị Viên)
  const handleDeleteNovel = async (novelId: string) => {
    setNovels((prev) => prev.filter((n) => n.id !== novelId));
    if (selectedNovel && selectedNovel.id === novelId) {
      setSelectedNovel(null);
      setSelectedChapter(null);
    }
    try {
      await deleteNovelFromFirestore(novelId);
    } catch (err) {
      console.warn('Could not delete novel from Firestore:', err);
    }
  };

  // Mở modal Chỉnh sửa Truyện & Chương (Dành cho Admin)
  const handleOpenEditNovel = (novel: Novel) => {
    setEditingNovel(novel);
    setIsEditNovelOpen(true);
  };

  // Lưu thông tin & danh sách chương sau khi Admin chỉnh sửa
  const handleSaveEditedNovel = async (updatedNovel: Novel) => {
    setNovels((prev) => prev.map((n) => (n.id === updatedNovel.id ? updatedNovel : n)));
    if (selectedNovel && selectedNovel.id === updatedNovel.id) {
      setSelectedNovel(updatedNovel);
    }
    try {
      await saveNovelToFirestore(updatedNovel);
    } catch (err) {
      console.warn('Could not save edited novel to Firestore:', err);
    }
  };

  // Mở modal Báo Cáo Vi Phạm Truyện
  const handleOpenReport = (novel: Novel) => {
    setReportingNovel(novel);
    setIsReportOpen(true);
  };

  // Người dùng gửi báo cáo vi phạm tác phẩm: Lưu thẳng lên Firestore collection "novel_reports"
  const handleSubmitReport = async (report: NovelReport) => {
    try {
      const created = await submitNovelReportToFirestore(report);
      if (created && user.role === 'admin') {
        setNovelReports((prev) => [created, ...prev.filter((r) => r.id !== created.id)]);
      }
      setUser((prev) => ({
        ...prev,
        notifications: [
          {
            id: `notif-${Date.now()}`,
            title: '🚩 Đã Gửi Báo Cáo Vi Phạm',
            message: `Cảm ơn bạn đã báo cáo tác phẩm "${report.novelTitle}". Ban Quản Trị sẽ xác minh và xử lý nghiêm theo quy chế.`,
            type: 'system',
            createdAt: Date.now(),
            isRead: false,
          },
          ...(prev.notifications || []),
        ],
      }));
    } catch (err) {
      console.error('Lỗi gửi báo cáo lên Firestore:', err);
    }
  };

  // Admin xử lý báo cáo vi phạm: Cập nhật Firestore
  const handleResolveReport = async (
    reportId: string, 
    action: 'dismiss' | 'hide_novel' | 'delete_novel' | 'ban_author', 
    novelId: string
  ) => {
    const report = novelReports.find((r) => r.id === reportId);
    if (!report) return;

    try {
      await updateNovelReportStatusInFirestore(reportId, 'resolved', action);
      setNovelReports((prev) =>
        prev.map((r) =>
          r.id === reportId
            ? {
                ...r,
                status: 'resolved',
                adminNotes: action,
              }
            : r
        )
      );

      if (action === 'hide_novel') {
        handleToggleHideNovel(novelId);
      } else if (action === 'delete_novel') {
        handleDeleteNovel(novelId);
      } else if (action === 'ban_author') {
        // Ẩn hoặc xóa tác phẩm vi phạm
        handleToggleHideNovel(novelId);
        // Hủy và từ chối toàn bộ lệnh rút tiền chưa giải ngân của tác giả này
        setWithdrawalRequests((prev) =>
          prev.map((req) => {
            if (req.authorName === report.author || req.authorEmail === user.email) {
              return {
                ...req,
                status: 'rejected',
                rejectionReason: 'Vi phạm bản quyền / 18+ / chính sách - Tịch thu toàn bộ doanh thu tháng & cấm tài khoản vĩnh viễn',
              };
            }
            return req;
          })
        );
        // Nếu chính tài khoản đang đăng nhập là tác giả bị phạt
        if (user.displayName === report.author) {
          setUser((prev) => ({
            ...prev,
            isBanned: true,
            authorEarnedXu: 0,
            notifications: [
              {
                id: `notif-${Date.now()}`,
                title: '🚫 TÀI KHOẢN BỊ KHÓA VĨNH VIỄN DO VI PHẠM',
                message: 'Tài khoản của bạn đã bị cấm vĩnh viễn và mất toàn bộ doanh thu tháng do vi phạm chính sách tác quyền/nội dung theo quyết định của Ban Quản Trị.',
                type: 'system',
                createdAt: Date.now(),
                isRead: false,
              },
              ...(prev.notifications || []),
            ],
          }));
        }
      }
    } catch (err) {
      console.error('Lỗi xử lý báo cáo trên Firestore:', err);
    }
  };

  // VIP Purchase Confirmation (Server-Authoritative VIP & Currency Security)
  // Toàn bộ logic kiểm tra số dư, trừ Xu và chia nhuận bút tác giả được thực thi trên Server an toàn
  const handleConfirmPurchase = async (type: 'chapter' | 'full_book', price: number) => {
    if (!purchasingTarget) return;
    const { novel, chapter } = purchasingTarget;

    try {
      const serverResult = await unlockVipItemOnServer({
        userId: user.id,
        userEmail: user.email,
        userName: user.displayName,
        novelId: novel.id,
        chapterId: chapter?.id,
        chapterNumber: chapter?.number,
        type,
        novelTitle: novel.title,
        authorName: novel.author,
        editorName: novel.editor,
        isExclusive: novel.isExclusive,
      });

      if (!serverResult.success) {
        alert(serverResult.message || serverResult.error || 'Giao dịch mở khóa không thành công.');
        return;
      }

      setUser((prev) => {
        const nextBalance = typeof serverResult.newXuBalance === 'number'
          ? serverResult.newXuBalance
          : Math.max(0, parseFloat((prev.xuBalance - price).toFixed(2)));

        let nextUnlockedChapters = { ...prev.unlockedChapters };
        let nextUnlockedFullBooks = [...prev.unlockedFullBooks];

        if (type === 'full_book') {
          const allChapterIds = novel.chapters.map((c) => c.id);
          const existingChapters = prev.unlockedChapters[novel.id] || [];
          nextUnlockedChapters[novel.id] = Array.from(new Set([...existingChapters, ...allChapterIds]));
          if (!nextUnlockedFullBooks.includes(novel.id)) {
            nextUnlockedFullBooks.push(novel.id);
          }
        } else if (chapter) {
          const existing = prev.unlockedChapters[novel.id] || [];
          nextUnlockedChapters[novel.id] = Array.from(new Set([...existing, chapter.id]));
        }

        const newPurchaseRecord = serverResult.purchaseRecord || {
          id: `p-${Date.now()}`,
          novelId: novel.id,
          novelTitle: novel.title,
          type,
          chapterId: type === 'chapter' ? chapter?.id : undefined,
          chapterNumber: type === 'chapter' ? chapter?.number : undefined,
          pricePaid: price,
          purchasedAt: Date.now(),
        };

        const updatedUser: UserProfile = {
          ...prev,
          xuBalance: nextBalance,
          unlockedFullBooks: nextUnlockedFullBooks,
          unlockedChapters: nextUnlockedChapters,
          purchases: [newPurchaseRecord, ...prev.purchases],
          notifications: [
            {
              id: `notif-${Date.now()}`,
              title: '💎 Mở Khóa VIP Thành Công (Bảo Mật Server)',
              message: `Mở khóa ${type === 'full_book' ? 'trọn bộ' : `chương ${chapter?.number}`} truyện "${novel.title}" thành công qua máy chủ Đạo Tâm. Trừ ${price} Xu. Nhuận bút đã tự động được tính cho Tác giả!`,
              type: 'system',
              createdAt: Date.now(),
              isRead: false,
            },
            ...(prev.notifications || []),
          ],
        };

        if (prev.isLoggedIn && prev.id && prev.id !== 'guest') {
          updateUserState(prev.id, {
            xuBalance: updatedUser.xuBalance,
            unlockedChapters: updatedUser.unlockedChapters,
            unlockedFullBooks: updatedUser.unlockedFullBooks,
          }).catch(() => {});
        }

        return updatedUser;
      });
    } catch (err: any) {
      console.error('Server VIP purchase error:', err);
      alert('Lỗi kết nối máy chủ VIP: ' + (err.message || 'Không thể mở khóa'));
    }
  };

  const handleOpenVipPurchase = (novel: Novel, chapter: Chapter) => {
    setPurchasingTarget({ novel, chapter });
    setIsVipPurchaseOpen(true);
  };

  // STRICT 3 MAIN CATEGORIES FILTERING (Đam Mỹ, Truyện Nam, Truyện Nữ) & SORTING
  const filteredAndSortedNovels = useMemo(() => {
    let list = [...novels];

    // 0. Lọc truyện bị ẩn: Độc giả thông thường KHÔNG nhìn thấy truyện đã ẩn (chỉ Admin mới thấy)
    if (user.role !== 'admin') {
      list = list.filter((n) => !n.isHidden && n.publishStatus !== 'hidden');
    }

    // 1. Phân mục chính: Khi chọn Đam Mỹ, CHỈ hiển thị truyện Đam Mỹ và KHÔNG hiện 2 loại còn lại!
    if (selectedMainCategory !== 'all') {
      list = list.filter((n) => n.mainCategory === selectedMainCategory);
    }

    // 2. Lọc theo Thể Loại Hot được chọn (Cổ Đại, Dị Năng, Tu Tiên, Hệ Thống, Mạt Thế, v.v.)
    if (selectedGenre) {
      list = list.filter((novel) =>
        novel.categories.some((c) => c.toLowerCase().includes(selectedGenre.toLowerCase()))
      );
    }

    // 3. Search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (novel) =>
          novel.title.toLowerCase().includes(q) ||
          novel.author.toLowerCase().includes(q) ||
          (novel.editor && novel.editor.toLowerCase().includes(q)) ||
          novel.categories.some((c) => c.toLowerCase().includes(q))
      );
    }

    // 4. Tab filter & sorting (Hot = theo lượt đọc, Mới cập nhật = thời gian, Hoàn thành = status)
    if (currentTab === 'completed') {
      list = list.filter((n) => n.status === 'Hoàn thành');
    } else if (currentTab === 'latest') {
      list = list.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    } else if (currentTab === 'home') {
      list = list.sort((a, b) => b.views - a.views);
    }

    return list;
  }, [novels, selectedMainCategory, selectedGenre, searchQuery, currentTab, user.role]);

  const handleResumeReading = (novel: Novel, progress: ReadingProgress) => {
    const chapter = novel.chapters.find((c) => c.number === progress.chapterNumber) || novel.chapters[0];
    setSelectedNovel(novel);
    setSelectedChapter(chapter);
  };

  const pendingTopUpCount = topUpRequests.filter((r) => r.status === 'pending').length;
  const pendingSubmissionsCount = novelSubmissions.filter((s) => s.status === 'pending').length;
  const pendingReportsCount = novelReports.filter((r) => r.status === 'pending').length;
  const totalPendingAdminCount = pendingTopUpCount + pendingSubmissionsCount + pendingReportsCount;

  return (
    <div className={`min-h-screen ${theme === 'light' ? 'bg-slate-50 text-slate-800' : 'bg-slate-900 text-slate-200'} font-sans selection:bg-blue-500/20 selection:text-blue-600 transition-colors duration-300`}>
      {/* Top Header with Role Switcher & 3 Main Categories Bar */}
      <Header
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        selectedMainCategory={selectedMainCategory}
        setSelectedMainCategory={setSelectedMainCategory}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        theme={theme}
        setTheme={setTheme}
        onOpenAccount={() => setIsAccountModalOpen(true)}
        onOpenXmlModal={() => setIsXmlModalOpen(true)}
        onOpenTopUp={() => setIsTopUpOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenArchitecture={() => setIsArchitectureOpen(true)}
        onOpenSubmitNovel={() => setIsSubmitNovelOpen(true)}
        onOpenVipPolicy={() => setIsVipPolicyOpen(true)}
        onToggleRole={handleToggleRole}
        onSelectRole={handleSelectRole}
        user={user}
        pendingCount={totalPendingAdminCount}
        onOpenDailyReward={() => setIsDailyRewardOpen(true)}
        hasClaimedToday={!canClaimDailyReward}
        onOpenAuthorShowcase={() => handleOpenAuthorShowcase()}
        onOpenRegisterCreator={() => setIsRegisterCreatorOpen(true)}
        onOpenEditProfile={() => setIsEditProfileOpen(true)}
        onOpenProfile={() => handleSelectCreator(user.displayName, user.id)}
        onOpenInterestedNovels={() => setIsAccountModalOpen(true)}
        onOpenFollowingCreators={() => setIsAccountModalOpen(true)}
        onOpenMyNovels={() => {
          if (user.role === 'admin' || user.role === 'author') {
            handleOpenAuthorShowcase(user.displayName);
          } else {
            setIsSubmitNovelOpen(true);
          }
        }}
        onOpenReadingHistory={() => setIsAccountModalOpen(true)}
        onOpenBookmarks={() => setIsAccountModalOpen(true)}
        onOpenStats={() => {
          if (user.role === 'admin') setIsAdminOpen(true);
          else handleOpenAuthorShowcase(user.displayName);
        }}
        onOpenInfo={() => setIsVipPolicyOpen(true)}
        onOpenChangePassword={() => setIsEditProfileOpen(true)}
        onLogout={handleLogout}
        onLogin={() => {
          setAuthModalMode('login');
          setIsAuthModalOpen(true);
        }}
        onOpenLogin={() => {
          setAuthModalMode('login');
          setIsAuthModalOpen(true);
        }}
        onOpenRegister={() => {
          setAuthModalMode('register');
          setIsAuthModalOpen(true);
        }}
        onHomeClick={() => {
          setSelectedNovel(null);
          setSelectedChapter(null);
          setSelectedCreator(null);
          setSelectedGenre(null);
          setCurrentTab('home');
        }}
      />

      {/* Main Content Area */}
      <main className="pb-24">
        {selectedChapter && selectedNovel ? (
          /* CHAPTER READER SCREEN (KARAOKE TTS + MULTI-VOICE + AUTO NEXT CHAPTER + DRM ANTI-THEFT + VIP LOCK) */
          <ChapterReader
            novel={selectedNovel}
            chapter={selectedChapter}
            readerSettings={readerSettings}
            setReaderSettings={setReaderSettings}
            onSelectChapter={(novel, chapter) => setSelectedChapter(chapter)}
            onBackToNovel={() => setSelectedChapter(null)}
            onSaveProgress={handleSaveProgress}
            user={user}
            onOpenVipPurchase={handleOpenVipPurchase}
            onOpenTopUp={() => setIsTopUpOpen(true)}
            onOpenReport={handleOpenReport}
          />
        ) : selectedNovel ? (
          /* NOVEL DETAIL & DETAILED TOC (COMMENTS & ZERO RECOMMENDATIONS) */
          <NovelDetail
            novel={selectedNovel}
            savedProgress={user.readingHistory.find((h) => h.novelId === selectedNovel.id)}
            isBookmarked={user.bookmarks.includes(selectedNovel.id)}
            onToggleBookmark={handleToggleBookmark}
            onSelectChapter={(novel, chapter) => setSelectedChapter(chapter)}
            onBack={() => setSelectedNovel(null)}
            user={user}
            onOpenVipPurchase={handleOpenVipPurchase}
            onToggleHideNovel={handleToggleHideNovel}
            onDeleteNovel={handleDeleteNovel}
            onOpenEditNovel={handleOpenEditNovel}
            onOpenNominate={(novel) => {
              setNominatingNovel(novel);
              setIsNominateOpen(true);
            }}
            onOpenAuthorShowcase={(authorName) => handleSelectCreator(authorName)}
            onOpenReport={handleOpenReport}
          />
        ) : selectedCreator ? (
          /* TRANG CÁ NHÂN NGƯỜI SÁNG TÁC (ÁP DỤNG CHUNG TÁC GIẢ, EDITOR VÀ ADMIN) */
          <CreatorProfile
            creator={selectedCreator}
            allNovels={novels}
            currentUser={user}
            onBack={() => setSelectedCreator(null)}
            onSelectNovel={(n) => {
              setSelectedCreator(null);
              setSelectedNovel(n);
            }}
            onFollowToggle={handleFollowCreator}
            onOpenDonateModal={(creatorData) => {
              setDonatingCreator(creatorData);
              setIsDonateOpen(true);
            }}
            onSelectCreator={handleSelectCreator}
            onOpenEditProfile={() => setIsEditProfileOpen(true)}
            onOpenSubmitNovel={() => setIsSubmitNovelOpen(true)}
          />
        ) : (
          /* HOME CATALOG SCREEN WITH TOP 10 HOT TRONG NGÀY RIGHT SIDEBAR */
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8">


            {/* Reading Shelf */}
            {user.readingHistory.length > 0 && (
              <div className="mb-10 bg-white dark:bg-slate-800 rounded-2xl p-5 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] dark:shadow-lg dark:shadow-black/40 transition-colors">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-sm uppercase tracking-wider font-bold text-blue-600 dark:text-cyan-400 flex items-center gap-2">
                    <Bookmark className="w-4 h-4" />
                    Tiến Trình Đọc Gần Đây (Đồng bộ tài khoản)
                  </h2>
                  <button
                    onClick={() => setIsAccountModalOpen(true)}
                    className="text-xs text-blue-600 dark:text-cyan-400 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    Xem chi tiết ({user.readingHistory.length}) &rarr;
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {user.readingHistory.slice(0, 3).map((hist) => {
                    const novel = novels.find((n) => n.id === hist.novelId);
                    return (
                      <div
                        key={hist.novelId}
                        onClick={() => {
                          if (novel) handleResumeReading(novel, hist);
                        }}
                        className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50 hover:bg-slate-100 dark:hover:bg-slate-700/50 flex items-center gap-3 cursor-pointer transition-all group"
                      >
                        <img
                          src={hist.novelCover}
                          alt={hist.novelTitle}
                          className="w-11 h-15 object-cover rounded-md flex-shrink-0 shadow-xs"
                        />
                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-xs text-black !text-black group-hover:!text-blue-600 truncate">
                            {hist.novelTitle}
                          </h4>
                          <div className="text-[11px] text-black !text-black font-semibold mt-0.5">
                            Chương {hist.chapterNumber} • Đã đọc {hist.scrollPercentage}%
                          </div>
                          <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden mt-1.5">
                            <div
                              className="h-full bg-gradient-to-r from-blue-600 to-cyan-400 rounded-full"
                              style={{ width: `${hist.scrollPercentage}%` }}
                            />
                          </div>
                        </div>
                        <span className="text-xs font-bold text-blue-600 dark:text-cyan-400 group-hover:translate-x-0.5 transition-transform">
                          &rarr;
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* BẢNG VÀNG ĐỀ CỬ: TOP 12 TRUYỆN ĐƯỢC ĐỀ CỬ NHIỀU NHẤT */}
            <TopNominatedSection
              novels={novels}
              onSelectNovel={(n) => setSelectedNovel(n)}
              onOpenNominate={(n) => {
                setNominatingNovel(n);
                setIsNominateOpen(true);
              }}
              onOpenDailyReward={() => setIsDailyRewardOpen(true)}
              user={user}
              onSelectCreator={handleSelectCreator}
            />

            {/* THỂ LOẠI HOT SECTION */}
            <HotGenresSection
              genres={genres}
              selectedGenre={selectedGenre}
              onSelectGenre={setSelectedGenre}
              onAddNewGenre={handleAddNewGenre}
              canAddGenre={user.role !== 'reader'}
            />

            {/* TWO-COLUMN LAYOUT: MAIN CATALOG + TOP 10 HOT TRONG NGÀY RIGHT SIDEBAR */}
            <div className="flex flex-col lg:flex-row items-start gap-8">
              {/* Left Column: Novels Catalog */}
              <div className="flex-1 min-w-0 w-full">
                {/* Catalog Section Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 mb-6 border-b border-slate-200 dark:border-slate-800">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-blue-600/10 text-blue-600 dark:text-cyan-400 flex items-center justify-center">
                      <Flame className="w-4 h-4" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">
                        {currentTab === 'completed'
                          ? 'Truyện Hoàn Thành'
                          : currentTab === 'latest'
                          ? 'Truyện Mới Cập Nhật'
                          : 'Truyện Hot'}
                        {selectedMainCategory === 'dam-my' && ' • Đam Mỹ'}
                        {selectedMainCategory === 'truyen-nam' && ' • Truyện Nam'}
                        {selectedMainCategory === 'truyen-nu' && ' • Truyện Nữ'}
                        {selectedMainCategory === 'truyen-sang-tac' && ' • Truyện Sáng Tác'}
                        {selectedGenre && ` • ${selectedGenre}`}
                      </h2>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {filteredAndSortedNovels.length} bộ truyện được hiển thị
                      </p>
                    </div>
                  </div>

                  {/* Filter Tabs */}
                  <div className="flex items-center gap-1.5 overflow-x-auto text-xs scrollbar-none">
                    <button
                      onClick={() => setCurrentTab('home')}
                      className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                        currentTab === 'home'
                          ? 'bg-blue-600 text-white shadow-sm'
                          : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-600'
                      }`}
                    >
                      <Flame className="w-3.5 h-3.5" />
                      Truyện Hot
                    </button>
                    <button
                      onClick={() => setCurrentTab('latest')}
                      className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                        currentTab === 'latest'
                          ? 'bg-blue-600 text-white shadow-sm'
                          : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-600'
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5" />
                      Mới cập nhật
                    </button>
                    <button
                      onClick={() => setCurrentTab('completed')}
                      className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                        currentTab === 'completed'
                          ? 'bg-blue-600 text-white shadow-sm'
                          : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-600'
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Truyện Full
                    </button>
                  </div>
                </div>

                {/* Novel Grid */}
                {filteredAndSortedNovels.length === 0 ? (
                  <div className="text-center py-16 bg-[#13141c] rounded-2xl border border-neutral-800 p-8">
                    <BookOpen className="w-10 h-10 text-neutral-600 mx-auto mb-3" />
                    <h3 className="text-neutral-300 font-bold text-sm">Chưa có truyện nào trong phân mục này</h3>
                    <p className="text-xs text-neutral-500 mt-1 mb-4">
                      {user.role !== 'reader'
                        ? 'Bạn có thể là người đầu tiên đăng truyện mới vào danh mục này!'
                        : 'Vui lòng quay lại sau khi ban biên tập cập nhật thêm tác phẩm mới.'}
                    </p>
                    {user.role !== 'reader' && (
                      <button
                        onClick={() => setIsSubmitNovelOpen(true)}
                        className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs cursor-pointer"
                      >
                        + Đăng Truyện Ngay
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-3.5 sm:gap-4">
                    {filteredAndSortedNovels.map((novel) => (
                      <NovelCard
                        key={novel.id}
                        novel={novel}
                        progress={user.readingHistory.find((h) => h.novelId === novel.id)}
                        onSelect={(n) => setSelectedNovel(n)}
                        onResumeReading={handleResumeReading}
                        onSelectCreator={handleSelectCreator}
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Right Column: TOP 10 TRUYỆN HOT TRONG NGÀY */}
              <Top10HotSidebar
                novels={novels}
                onSelectNovel={(n) => setSelectedNovel(n)}
                onSelectCreator={handleSelectCreator}
              />
            </div>

            {/* TUYỆT ĐỐI KHÔNG CHỨA PHẦN ĐỀ XUẤT TRUYỆN Ở ĐÂY HOẶC BẤT CỨ ĐÂU */}
          </div>
        )}
      </main>

      {/* Floating Audio Bar */}
      {isAudioBarOpen && (
        <AudioPlayerBar
          currentNovel={selectedNovel}
          currentChapter={selectedChapter}
          isPlaying={isAudioPlaying}
          onTogglePlay={() => setIsAudioPlaying(!isAudioPlaying)}
          onClose={() => {
            setIsAudioBarOpen(false);
            setIsAudioPlaying(false);
          }}
          selectedVoiceId={readerSettings.selectedVoiceId}
          onVoiceChange={(voiceId) =>
            setReaderSettings((prev) => ({ ...prev, selectedVoiceId: voiceId }))
          }
          autoNextChapter={readerSettings.autoNextChapter}
          onToggleAutoNext={() =>
            setReaderSettings((prev) => ({
              ...prev,
              autoNextChapter: !prev.autoNextChapter,
            }))
          }
        />
      )}

      {/* Submit Novel Modal (For Admin & Authors, 5-chapter draft and device cover upload) */}
      <SubmitNovelModal
        isOpen={isSubmitNovelOpen}
        onClose={() => setIsSubmitNovelOpen(false)}
        user={user}
        genres={genres}
        onAddNewGenre={handleAddNewGenre}
        onSubmitForApproval={handleSubmitNovelForApproval}
        onDirectPublishByAdmin={handleDirectPublishNovel}
      />

      {/* TopUp Modal (VietQR, MoMo, Thẻ cào - Gửi yêu cầu chờ Admin duyệt) */}
      <TopUpModal
        isOpen={isTopUpOpen}
        onClose={() => setIsTopUpOpen(false)}
        user={user}
        onSubmitTopUp={handleSubmitTopUp}
      />

      {/* VIP Purchase Modal */}
      {purchasingTarget && (
        <VipPurchaseModal
          isOpen={isVipPurchaseOpen}
          onClose={() => {
            setIsVipPurchaseOpen(false);
            setPurchasingTarget(null);
          }}
          novel={purchasingTarget.novel}
          chapter={purchasingTarget.chapter}
          user={user}
          onConfirmPurchase={handleConfirmPurchase}
          onOpenTopUp={() => setIsTopUpOpen(true)}
        />
      )}

      {/* Admin Dashboard Modal (Duyệt Đơn Tác Giả 5 Chương + STK, Đối Soát Nhuận Bút, Quản Trị) */}
      <AdminDashboardModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        topUpRequests={topUpRequests}
        onApproveRequest={handleApproveTopUp}
        onRejectRequest={handleRejectTopUp}
        user={user}
        novels={novels}
        onAddBatchChapters={handleAddBatchChapters}
        novelSubmissions={novelSubmissions}
        onApproveNovelSubmission={handleApproveNovelSubmission}
        onRejectNovelSubmission={handleRejectNovelSubmission}
        onToggleHideNovel={handleToggleHideNovel}
        onDeleteNovel={handleDeleteNovel}
        onOpenEditNovel={handleOpenEditNovel}
        withdrawalRequests={withdrawalRequests}
        onApproveWithdrawal={handleApproveWithdrawal}
        onRejectWithdrawal={handleRejectWithdrawal}
        royaltyConfig={royaltyConfig}
        onUpdateRoyaltyConfig={setRoyaltyConfig}
        onOpenXmlModal={() => setIsXmlModalOpen(true)}
        onOpenArchitecture={() => setIsArchitectureOpen(true)}
        novelReports={novelReports}
        onResolveReport={handleResolveReport}
      />

      {/* Edit Novel & Chapters Modal for Admin */}
      {editingNovel && (
        <EditNovelModal
          isOpen={isEditNovelOpen}
          onClose={() => {
            setIsEditNovelOpen(false);
            setEditingNovel(null);
          }}
          novel={editingNovel}
          onSaveNovel={handleSaveEditedNovel}
          genres={genres}
        />
      )}

      {/* Architecture & Deployment Guide Modal */}
      <ArchitectureGuideModal
        isOpen={isArchitectureOpen}
        onClose={() => setIsArchitectureOpen(false)}
      />

      {/* Account Profile Modal */}
      <AccountModal
        isOpen={isAccountModalOpen}
        onClose={() => setIsAccountModalOpen(false)}
        user={user}
        onLogin={async () => {
          try {
            const fbUser = await loginWithGoogle();
            const profile = await syncUserProfile(fbUser);
            setUser(profile);
            if (profile.role === 'admin') {
              setIsAccountModalOpen(false);
              setIsAdminOpen(true);
            }
          } catch (err: any) {
            console.error('Google login error:', err);
            alert('Đăng nhập Google: ' + (err?.message || 'Không thể đăng nhập'));
          }
        }}
        onLogout={async () => {
          try {
            await logoutUser();
          } catch (err) {
            console.error('Logout error:', err);
          }
          setUser({
            id: 'guest',
            email: '',
            displayName: 'Khách Đọc Truyện',
            avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
            isLoggedIn: false,
            role: 'reader',
            xuBalance: 0,
            authorEarnedXu: 0,
            flowerBalance: 0,
            lastDailyRewardTimestamp: 0,
            lastDailyRewardDate: '',
            readingHistory: [],
            bookmarks: [],
            unlockedChapters: {},
            unlockedFullBooks: [],
            purchases: [],
          });
        }}
        onClearHistory={() => {
          setUser((prev) => ({
            ...prev,
            readingHistory: [],
          }));
        }}
        onResumeReading={(novelId, chapterId) => {
          const novel = novels.find((n) => n.id === novelId);
          if (novel) {
            const chapter = novel.chapters.find((c) => c.id === chapterId) || novel.chapters[0];
            setSelectedNovel(novel);
            setSelectedChapter(chapter);
          }
        }}
        onUpdateProfile={handleUpdateProfile}
        onOpenTopUp={() => {
          setIsAccountModalOpen(false);
          setIsTopUpOpen(true);
        }}
        onOpenAuthorShowcase={() => {
          setIsAccountModalOpen(false);
          handleOpenAuthorShowcase(user.displayName);
        }}
        onOpenSubmitNovel={() => {
          setIsAccountModalOpen(false);
          setIsSubmitNovelOpen(true);
        }}
        onOpenRegisterCreator={() => {
          setIsAccountModalOpen(false);
          setIsRegisterCreatorOpen(true);
        }}
        topUpRequests={topUpRequests}
        userSubmissions={novelSubmissions}
      />

      {/* Auth Modal (Bảng Đăng Ký & Đăng Nhập Chuẩn Hình 2 & 3) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        initialMode={authModalMode}
        onClose={() => setIsAuthModalOpen(false)}
        onSuccessLogin={(loggedInUser) => {
          setUser(loggedInUser);
          setIsAuthModalOpen(false);
          // Khi đăng nhập thì sẽ hiện như hình 4 nhưng mọi thứ đều trống
          setSelectedCreator({
            id: loggedInUser.id,
            name: loggedInUser.displayName,
            avatarUrl: loggedInUser.avatarUrl,
            bio: loggedInUser.bio,
            role: loggedInUser.role,
            email: loggedInUser.email,
            followers: loggedInUser.followers || [],
            xuBalance: loggedInUser.xuBalance || 0,
          });
          setSelectedNovel(null);
          setSelectedChapter(null);
        }}
      />

      {/* Edit Profile Modal (Change Display Name & Avatar with Upload, Presets & URL) */}
      <EditProfileModal
        isOpen={isEditProfileOpen}
        onClose={() => setIsEditProfileOpen(false)}
        user={user}
        onSaveProfile={handleUpdateProfile}
      />

      {/* Register Creator Modal (Author & Editor Registration with 5-chapter draft & Bank Info) */}
      <RegisterCreatorModal
        isOpen={isRegisterCreatorOpen}
        onClose={() => setIsRegisterCreatorOpen(false)}
        user={user}
        genres={genres}
        onAddNewGenre={handleAddNewGenre}
        onSubmitApplication={handleSubmitNovelForApproval}
        existingSubmission={novelSubmissions.find((s) => s.submittedBy?.userId === user.id || s.submittedBy?.userEmail === user.email)}
      />

      {/* Footer */}
      <footer className="bg-[#06080e] border-t border-blue-500/20 py-10 mt-16 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div className="md:col-span-2 space-y-3">
              <DaoTamLogo size="sm" />
              <p className="text-slate-400 leading-relaxed text-xs max-w-md">
                Nền tảng đọc truyện chữ và audio tự động đa giọng đọc. Không gian đọc tĩnh tâm, bảo vệ thị lực, tự động lưu và đồng bộ tiến trình đọc theo tài khoản.
              </p>
            </div>

            <div>
              <h4 className="font-bold text-white uppercase tracking-wider mb-3">Thông Tin &amp; Hỗ Trợ</h4>
              <ul className="space-y-1.5 text-slate-400">
                <li>• Điều khoản sử dụng &amp; Bản quyền</li>
                <li>• Chính sách bảo mật độc giả</li>
                <li>• Hướng dẫn nạp Xu &amp; mở khóa chương</li>
                <li>• Trình phát âm thanh Microsoft Edge TTS Neural Chuẩn</li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-white uppercase tracking-wider mb-3">Cam Kết Trải Nghiệm</h4>
              <p className="text-slate-400 leading-relaxed text-xs">
                Đạo Tâm tôn trọng trải nghiệm đọc sách thuần khiết của bạn, cam kết tốc độ tải trang nhanh chóng, không quảng cáo chen ngang gây khó chịu.
              </p>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
            <div>
              &copy; 2026 Đạo Tâm. Hệ thống đọc truyện và âm thanh trực tuyến chuẩn mực.
            </div>
            <div className="flex items-center gap-4">
              <span>Font chữ: Be Vietnam Pro chuẩn 100%</span>
              <span>•</span>
              <span>Audio: Microsoft Edge TTS (Hoài My &amp; Nam Minh)</span>
              <span>•</span>
              <span>Tone màu: Xanh Dương • Trắng • Đen</span>
            </div>
          </div>
        </div>
      </footer>

      {/* VIP Policy Modal */}
      <VipPolicyModal
        isOpen={isVipPolicyOpen}
        onClose={() => setIsVipPolicyOpen(false)}
      />

      {/* Daily Login Reward Modal (5 Flowers, yêu cầu đăng nhập Gmail, 24h cooldown) */}
      <DailyRewardModal
        isOpen={isDailyRewardOpen}
        onClose={() => setIsDailyRewardOpen(false)}
        user={user}
        onClaim={handleClaimDailyFlowers}
        onLogin={async () => {
          try {
            const fbUser = await loginWithGoogle();
            const profile = await syncUserProfile(fbUser);
            setUser(profile);
          } catch (err: any) {
            console.error('Google login error:', err);
            alert('Đăng nhập Google: ' + (err?.message || 'Không thể đăng nhập'));
          }
        }}
      />

      {/* Novel Nomination / Flower Gift Modal */}
      {nominatingNovel && (
        <NominateNovelModal
          isOpen={isNominateOpen}
          onClose={() => {
            setIsNominateOpen(false);
            setNominatingNovel(null);
          }}
          novel={nominatingNovel}
          user={user}
          onNominate={handleNominateNovel}
          onOpenDailyReward={() => setIsDailyRewardOpen(true)}
        />
      )}

      {/* Author & Editor Workspace Modal (Quản Lý Tác Phẩm, Soạn & Hẹn Giờ Chương VIP, Doanh Thu & Rút Nhuận Bút >= 100 Xu) */}
      <AuthorDashboardModal
        isOpen={isAuthorShowcaseOpen}
        onClose={() => setIsAuthorShowcaseOpen(false)}
        user={user}
        novels={novels}
        withdrawalRequests={withdrawalRequests}
        onSubmitWithdrawal={handleCreateWithdrawal}
        onSaveChapter={handleSaveChapterFromAuthor}
        onOpenCreateNovel={() => setIsSubmitNovelOpen(true)}
        onOpenEditNovel={handleOpenEditNovel}
      />

      {/* Report Novel Modal (Báo Cáo Vi Phạm: Bản Quyền, 18+, Reup, Bôi Nhọ VN, Khác) */}
      {reportingNovel && (
        <ReportNovelModal
          isOpen={isReportOpen}
          onClose={() => {
            setIsReportOpen(false);
            setReportingNovel(null);
          }}
          novel={reportingNovel}
          user={user}
          onSubmitReport={handleSubmitReport}
        />
      )}

      {/* Donate Creator Modal ($ Donate cho Tác Giả / Editor / Admin) */}
      <DonateModal
        isOpen={isDonateOpen}
        onClose={() => {
          setIsDonateOpen(false);
          setDonatingCreator(null);
        }}
        creator={donatingCreator}
        user={user}
        onDonateXu={handleDonateXu}
        onOpenTopUp={() => {
          setIsDonateOpen(false);
          setIsTopUpOpen(true);
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AudioProvider>
        <DaoTamApp />
      </AudioProvider>
    </AuthProvider>
  );
}
