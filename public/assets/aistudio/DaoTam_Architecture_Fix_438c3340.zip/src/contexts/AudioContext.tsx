import React, { createContext, useContext, useState, useRef, useEffect } from 'react';
import { Chapter } from '../types';

interface AudioContextType {
  isAudioPlaying: boolean;
  currentChunkIndex: number;
  playChapter: (chapter: Chapter, autoNext?: boolean, onChapterEnd?: () => void) => void;
  pause: () => void;
  resume: () => void;
  stop: () => void;
}

const AudioContext = createContext<AudioContextType | null>(null);

export const AudioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [currentChunkIndex, setCurrentChunkIndex] = useState(-1);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const chunksRef = useRef<string[]>([]);
  const indexRef = useRef(0);
  const autoNextRef = useRef(false);
  const onChapterEndRef = useRef<(() => void) | null>(null);

  // Khởi tạo Audio Element duy nhất để lách luật Autoplay
  useEffect(() => {
    audioRef.current = new Audio();
    audioRef.current.onended = playNextChunk;
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  const playNextChunk = () => {
    if (indexRef.current >= chunksRef.current.length) {
      setIsAudioPlaying(false);
      if (autoNextRef.current && onChapterEndRef.current) {
        onChapterEndRef.current(); // Gọi hàm chuyển chương
      }
      return;
    }

    const chunk = chunksRef.current[indexRef.current];
    setCurrentChunkIndex(indexRef.current);
    indexRef.current++;

    if (audioRef.current && chunk) {
      // Gọi lên API thực tế của bạn (Next.js API route)
      audioRef.current.src = `/api/tts/stream?text=${encodeURIComponent(chunk)}&voice=vi-VN-HoaiMyNeural`;
      audioRef.current.play().catch(e => {
        console.error('Audio play error:', e);
        setIsAudioPlaying(false);
      });
    }
  };

  const playChapter = (chapter: Chapter, autoNext = true, onChapterEnd?: () => void) => {
    // Dừng luồng cũ nếu có
    if (audioRef.current) {
      audioRef.current.pause();
    }
    
    // Chunking: Ép câu 1 phải rất ngắn để đọc ngay
    const fullText = `${chapter.title}. ${chapter.content}`;
    const rawChunks = fullText.match(/[^.!?\n]+[.!?\n]+/g) || [fullText];
    
    // Đảm bảo chunk đầu < 50 ký tự nếu có thể
    if (rawChunks[0].length > 50) {
        const words = rawChunks[0].split(' ');
        chunksRef.current = [words.slice(0, 5).join(' '), words.slice(5).join(' '), ...rawChunks.slice(1)];
    } else {
        chunksRef.current = rawChunks;
    }

    indexRef.current = 0;
    autoNextRef.current = autoNext;
    onChapterEndRef.current = onChapterEnd || null;
    setIsAudioPlaying(true);
    playNextChunk();
  };

  const pause = () => {
    if (audioRef.current) audioRef.current.pause();
    setIsAudioPlaying(false);
  };

  const resume = () => {
    if (audioRef.current) audioRef.current.play();
    setIsAudioPlaying(true);
  };

  const stop = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    setIsAudioPlaying(false);
    setCurrentChunkIndex(-1);
  };

  return (
    <AudioContext.Provider value={{ isAudioPlaying, currentChunkIndex, playChapter, pause, resume, stop }}>
      {children}
    </AudioContext.Provider>
  );
};

export const useAudio = () => {
  const context = useContext(AudioContext);
  if (!context) throw new Error("useAudio must be used within AudioProvider");
  return context;
};
